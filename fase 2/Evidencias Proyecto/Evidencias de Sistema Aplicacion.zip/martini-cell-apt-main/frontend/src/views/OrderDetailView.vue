<script setup>
import { computed, nextTick, onBeforeUnmount, ref, watch } from 'vue'
import { useRoute } from 'vue-router'

import AdminLayout from '../layouts/AdminLayout.vue'
import PageHeader from '../components/PageHeader.vue'
import StatusBadge from '../components/StatusBadge.vue'
import { authenticatedFetch, getCurrentUser } from '../services/auth'

const route = useRoute()
const currentUser = getCurrentUser()
const canEditReport = ['ADMIN', 'TECH'].includes(currentUser?.role)
const canViewTechnicalReportHistory = ['ADMIN', 'TECH'].includes(currentUser?.role)
const canChangeStatus = ['ADMIN', 'TECH'].includes(currentUser?.role)
const canRegisterParts = ['ADMIN', 'TECH'].includes(currentUser?.role)
const canCorrectParts = ['ADMIN', 'TECH'].includes(currentUser?.role)
const canCancelParts = ['ADMIN', 'TECH'].includes(currentUser?.role)
const canViewFinancial = ['ADMIN', 'TECH'].includes(currentUser?.role)
const canEditFinancial = currentUser?.role === 'ADMIN'
const canViewWarranties = ['ADMIN', 'TECH'].includes(currentUser?.role)
const canManageWarranties = ['ADMIN', 'TECH'].includes(currentUser?.role)
const canManageReceptionReceipt = ['ADMIN', 'TECH'].includes(currentUser?.role)

// HU-23: el técnico propone y el administrador resuelve.
const canProposeWarrantyResolution = currentUser?.role === 'TECH'
const canAdminResolveWarrantyRequest = currentUser?.role === 'ADMIN'

const canViewViability = ['ADMIN', 'TECH'].includes(currentUser?.role)
const canManageViability = ['ADMIN', 'TECH'].includes(currentUser?.role)

// HU-27: edición y consulta de cambios sensibles solo para ADMIN/TECH.
const canEditSensitiveOrder = ['ADMIN', 'TECH'].includes(currentUser?.role)
const canViewSensitiveHistory = ['ADMIN', 'TECH'].includes(currentUser?.role)

const order = ref(null)
const history = ref([])
const latestStatusEvent = computed(() => history.value.at(-1) || null)
const technicalReport = ref(null)
const times = ref(null)

// HU-34: comprobante de recepción, canal preferido e historial de entregas.
const receptionReceipt = ref(null)
const receptionReceiptLoading = ref(false)
const receptionReceiptError = ref('')
const receptionReceiptSaving = ref(false)
const receptionReceiptDeliveryMethod = ref('')
const receptionReceiptDeliverySaving = ref(false)
const receptionReceiptDeliveryError = ref('')
const receptionReceiptDeliverySuccess = ref('')
const receptionReceiptWhatsappUrl = ref('')
let receptionReceiptRequestId = 0

const receptionReceiptSnapshot = computed(() =>
  receptionReceipt.value?.snapshot || null
)
const receptionReceiptOrder = computed(() =>
  receptionReceiptSnapshot.value?.order || {}
)
const receptionReceiptClient = computed(() =>
  receptionReceiptSnapshot.value?.client || {}
)
const receptionReceiptEquipment = computed(() =>
  receptionReceiptSnapshot.value?.equipment || {}
)
const receptionReceiptData = computed(() =>
  receptionReceiptSnapshot.value?.reception || {}
)
const receptionReceiptTracking = computed(() =>
  receptionReceiptSnapshot.value?.tracking || {}
)

const receptionReceiptHasEmail = computed(() =>
  Boolean(String(receptionReceiptClient.value?.email || '').trim())
)
const receptionReceiptHasPhone = computed(() =>
  Boolean(String(receptionReceiptClient.value?.phone || '').trim())
)

// HU-27: edición controlada e historial de cambios sensibles.
const sensitiveChanges = ref([])
const sensitiveHistoryLoading = ref(false)
const sensitiveHistoryError = ref('')
const sensitiveEditOpen = ref(false)
const sensitiveReferenceLoading = ref(false)
const sensitiveReferenceError = ref('')
const sensitiveSaving = ref(false)
const sensitiveFormError = ref('')
const sensitiveSuccess = ref('')
const sensitiveClients = ref([])
const sensitiveDevices = ref([])

const emptySensitiveOrderForm = () => ({
  client: '',
  equipment: '',
  reported_issue: '',
  initial_observations: '',
  change_reason: '',
})
const sensitiveOrderForm = ref(emptySensitiveOrderForm())

const sensitiveOrderLocked = computed(() =>
  ['DELIVERED', 'CLOSED'].includes(order.value?.status)
)

const availableSensitiveDevices = computed(() => {
  const clientId = String(sensitiveOrderForm.value.client || '')
  if (!clientId) return []

  return sensitiveDevices.value.filter((device) =>
    String(device.client) === clientId &&
    (device.is_active || Number(device.id) === Number(order.value?.equipment))
  )
})

const sensitiveRelationChanged = computed(() =>
  Number(sensitiveOrderForm.value.client) !== Number(order.value?.client) ||
  Number(sensitiveOrderForm.value.equipment) !== Number(order.value?.equipment)
)

function clientIdentificationLabel(client) {
  if (!client) return 'Sin documento'

  if (client.identification_type === 'RUT') {
    const clean = String(client.rut || '')
    const verifier = clean.slice(-1)
    const body = clean.slice(0, -1)
    const formattedBody = body.replace(
      /\B(?=(\d{3})+(?!\d))/g,
      '.'
    )

    return clean
      ? `RUT chileno: ${formattedBody}-${verifier}`
      : 'RUT chileno: No registrado'
  }

  if (client.identification_type === 'PASSPORT') {
    return `Pasaporte: ${client.document_number || 'No registrado'}`
  }

  if (client.identification_type === 'FOREIGN_DOCUMENT') {
    return `Documento extranjero: ${client.document_number || 'No registrado'}`
  }

  return 'Sin documento'
}

function notificationDisplayDetail(detail) {
  const value = String(detail || '').trim()

  if (!value) return ''

  if (!value.includes('ID de Meta:')) {
    return value
  }

  if (
    value.startsWith(
      'Comprobante enviado mediante WhatsApp Cloud API.'
    )
  ) {
    return 'Comprobante enviado correctamente mediante WhatsApp.'
  }

  if (
    value.startsWith(
      'Aviso de cambio de estado enviado mediante WhatsApp Cloud API.'
    )
  ) {
    return 'Aviso de cambio de estado enviado correctamente mediante WhatsApp.'
  }

  if (
    value.startsWith(
      'Aviso de nueva respuesta enviado mediante WhatsApp Cloud API.'
    )
  ) {
    return 'Aviso de nueva respuesta enviado correctamente mediante WhatsApp.'
  }

  return value.replace(/\s*ID de Meta:.*$/i, '').trim()
}

function syncSensitiveOrderForm() {
  if (!order.value) {
    sensitiveOrderForm.value = emptySensitiveOrderForm()
    return
  }

  sensitiveOrderForm.value = {
    client: order.value.client ?? '',
    equipment: order.value.equipment ?? '',
    reported_issue: order.value.reported_issue ?? '',
    initial_observations: order.value.initial_observations ?? '',
    change_reason: '',
  }
}

function resetSensitiveOrderState() {
  sensitiveChanges.value = []
  sensitiveHistoryLoading.value = false
  sensitiveHistoryError.value = ''
  sensitiveEditOpen.value = false
  sensitiveReferenceLoading.value = false
  sensitiveReferenceError.value = ''
  sensitiveSaving.value = false
  sensitiveFormError.value = ''
  sensitiveSuccess.value = ''
  sensitiveClients.value = []
  sensitiveDevices.value = []
  sensitiveOrderForm.value = emptySensitiveOrderForm()
}

function onSensitiveClientChange() {
  const selectedDevice = sensitiveDevices.value.find(
    (device) => Number(device.id) === Number(sensitiveOrderForm.value.equipment)
  )

  if (
    selectedDevice &&
    String(selectedDevice.client) !== String(sensitiveOrderForm.value.client)
  ) {
    sensitiveOrderForm.value.equipment = ''
  }

  sensitiveFormError.value = ''
  sensitiveSuccess.value = ''
}

function formatSensitiveValue(value) {
  if (value === null || value === undefined || value === '') return 'Sin información'

  if (typeof value === 'object') {
    if (value.name) return `${value.name}${value.id ? ` (#${value.id})` : ''}`
    if (value.description) {
      return `${value.description}${value.id ? ` (#${value.id})` : ''}`
    }
    return JSON.stringify(value)
  }

  return String(value)
}

function sensitiveRoleLabel(role) {
  if (role === 'ADMIN') return 'Administrador'
  if (role === 'TECH') return 'Técnico'
  if (role === 'HELPER') return 'Ayudante'
  return role || 'No disponible'
}

async function loadSensitiveReferenceData() {
  if (!canEditSensitiveOrder || sensitiveReferenceLoading.value) return

  sensitiveReferenceLoading.value = true
  sensitiveReferenceError.value = ''

  try {
    const [clientsResponse, devicesResponse] = await Promise.all([
      authenticatedFetch('/api/clients/'),
      authenticatedFetch('/api/devices/'),
    ])

    const clientsData = await clientsResponse.json().catch(() => null)
    const devicesData = await devicesResponse.json().catch(() => null)

    if (!clientsResponse.ok) {
      throw new Error(
        evidenceApiError(clientsData, 'No fue posible cargar los clientes.')
      )
    }

    if (!devicesResponse.ok) {
      throw new Error(
        evidenceApiError(devicesData, 'No fue posible cargar los equipos.')
      )
    }

    sensitiveClients.value = Array.isArray(clientsData)
      ? clientsData
      : (clientsData?.results || [])

    sensitiveDevices.value = Array.isArray(devicesData)
      ? devicesData
      : (devicesData?.results || [])
  } catch (err) {
    sensitiveReferenceError.value =
      err?.message || 'Error al cargar clientes y equipos.'
  } finally {
    sensitiveReferenceLoading.value = false
  }
}

async function loadSensitiveHistory(orderId = order.value?.id, sequence = loadSequence) {
  if (!canViewSensitiveHistory || !orderId) return

  sensitiveHistoryLoading.value = true
  sensitiveHistoryError.value = ''

  try {
    const response = await getResponse(
      `/api/orders/${orderId}/sensitive-changes/`
    )

    if (sequence !== loadSequence) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(
          response.data,
          'No fue posible cargar el historial de cambios sensibles.'
        )
      )
    }

    sensitiveChanges.value = Array.isArray(response.data)
      ? response.data
      : (response.data?.results || [])
  } catch (err) {
    if (sequence === loadSequence) {
      sensitiveChanges.value = []
      sensitiveHistoryError.value =
        err?.message || 'Error al consultar el historial de cambios sensibles.'
    }
  } finally {
    if (sequence === loadSequence) sensitiveHistoryLoading.value = false
  }
}

async function openSensitiveOrderEdit() {
  if (!canEditSensitiveOrder || sensitiveOrderLocked.value || !order.value) return

  sensitiveFormError.value = ''
  sensitiveSuccess.value = ''
  syncSensitiveOrderForm()

  if (!sensitiveClients.value.length || !sensitiveDevices.value.length) {
    await loadSensitiveReferenceData()
  }

  if (!sensitiveReferenceError.value) sensitiveEditOpen.value = true
}

function cancelSensitiveOrderEdit() {
  if (sensitiveSaving.value) return
  sensitiveEditOpen.value = false
  sensitiveFormError.value = ''
  syncSensitiveOrderForm()
}

async function saveSensitiveOrder() {
  if (
    !canEditSensitiveOrder ||
    sensitiveOrderLocked.value ||
    sensitiveSaving.value ||
    !order.value
  ) return

  sensitiveFormError.value = ''
  sensitiveSuccess.value = ''

  const clientId = Number(sensitiveOrderForm.value.client)
  const equipmentId = Number(sensitiveOrderForm.value.equipment)
  const reportedIssue = String(
    sensitiveOrderForm.value.reported_issue ?? ''
  ).trim()
  const initialObservations = String(
    sensitiveOrderForm.value.initial_observations ?? ''
  ).trim()
  const changeReason = String(
    sensitiveOrderForm.value.change_reason ?? ''
  ).trim()

  if (!clientId || !equipmentId) {
    sensitiveFormError.value = 'Selecciona un cliente y un equipo válido.'
    return
  }

  const selectedDevice = sensitiveDevices.value.find(
    (device) => Number(device.id) === equipmentId
  )

  if (!selectedDevice || Number(selectedDevice.client) !== clientId) {
    sensitiveFormError.value =
      'El equipo seleccionado debe pertenecer al cliente indicado.'
    return
  }

  if (!reportedIssue) {
    sensitiveFormError.value = 'La falla reportada no puede quedar vacía.'
    return
  }

  if (sensitiveRelationChanged.value && !changeReason) {
    sensitiveFormError.value =
      'Debes indicar el motivo al cambiar el cliente o el equipo.'
    return
  }

  const orderId = order.value.id
  const sequence = loadSequence
  sensitiveSaving.value = true

  try {
    const response = await authenticatedFetch(`/api/orders/${orderId}/`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        client: clientId,
        equipment: equipmentId,
        reported_issue: reportedIssue,
        initial_observations: initialObservations,
        change_reason: changeReason,
      }),
    })

    const data = await response.json().catch(() => null)

    if (sequence !== loadSequence) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(data, 'No fue posible actualizar los datos de la orden.')
      )
    }

    order.value = data
    sensitiveEditOpen.value = false
    syncSensitiveOrderForm()
    sensitiveSuccess.value =
      'Datos de la orden actualizados. Los cambios sensibles quedaron registrados.'

    await loadSensitiveHistory(orderId, sequence)
  } catch (err) {
    if (sequence === loadSequence) {
      sensitiveFormError.value =
        err?.message || 'Error al actualizar los datos de la orden.'
    }
  } finally {
    if (sequence === loadSequence) sensitiveSaving.value = false
  }
}

// HU-10: cambios de estado autorizados por la API y trazabilidad real.
const statusInfo = ref(null)
const statusLoading = ref(false)
const statusSaving = ref(false)
const statusError = ref('')
const statusFormError = ref('')
const statusSuccess = ref('')

// HU-37: resultado del intento de notificación asociado al último cambio.
const statusNotificationFeedback = ref(null)

const nextStatus = ref('')
const statusNote = ref('')

function statusNotificationAlertClass(notification) {
  if (!notification) return 'alert-secondary'

  if (notification.status === 'SENT') return 'alert-success'
  if (notification.status === 'PREPARED') return 'alert-info'
  if (notification.status === 'FAILED') return 'alert-warning'

  return 'alert-secondary'
}

function statusNotificationTitle(notification) {
  if (!notification) return ''

  if (notification.status === 'SENT') {
    return 'Notificación enviada'
  }

  if (notification.status === 'PREPARED') {
    return 'WhatsApp preparado'
  }

  if (notification.status === 'FAILED') {
    return 'Estado guardado; notificación no completada'
  }

  return 'Resultado de la notificación'
}

function statusNotificationChannelLabel(notification) {
  if (!notification) return 'Sin canal'

  return (
    notification.channel_display ||
    (
      notification.channel === 'EMAIL'
        ? 'Correo electrónico'
        : notification.channel === 'WHATSAPP'
          ? 'WhatsApp'
          : 'Sin canal configurado'
    )
  )
}

// HU-09: informe técnico real y sus revisiones.
const technicalReportHistory = ref([])
const reportHistoryLoading = ref(false)
const reportHistoryError = ref('')
const reportSaving = ref(false)
const reportFormError = ref('')
const reportSuccess = ref('')
const technicians = ref([])
const techniciansLoading = ref(false)
const techniciansError = ref('')

const emptyReportForm = () => ({
  diagnosis: '',
  repair_actions: '',
  repair_observations: '',
  parts_description: '',
  result: '',
  technician: '',
})
const reportForm = ref(emptyReportForm())

const reportResults = [
  { value: 'REPARADO', label: 'Reparado' },
  { value: 'PARCIAL', label: 'Reparado parcialmente' },
  { value: 'NO_REPARABLE', label: 'No reparable' },
  { value: 'SIN_FALLA', label: 'Sin falla detectada' },
]

const tab = ref('resumen')
const loading = ref(true)
const error = ref('')
const historyError = ref('')
const reportError = ref('')
const timesError = ref('')

// HU-08: evidencias fotográficas asociadas a la orden real.
const evidences = ref([])
const evidenceLoading = ref(false)
const evidenceError = ref('')
const uploadingEvidence = ref(false)
const uploadError = ref('')
const uploadSuccess = ref('')
const evidenceStage = ref('RECEPCION')
const evidenceDescription = ref('')
const evidenceFile = ref(null)
const evidenceInput = ref(null)
const imageUrls = ref({})
const imageLoading = ref({})
const imageErrors = ref({})

const evidenceStages = [
  { value: 'RECEPCION', label: 'Recepción' },
  { value: 'DIAGNOSTICO', label: 'Diagnóstico' },
  { value: 'REPARACION', label: 'Reparación' },
  { value: 'ENTREGA', label: 'Entrega' },
  { value: 'OTRO', label: 'Otro' },
]

const maxEvidenceSize = 20 * 1024 * 1024
let evidenceRequestId = 0

// HU-13: repuestos reales consumidos por esta orden y catálogo disponible.
const usedParts = ref([])
const partCatalog = ref([])
const orderPartsLoading = ref(false)
const orderPartsError = ref('')
const partCatalogError = ref('')
const orderPartSaving = ref(false)
const orderPartFormError = ref('')
const orderPartSuccess = ref('')
const emptyOrderPartForm = () => ({ part: '', quantity: 1, note: '' })
const orderPartForm = ref(emptyOrderPartForm())
const selectedPart = computed(() =>
  partCatalog.value.find((item) => Number(item.id) === Number(orderPartForm.value.part)) || null
)
const usedPartsTotal = computed(() =>
  usedParts.value
    .filter((item) => !item.is_cancelled)
    .reduce((total, item) => total + Number(item.subtotal || 0), 0)
)
let orderPartsRequestId = 0

// HU-24: corrección trazable de cantidad/nota en usos de repuesto.
const orderPartCorrectionOpenId = ref(null)
const orderPartCorrectionForms = ref({})
const orderPartCorrectionSavingId = ref(null)
const orderPartCorrectionErrors = ref({})
const orderPartCorrectionSuccess = ref({})
const orderPartCorrectionHistoryById = ref({})
const orderPartCorrectionHistoryLoading = ref({})
const orderPartCorrectionHistoryErrors = ref({})
const expandedOrderPartCorrectionHistoryId = ref(null)
let orderPartCorrectionHistoryRequestId = 0
let orderPartCorrectionHistoryLatestById = {}

function emptyOrderPartCorrectionForm(item = null) {
  return {
    field_name: 'QUANTITY',
    quantity: item?.quantity ?? 1,
    note: item?.note ?? '',
    reason: '',
  }
}

function setOrderPartCorrectionError(orderPartId, message) {
  orderPartCorrectionErrors.value = {
    ...orderPartCorrectionErrors.value,
    [orderPartId]: message,
  }
}

function setOrderPartCorrectionSuccess(orderPartId, message) {
  orderPartCorrectionSuccess.value = {
    ...orderPartCorrectionSuccess.value,
    [orderPartId]: message,
  }
}

function clearOrderPartCorrectionMessages(orderPartId) {
  setOrderPartCorrectionError(orderPartId, '')
  setOrderPartCorrectionSuccess(orderPartId, '')
}

function isOrderPartCorrectionSaving(orderPartId) {
  return Number(orderPartCorrectionSavingId.value) === Number(orderPartId)
}

// HU-25: anulación trazable de un uso de repuesto.
const orderPartCancellationOpenId = ref(null)
const orderPartCancellationForms = ref({})
const orderPartCancellationSavingId = ref(null)
const orderPartCancellationErrors = ref({})
const orderPartCancellationSuccess = ref({})

function emptyOrderPartCancellationForm() {
  return {
    reason: '',
  }
}

function setOrderPartCancellationError(orderPartId, message) {
  orderPartCancellationErrors.value = {
    ...orderPartCancellationErrors.value,
    [orderPartId]: message,
  }
}

function setOrderPartCancellationSuccess(orderPartId, message) {
  orderPartCancellationSuccess.value = {
    ...orderPartCancellationSuccess.value,
    [orderPartId]: message,
  }
}

function clearOrderPartCancellationMessages(orderPartId) {
  setOrderPartCancellationError(orderPartId, '')
  setOrderPartCancellationSuccess(orderPartId, '')
}

function isOrderPartCancellationSaving(orderPartId) {
  return Number(orderPartCancellationSavingId.value) === Number(orderPartId)
}

// HU-14: resumen calculado en Django y datos financieros editables por ADMIN.
const financial = ref(null)
const financialLoading = ref(false)
const financialError = ref('')
const financialSaving = ref(false)
const financialFormError = ref('')
const financialSuccess = ref('')
const emptyFinancialForm = () => ({
  price_charged: '',
  labor_cost: '0.00',
  other_direct_cost: '0.00',
  notes: '',
})
const financialForm = ref(emptyFinancialForm())
let financialRequestId = 0

function resetFinancial() {
  ++financialRequestId
  financial.value = null
  financialLoading.value = false
  financialError.value = ''
  financialSaving.value = false
  financialFormError.value = ''
  financialSuccess.value = ''
  financialForm.value = emptyFinancialForm()
}

function syncFinancialForm(data) {
  financialForm.value = {
    price_charged: data.price_charged ?? '',
    labor_cost: data.labor_cost ?? '0.00',
    other_direct_cost: data.other_direct_cost ?? '0.00',
    notes: data.notes ?? '',
  }
}

async function loadFinancial() {
  if (!order.value || !canViewFinancial) return
  const orderId = order.value.id
  const sequence = loadSequence
  const requestId = ++financialRequestId
  const isCurrent = () => sequence === loadSequence && requestId === financialRequestId
  financialLoading.value = true
  financialError.value = ''

  try {
    const response = await getResponse(`/api/orders/${orderId}/financial/`)
    if (!isCurrent()) return
    if (!response.ok) {
      throw new Error(evidenceApiError(response.data, 'No fue posible cargar el resumen financiero.'))
    }
    financial.value = response.data
    syncFinancialForm(response.data)
  } catch (err) {
    if (isCurrent()) {
      financial.value = null
      financialError.value = err?.message || 'Error al consultar el resumen financiero.'
    }
  } finally {
    if (isCurrent()) financialLoading.value = false
  }
}

async function refreshPartsAndFinancial() {
  await Promise.allSettled([
    loadOrderParts(),
    ...(canViewFinancial ? [loadFinancial()] : []),
  ])
}

async function saveFinancial() {
  if (!order.value || !canEditFinancial || financialSaving.value || financialLoading.value || !financial.value) return
  financialFormError.value = ''
  financialSuccess.value = ''

  // Evitamos convertir importes a Number antes de enviarlos: Django utiliza Decimal.
  // DecimalField(max_digits=12, decimal_places=2): hasta 10 dígitos enteros.
  const amountPattern = /^\d{1,10}(?:\.\d{1,2})?$/
  const priceText = String(financialForm.value.price_charged ?? '').trim()
  const laborText = String(financialForm.value.labor_cost ?? '').trim()
  const otherText = String(financialForm.value.other_direct_cost ?? '').trim()
  if (priceText !== '' && !amountPattern.test(priceText)) {
    financialFormError.value = 'El precio debe ser no negativo, con hasta 10 dígitos enteros y 2 decimales.'
    return
  }
  if (!amountPattern.test(laborText) || !amountPattern.test(otherText)) {
    financialFormError.value = 'Los costos deben ser no negativos, con hasta 10 dígitos enteros y 2 decimales.'
    return
  }

  const sequence = loadSequence
  const orderId = order.value.id
  financialSaving.value = true
  try {
    const response = await authenticatedFetch(`/api/orders/${orderId}/financial/`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        price_charged: priceText === '' ? null : priceText,
        labor_cost: laborText,
        other_direct_cost: otherText,
        notes: String(financialForm.value.notes ?? '').trim(),
      }),
    })
    const data = await response.json().catch(() => null)
    if (sequence !== loadSequence) return
    if (!response.ok) {
      throw new Error(evidenceApiError(data, 'No fue posible guardar los datos financieros.'))
    }
    financial.value = data
    financialError.value = ''
    syncFinancialForm(data)
    financialSuccess.value = 'Datos financieros guardados y margen recalculado correctamente.'
  } catch (err) {
    if (sequence === loadSequence) {
      financialFormError.value = err?.message || 'Error al guardar los datos financieros.'
    }
  } finally {
    if (sequence === loadSequence) financialSaving.value = false
  }
}

// HU-15: garantías del servicio/repuestos e historial de revisiones.
const warranties = ref([])
const warrantyLoading = ref(false)
const warrantyError = ref('')
const warrantySaving = ref(false)
const warrantyDeletingId = ref(null)
const warrantyFormError = ref('')
const warrantySuccess = ref('')
const editingWarrantyId = ref(null)
const warrantyHistoryById = ref({})
const warrantyHistoryLoading = ref({})
const warrantyHistoryErrors = ref({})
const expandedWarrantyHistoryId = ref(null)
let warrantyRequestId = 0
let warrantyHistoryRequestId = 0
let warrantyHistoryLatestById = {}

// HU-22: solicitudes/reclamos asociados a una garantía existente.
const warrantyRequests = ref([])
const warrantyRequestsLoading = ref(false)
const warrantyRequestsError = ref('')
const warrantyRequestSaving = ref(false)
const warrantyRequestFormError = ref('')
const warrantyRequestSuccess = ref('')
const warrantyRequestHistoryById = ref({})
const warrantyRequestHistoryLoading = ref({})
const warrantyRequestHistoryErrors = ref({})
const expandedWarrantyRequestHistoryId = ref(null)
const warrantyRequestFileInput = ref(null)
const warrantyRequestImageUrls = ref({})
const warrantyRequestImageFilenames = ref({})
const warrantyRequestImageLoading = ref({})
const warrantyRequestImageErrors = ref({})
let warrantyClaimRequestId = 0
let warrantyClaimHistoryRequestId = 0
let warrantyClaimHistoryLatestById = {}
let warrantyClaimImageRequestId = 0

// HU-23: propuesta técnica, revisión administrativa y resolución final.
const warrantyActionOptions = [
  { value: 'REPAIR', label: 'Reparación' },
  { value: 'PART_REPLACEMENT', label: 'Cambio de repuesto' },
  { value: 'OTHER', label: 'Otra' },
]

const warrantyRequestActionSavingId = ref(null)
const warrantyRequestActionErrors = ref({})
const warrantyRequestActionSuccess = ref({})
const warrantyProposalForms = ref({})
const warrantyResolutionForms = ref({})
const warrantyReturnForms = ref({})
const warrantyAdminNoteForms = ref({})

function emptyWarrantyProposalForm(requestItem = null) {
  const previous = requestItem?.status === 'CHANGES_REQUESTED'
    ? requestItem?.latest_proposal
    : null

  return {
    technical_rationale: previous?.technical_rationale ?? '',
    action_type: previous?.action_type ?? '',
    action_description: previous?.action_description ?? '',
  }
}

function emptyWarrantyResolutionForm(requestItem = null) {
  const latestProposal = requestItem?.latest_proposal

  return {
    decision: '',
    rationale: '',
    action_type: latestProposal?.action_type ?? '',
    action_description: latestProposal?.action_description ?? '',
  }
}

function emptyWarrantyReturnForm() {
  return {
    reason: '',
  }
}

function emptyWarrantyAdminNoteForm() {
  return {
    observation: '',
  }
}

function ensureWarrantyRequestActionForms(items) {
  const proposals = { ...warrantyProposalForms.value }
  const resolutions = { ...warrantyResolutionForms.value }
  const returns = { ...warrantyReturnForms.value }
  const notes = { ...warrantyAdminNoteForms.value }

  for (const item of items) {
    if (!Object.prototype.hasOwnProperty.call(proposals, item.id)) {
      proposals[item.id] = emptyWarrantyProposalForm(item)
    }

    if (!Object.prototype.hasOwnProperty.call(resolutions, item.id)) {
      resolutions[item.id] = emptyWarrantyResolutionForm(item)
    }

    if (!Object.prototype.hasOwnProperty.call(returns, item.id)) {
      returns[item.id] = emptyWarrantyReturnForm()
    }

    if (!Object.prototype.hasOwnProperty.call(notes, item.id)) {
      notes[item.id] = emptyWarrantyAdminNoteForm()
    }
  }

  warrantyProposalForms.value = proposals
  warrantyResolutionForms.value = resolutions
  warrantyReturnForms.value = returns
  warrantyAdminNoteForms.value = notes
}

function clearWarrantyRequestActionMessages(requestId) {
  warrantyRequestActionErrors.value = {
    ...warrantyRequestActionErrors.value,
    [requestId]: '',
  }
  warrantyRequestActionSuccess.value = {
    ...warrantyRequestActionSuccess.value,
    [requestId]: '',
  }
}

function setWarrantyRequestActionError(requestId, message) {
  warrantyRequestActionErrors.value = {
    ...warrantyRequestActionErrors.value,
    [requestId]: message,
  }
}

function setWarrantyRequestActionSuccess(requestId, message) {
  warrantyRequestActionSuccess.value = {
    ...warrantyRequestActionSuccess.value,
    [requestId]: message,
  }
}

function warrantyActionTypeLabel(value) {
  return (
    warrantyActionOptions.find((item) => item.value === value)?.label ||
    value ||
    'No indicada'
  )
}

function warrantyResolutionAlertClass(decision) {
  return decision === 'ACCEPTED'
    ? 'alert-success'
    : 'alert-danger'
}

function isWarrantyRequestActionSaving(requestId) {
  return Number(warrantyRequestActionSavingId.value) === Number(requestId)
}

function localDateInputValue() {
  const now = new Date()
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60_000)
  return local.toISOString().slice(0, 10)
}

function emptyWarrantyRequestForm() {
  return {
    warranty: '',
    requested_on: localDateInputValue(),
    problem_description: '',
    concurrent_open_reason: '',
    evidence: null,
  }
}

const warrantyRequestForm = ref(emptyWarrantyRequestForm())

const selectedWarrantyForRequest = computed(() =>
  warranties.value.find(
    (item) => Number(item.id) === Number(warrantyRequestForm.value.warranty)
  ) || null
)

const openWarrantyRequestExists = computed(() => {
  const warrantyId = Number(warrantyRequestForm.value.warranty)
  if (!warrantyId) return false

  return warrantyRequests.value.some(
    (item) =>
      Number(item.warranty) === warrantyId &&
      ['PENDING', 'AWAITING_APPROVAL', 'CHANGES_REQUESTED'].includes(item.status)
  )
})

const warrantyRequestBlockedReason = computed(() => {
  const warranty = selectedWarrantyForRequest.value
  if (!warranty) return ''

  if (warranty.status === 'NOT_APPLICABLE') {
    return 'Esta garantía está marcada como «No aplica», por lo que no puede recibir solicitudes.'
  }

  if (warranty.status === 'NOT_STARTED') {
    return 'La cobertura todavía no ha comenzado. No se puede ingresar una solicitud hasta su fecha de inicio.'
  }

  return ''
})

const warrantyStatusLabels = {
  ACTIVE: 'Vigente',
  EXPIRED: 'Vencida',
  NOT_APPLICABLE: 'No aplica',
  NOT_STARTED: 'Aún no inicia',
}

const serviceWarrantyExists = computed(() =>
  warranties.value.some((item) => item.warranty_type === 'SERVICE')
)
const availableWarrantyParts = computed(() =>
  usedParts.value.filter((usage) =>
    !usage.is_cancelled
    && !warranties.value.some((warranty) => Number(warranty.order_part) === Number(usage.id))
  )
)
const emptyWarrantyForm = (type = 'SERVICE') => ({
  warranty_type: type,
  order_part: '',
  is_applicable: true,
  starts_on: '',
  ends_on: '',
  conditions: '',
  change_note: '',
})
const warrantyForm = ref(emptyWarrantyForm())
const selectedWarrantyPart = computed(() =>
  usedParts.value.find((item) => Number(item.id) === Number(warrantyForm.value.order_part)) || null
)

function resetWarranties() {
  ++warrantyRequestId
  ++warrantyHistoryRequestId
  warrantyHistoryLatestById = {}
  warranties.value = []
  warrantyLoading.value = false
  warrantyError.value = ''
  warrantySaving.value = false
  warrantyDeletingId.value = null
  warrantyFormError.value = ''
  warrantySuccess.value = ''
  editingWarrantyId.value = null
  warrantyForm.value = emptyWarrantyForm()
  warrantyHistoryById.value = {}
  warrantyHistoryLoading.value = {}
  warrantyHistoryErrors.value = {}
  expandedWarrantyHistoryId.value = null
  resetWarrantyRequests()
}

function resetWarrantyForm() {
  editingWarrantyId.value = null
  warrantyForm.value = emptyWarrantyForm(serviceWarrantyExists.value ? 'PART' : 'SERVICE')
  warrantyFormError.value = ''
}

function startEditWarranty(item) {
  if (!canManageWarranties || warrantyDeletingId.value !== null) return
  editingWarrantyId.value = item.id
  warrantyForm.value = {
    warranty_type: item.warranty_type,
    order_part: item.order_part ?? '',
    is_applicable: item.is_applicable,
    starts_on: item.starts_on ?? '',
    ends_on: item.ends_on ?? '',
    conditions: item.conditions ?? '',
    change_note: '',
  }
  warrantyFormError.value = ''
  warrantySuccess.value = ''
}

function warrantyBadgeClass(status) {
  if (status === 'ACTIVE') return 'bg-success'
  if (status === 'EXPIRED') return 'bg-secondary'
  if (status === 'NOT_STARTED') return 'bg-info text-dark'
  return 'bg-light text-dark border'
}

// DateField devuelve YYYY-MM-DD; no usamos UTC para evitar desplazar el día.
function formatWarrantyDate(value) {
  if (!value) return 'No aplica'
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value)
  return match ? `${match[3]}-${match[2]}-${match[1]}` : value
}

function warrantyPartDescription(id) {
  const usage = usedParts.value.find((item) => Number(item.id) === Number(id))
  return usage ? `${usage.part_name} · ${usage.supplier_name}` : `Uso de repuesto #${id}`
}

function warrantyRequestCount(warrantyId) {
  return warrantyRequests.value.filter(
    (item) => Number(item.warranty) === Number(warrantyId)
  ).length
}

function warrantyHasRequests(warrantyId) {
  return warrantyRequestCount(warrantyId) > 0
}

function warrantyRequestStatusBadgeClass(status) {
  if (status === 'PENDING') return 'bg-warning text-dark'
  if (status === 'AWAITING_APPROVAL') return 'bg-info text-dark'
  if (status === 'CHANGES_REQUESTED') return 'bg-warning text-dark'
  if (status === 'RESOLVED') return 'bg-success'
  return 'bg-secondary'
}

async function loadWarranties() {
  if (!order.value || !canViewWarranties) return
  const orderId = order.value.id
  const sequence = loadSequence
  const requestId = ++warrantyRequestId
  const isCurrent = () => sequence === loadSequence && requestId === warrantyRequestId
  warrantyLoading.value = true
  warrantyError.value = ''

  try {
    const response = await getResponse(`/api/orders/${orderId}/warranties/`)
    if (!isCurrent()) return
    if (!response.ok) {
      throw new Error(evidenceApiError(response.data, 'No fue posible consultar las garantías.'))
    }
    const data = response.data
    warranties.value = Array.isArray(data) ? data : (data?.results || [])
    if (editingWarrantyId.value === null && serviceWarrantyExists.value && warrantyForm.value.warranty_type === 'SERVICE') {
      warrantyForm.value.warranty_type = 'PART'
    }

    const selectedRequestWarrantyStillExists = warranties.value.some(
      (item) => Number(item.id) === Number(warrantyRequestForm.value.warranty)
    )
    if (!selectedRequestWarrantyStillExists) {
      const preferredWarranty =
        warranties.value.find((item) => ['ACTIVE', 'EXPIRED'].includes(item.status)) ||
        warranties.value[0] ||
        null
      warrantyRequestForm.value.warranty = preferredWarranty?.id ?? ''
      warrantyRequestForm.value.concurrent_open_reason = ''
    }
  } catch (err) {
    if (isCurrent()) {
      warranties.value = []
      warrantyError.value = err?.message || 'Error al cargar las garantías.'
    }
  } finally {
    if (isCurrent()) warrantyLoading.value = false
  }
}

async function loadWarrantyHistory(warrantyId) {
  if (!order.value || !canViewWarranties) return
  const orderId = order.value.id
  const sequence = loadSequence
  const requestId = ++warrantyHistoryRequestId
  warrantyHistoryLatestById[warrantyId] = requestId
  const isCurrent = () => sequence === loadSequence && warrantyHistoryLatestById[warrantyId] === requestId
  warrantyHistoryLoading.value = { ...warrantyHistoryLoading.value, [warrantyId]: true }
  warrantyHistoryErrors.value = { ...warrantyHistoryErrors.value, [warrantyId]: '' }

  try {
    const response = await getResponse(`/api/orders/${orderId}/warranties/${warrantyId}/history/`)
    if (!isCurrent()) return
    if (!response.ok) {
      throw new Error(evidenceApiError(response.data, 'No fue posible consultar las revisiones.'))
    }
    const data = response.data
    warrantyHistoryById.value = {
      ...warrantyHistoryById.value,
      [warrantyId]: Array.isArray(data) ? data : (data?.results || []),
    }
  } catch (err) {
    if (isCurrent()) {
      warrantyHistoryErrors.value = {
        ...warrantyHistoryErrors.value,
        [warrantyId]: err?.message || 'Error al cargar las revisiones.',
      }
    }
  } finally {
    if (isCurrent()) {
      warrantyHistoryLoading.value = { ...warrantyHistoryLoading.value, [warrantyId]: false }
    }
  }
}

async function toggleWarrantyHistory(warrantyId) {
  if (expandedWarrantyHistoryId.value === warrantyId) {
    expandedWarrantyHistoryId.value = null
    return
  }
  expandedWarrantyHistoryId.value = warrantyId
  await loadWarrantyHistory(warrantyId)
}

async function saveWarranty() {
  if (!order.value || !canManageWarranties || warrantySaving.value || warrantyLoading.value || warrantyDeletingId.value !== null) return
  warrantyFormError.value = ''
  warrantySuccess.value = ''

  const form = warrantyForm.value
  const editing = editingWarrantyId.value !== null
  const conditions = String(form.conditions ?? '').trim()
  const changeNote = String(form.change_note ?? '').trim()
  const partId = Number(form.order_part)

  if (!editing && form.warranty_type === 'SERVICE' && serviceWarrantyExists.value) {
    warrantyFormError.value = 'Esta orden ya tiene garantía del servicio. Selecciona Modificar en su registro.'
    return
  }
  if (!editing && form.warranty_type === 'PART' &&
      (!partId || !availableWarrantyParts.value.some((item) => Number(item.id) === partId))) {
    warrantyFormError.value = 'Selecciona un repuesto utilizado en esta orden y sin garantía registrada.'
    return
  }
  if (form.is_applicable) {
    if (!form.starts_on || !form.ends_on) {
      warrantyFormError.value = 'Completa las fechas de inicio y término.'
      return
    }
    if (form.ends_on < form.starts_on) {
      warrantyFormError.value = 'La fecha de término no puede ser anterior a la de inicio.'
      return
    }
    if (!conditions) {
      warrantyFormError.value = 'Indica las condiciones de la garantía.'
      return
    }
  }
  if (editing && !changeNote) {
    warrantyFormError.value = 'Indica el motivo de la modificación para conservar la trazabilidad.'
    return
  }

  const orderId = order.value.id
  const sequence = loadSequence
  const payload = {
    is_applicable: Boolean(form.is_applicable),
    starts_on: form.is_applicable ? form.starts_on : null,
    ends_on: form.is_applicable ? form.ends_on : null,
    conditions,
  }
  if (editing) {
    payload.change_note = changeNote
  } else {
    payload.warranty_type = form.warranty_type
    payload.order_part = form.warranty_type === 'PART' ? partId : null
  }

  warrantySaving.value = true
  try {
    const url = editing
      ? `/api/orders/${orderId}/warranties/${editingWarrantyId.value}/`
      : `/api/orders/${orderId}/warranties/`
    const response = await authenticatedFetch(url, {
      method: editing ? 'PATCH' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
    const data = await response.json().catch(() => null)
    if (sequence !== loadSequence) return
    if (!response.ok) {
      throw new Error(evidenceApiError(data, 'No fue posible guardar la garantía.'))
    }

    await loadWarranties()
    if (sequence !== loadSequence) return
    resetWarrantyForm()
    warrantySuccess.value = editing
      ? 'Garantía actualizada y nueva revisión registrada.'
      : 'Garantía registrada con su primera revisión.'
    expandedWarrantyHistoryId.value = data.id
    await loadWarrantyHistory(data.id)
  } catch (err) {
    if (sequence === loadSequence) {
      warrantyFormError.value = err?.message || 'Error al guardar la garantía.'
    }
  } finally {
    if (sequence === loadSequence) warrantySaving.value = false
  }
}


// HU-21: eliminación segura de una garantía ingresada por error.
async function deleteWarranty(item) {
  if (
    !order.value ||
    !canManageWarranties ||
    warrantyDeletingId.value !== null ||
    warrantySaving.value ||
    warrantyLoading.value
  ) {
    return
  }

  if (warrantyHasRequests(item.id)) {
    warrantyError.value =
      'No se puede eliminar esta garantía porque tiene solicitudes asociadas. ' +
      'La trazabilidad de esos reclamos debe conservarse.'
    return
  }

  const warrantyLabel =
    item.warranty_type_display ||
    (
      item.warranty_type === 'SERVICE'
        ? 'Garantía del servicio'
        : 'Garantía de repuesto'
    )

  const confirmed = window.confirm(
    `¿Eliminar ${warrantyLabel} #${item.id}?\n\n` +
    'Esta acción eliminará solamente la garantía seleccionada. ' +
    'La orden, cliente, equipo, repuestos y proveedor asociados se conservarán.'
  )

  if (!confirmed) return

  const orderId = order.value.id
  const sequence = loadSequence

  warrantyDeletingId.value = item.id
  warrantyError.value = ''
  warrantyFormError.value = ''
  warrantySuccess.value = ''

  try {
    const response = await authenticatedFetch(
      `/api/orders/${orderId}/warranties/${item.id}/`,
      {
        method: 'DELETE',
      }
    )

    if (sequence !== loadSequence) return

    if (!response.ok) {
      const data = await response.json().catch(() => null)

      throw new Error(
        evidenceApiError(
          data,
          'No fue posible eliminar la garantía.'
        )
      )
    }

    expandedWarrantyHistoryId.value = null

    await loadWarranties()

    if (sequence !== loadSequence) return

    resetWarrantyForm()

    warrantySuccess.value =
      'Garantía eliminada correctamente. ' +
      'La orden y sus registros relacionados se conservaron.'
  } catch (err) {
    if (sequence === loadSequence) {
      warrantyError.value =
        err?.message ||
        'Error al eliminar la garantía.'
    }
  } finally {
    if (sequence === loadSequence) {
      warrantyDeletingId.value = null
    }
  }
}


// HU-22: solicitudes de garantía e historial de cada reclamo.
function releaseWarrantyRequestImages() {
  ++warrantyClaimImageRequestId
  Object.values(warrantyRequestImageUrls.value).forEach((url) => URL.revokeObjectURL(url))
  warrantyRequestImageUrls.value = {}
  warrantyRequestImageFilenames.value = {}
  warrantyRequestImageLoading.value = {}
  warrantyRequestImageErrors.value = {}
}

function resetWarrantyRequests() {
  ++warrantyClaimRequestId
  ++warrantyClaimHistoryRequestId
  releaseWarrantyRequestImages()
  warrantyClaimHistoryLatestById = {}
  warrantyRequests.value = []
  warrantyRequestsLoading.value = false
  warrantyRequestsError.value = ''
  warrantyRequestSaving.value = false
  warrantyRequestFormError.value = ''
  warrantyRequestSuccess.value = ''
  warrantyRequestHistoryById.value = {}
  warrantyRequestHistoryLoading.value = {}
  warrantyRequestHistoryErrors.value = {}
  expandedWarrantyRequestHistoryId.value = null
  warrantyRequestForm.value = emptyWarrantyRequestForm()

  warrantyRequestActionSavingId.value = null
  warrantyRequestActionErrors.value = {}
  warrantyRequestActionSuccess.value = {}
  warrantyProposalForms.value = {}
  warrantyResolutionForms.value = {}
  warrantyReturnForms.value = {}
  warrantyAdminNoteForms.value = {}

  if (warrantyRequestFileInput.value) warrantyRequestFileInput.value.value = ''
}

async function toggleWarrantyRequestImage(item) {
  const id = item.id
  if (warrantyRequestImageUrls.value[id]) {
    URL.revokeObjectURL(warrantyRequestImageUrls.value[id])
    const urls = { ...warrantyRequestImageUrls.value }
    delete urls[id]
    warrantyRequestImageUrls.value = urls
    const filenames = { ...warrantyRequestImageFilenames.value }
    delete filenames[id]
    warrantyRequestImageFilenames.value = filenames
    return
  }
  if (warrantyRequestImageLoading.value[id] || !order.value || !item.evidence_download_url) return

  const requestId = warrantyClaimImageRequestId
  const orderId = order.value.id
  warrantyRequestImageLoading.value = { ...warrantyRequestImageLoading.value, [id]: true }
  warrantyRequestImageErrors.value = { ...warrantyRequestImageErrors.value, [id]: '' }

  try {
    const response = await authenticatedFetch(item.evidence_download_url)
    if (!response.ok) throw new Error('No fue posible recuperar la fotografía.')
    const blob = await response.blob()
    const extension = {
      'image/jpeg': 'jpg',
      'image/png': 'png',
      'image/webp': 'webp',
    }[blob.type]
    if (!extension) {
      throw new Error('El servidor no devolvió una imagen válida.')
    }
    if (requestId !== warrantyClaimImageRequestId || order.value?.id !== orderId) return
    warrantyRequestImageUrls.value = {
      ...warrantyRequestImageUrls.value,
      [id]: URL.createObjectURL(blob),
    }
    warrantyRequestImageFilenames.value = {
      ...warrantyRequestImageFilenames.value,
      [id]: `solicitud-garantia-${id}.${extension}`,
    }
  } catch (err) {
    if (requestId === warrantyClaimImageRequestId && order.value?.id === orderId) {
      warrantyRequestImageErrors.value = {
        ...warrantyRequestImageErrors.value,
        [id]: err?.message || 'Error al abrir la fotografía.',
      }
    }
  } finally {
    if (requestId === warrantyClaimImageRequestId && order.value?.id === orderId) {
      warrantyRequestImageLoading.value = { ...warrantyRequestImageLoading.value, [id]: false }
    }
  }
}

async function loadWarrantyRequests() {
  if (!order.value || !canViewWarranties) return

  const orderId = order.value.id
  const sequence = loadSequence
  const requestId = ++warrantyClaimRequestId
  const isCurrent = () =>
    sequence === loadSequence &&
    requestId === warrantyClaimRequestId

  warrantyRequestsLoading.value = true
  warrantyRequestsError.value = ''

  try {
    const response = await getResponse(
      `/api/orders/${orderId}/warranty-requests/`
    )

    if (!isCurrent()) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(
          response.data,
          'No fue posible consultar las solicitudes de garantía.'
        )
      )
    }

    const data = response.data
    const requestItems = Array.isArray(data)
      ? data
      : (data?.results || [])

    ensureWarrantyRequestActionForms(requestItems)
    warrantyRequests.value = requestItems
  } catch (err) {
    if (isCurrent()) {
      warrantyRequests.value = []
      warrantyRequestsError.value =
        err?.message ||
        'Error al cargar las solicitudes de garantía.'
    }
  } finally {
    if (isCurrent()) warrantyRequestsLoading.value = false
  }
}

async function loadWarrantyRequestHistory(requestId) {
  if (!order.value || !canViewWarranties) return

  const orderId = order.value.id
  const sequence = loadSequence
  const historyRequestId = ++warrantyClaimHistoryRequestId
  warrantyClaimHistoryLatestById[requestId] = historyRequestId
  const isCurrent = () =>
    sequence === loadSequence &&
    warrantyClaimHistoryLatestById[requestId] === historyRequestId

  warrantyRequestHistoryLoading.value = {
    ...warrantyRequestHistoryLoading.value,
    [requestId]: true,
  }
  warrantyRequestHistoryErrors.value = {
    ...warrantyRequestHistoryErrors.value,
    [requestId]: '',
  }

  try {
    const response = await getResponse(
      `/api/orders/${orderId}/warranty-requests/${requestId}/history/`
    )

    if (!isCurrent()) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(
          response.data,
          'No fue posible consultar el historial de la solicitud.'
        )
      )
    }

    const data = response.data
    warrantyRequestHistoryById.value = {
      ...warrantyRequestHistoryById.value,
      [requestId]: Array.isArray(data)
        ? data
        : (data?.results || []),
    }
  } catch (err) {
    if (isCurrent()) {
      warrantyRequestHistoryErrors.value = {
        ...warrantyRequestHistoryErrors.value,
        [requestId]:
          err?.message ||
          'Error al cargar el historial de la solicitud.',
      }
    }
  } finally {
    if (isCurrent()) {
      warrantyRequestHistoryLoading.value = {
        ...warrantyRequestHistoryLoading.value,
        [requestId]: false,
      }
    }
  }
}

async function toggleWarrantyRequestHistory(requestId) {
  if (expandedWarrantyRequestHistoryId.value === requestId) {
    expandedWarrantyRequestHistoryId.value = null
    return
  }

  expandedWarrantyRequestHistoryId.value = requestId
  await loadWarrantyRequestHistory(requestId)
}

async function selectWarrantyForRequest(item) {
  warrantyRequestForm.value = {
    ...emptyWarrantyRequestForm(),
    warranty: item.id,
  }
  warrantyRequestFormError.value = ''
  warrantyRequestSuccess.value = ''

  await nextTick()
  document.getElementById('warranty-request-problem')?.focus()
}

function selectWarrantyRequestEvidence(event) {
  warrantyRequestForm.value.evidence =
    event.target.files?.[0] || null
  warrantyRequestFormError.value = ''
  warrantyRequestSuccess.value = ''
}

async function saveWarrantyRequest() {
  if (
    !order.value ||
    !canManageWarranties ||
    warrantyRequestSaving.value ||
    warrantyRequestsLoading.value
  ) {
    return
  }

  warrantyRequestFormError.value = ''
  warrantyRequestSuccess.value = ''

  const warranty = selectedWarrantyForRequest.value
  if (!warranty) {
    warrantyRequestFormError.value =
      'Selecciona la garantía asociada a la solicitud.'
    return
  }

  if (warrantyRequestBlockedReason.value) {
    warrantyRequestFormError.value =
      warrantyRequestBlockedReason.value
    return
  }

  const description = String(
    warrantyRequestForm.value.problem_description ?? ''
  ).trim()

  if (!description) {
    warrantyRequestFormError.value =
      'Describe el problema reportado por el cliente.'
    return
  }

  const concurrentReason = String(
    warrantyRequestForm.value.concurrent_open_reason ?? ''
  ).trim()

  if (openWarrantyRequestExists.value && !concurrentReason) {
    warrantyRequestFormError.value =
      'Ya existe una solicitud abierta para esta garantía. ' +
      'Indica el motivo para registrar otra.'
    return
  }

  const file = warrantyRequestForm.value.evidence
  if (file) {
    if (!/\.(jpe?g|png|webp)$/i.test(file.name)) {
      warrantyRequestFormError.value =
        'La evidencia debe ser JPG, JPEG, PNG o WEBP.'
      return
    }

    if (file.size > maxEvidenceSize) {
      warrantyRequestFormError.value =
        'La evidencia no puede superar los 20 MB.'
      return
    }
  }

  const orderId = order.value.id
  const sequence = loadSequence
  const selectedWarrantyId = warranty.id
  const formData = new FormData()

  formData.append('warranty', String(selectedWarrantyId))
  formData.append(
    'requested_on',
    warrantyRequestForm.value.requested_on || localDateInputValue()
  )
  formData.append('problem_description', description)

  if (concurrentReason) {
    formData.append('concurrent_open_reason', concurrentReason)
  }

  if (file) {
    formData.append('evidence', file)
  }

  warrantyRequestSaving.value = true

  try {
    // No se fija Content-Type: el navegador agrega el boundary multipart.
    const response = await authenticatedFetch(
      `/api/orders/${orderId}/warranty-requests/`,
      {
        method: 'POST',
        body: formData,
      }
    )
    const data = await response.json().catch(() => null)

    if (sequence !== loadSequence) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(
          data,
          'No fue posible registrar la solicitud de garantía.'
        )
      )
    }

    await loadWarrantyRequests()
    if (sequence !== loadSequence) return

    warrantyRequestForm.value = {
      ...emptyWarrantyRequestForm(),
      warranty: selectedWarrantyId,
    }

    if (warrantyRequestFileInput.value) {
      warrantyRequestFileInput.value.value = ''
    }

    warrantyRequestSuccess.value = data?.coverage_warning
      ? `Solicitud #${data.id} registrada. ${data.coverage_warning}`
      : `Solicitud #${data.id} registrada correctamente.`

    expandedWarrantyRequestHistoryId.value = data.id
    await loadWarrantyRequestHistory(data.id)
  } catch (err) {
    if (sequence === loadSequence) {
      warrantyRequestFormError.value =
        err?.message ||
        'Error al registrar la solicitud de garantía.'
    }
  } finally {
    if (sequence === loadSequence) {
      warrantyRequestSaving.value = false
    }
  }
}


// HU-23: flujo de resolución de solicitudes de garantía.
async function refreshWarrantyRequestAfterAction(requestId) {
  await loadWarrantyRequests()

  expandedWarrantyRequestHistoryId.value = requestId
  await loadWarrantyRequestHistory(requestId)
}

async function submitWarrantyProposal(requestItem) {
  if (
    !order.value ||
    !canProposeWarrantyResolution ||
    isWarrantyRequestActionSaving(requestItem.id)
  ) {
    return
  }

  if (!['PENDING', 'CHANGES_REQUESTED'].includes(requestItem.status)) {
    setWarrantyRequestActionError(
      requestItem.id,
      'La solicitud ya no está disponible para enviar una propuesta técnica.'
    )
    return
  }

  const form =
    warrantyProposalForms.value[requestItem.id] ||
    emptyWarrantyProposalForm(requestItem)

  const technicalRationale = String(form.technical_rationale ?? '').trim()
  const actionType = String(form.action_type ?? '').trim()
  const actionDescription = String(form.action_description ?? '').trim()

  clearWarrantyRequestActionMessages(requestItem.id)

  if (!technicalRationale) {
    setWarrantyRequestActionError(
      requestItem.id,
      'El fundamento técnico es obligatorio.'
    )
    return
  }

  if (!['REPAIR', 'PART_REPLACEMENT', 'OTHER'].includes(actionType)) {
    setWarrantyRequestActionError(
      requestItem.id,
      'Selecciona la acción propuesta.'
    )
    return
  }

  if (!actionDescription) {
    setWarrantyRequestActionError(
      requestItem.id,
      'Describe la acción propuesta.'
    )
    return
  }

  const sequence = loadSequence
  const orderId = order.value.id
  warrantyRequestActionSavingId.value = requestItem.id

  try {
    const response = await authenticatedFetch(
      `/api/orders/${orderId}/warranty-requests/${requestItem.id}/proposal/`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          technical_rationale: technicalRationale,
          action_type: actionType,
          action_description: actionDescription,
        }),
      }
    )

    const data = await response.json().catch(() => null)

    if (sequence !== loadSequence) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(
          data,
          'No fue posible enviar la propuesta técnica.'
        )
      )
    }

    warrantyProposalForms.value = {
      ...warrantyProposalForms.value,
      [requestItem.id]: emptyWarrantyProposalForm(),
    }

    await refreshWarrantyRequestAfterAction(requestItem.id)

    if (sequence !== loadSequence) return

    setWarrantyRequestActionSuccess(
      requestItem.id,
      data?.proposal?.revision
        ? `Propuesta técnica #${data.proposal.revision} enviada para aprobación.`
        : 'Propuesta técnica enviada para aprobación.'
    )
  } catch (err) {
    if (sequence === loadSequence) {
      setWarrantyRequestActionError(
        requestItem.id,
        err?.message || 'Error al enviar la propuesta técnica.'
      )
    }
  } finally {
    if (
      sequence === loadSequence &&
      isWarrantyRequestActionSaving(requestItem.id)
    ) {
      warrantyRequestActionSavingId.value = null
    }
  }
}

async function returnWarrantyRequestToTech(requestItem) {
  if (
    !order.value ||
    !canAdminResolveWarrantyRequest ||
    isWarrantyRequestActionSaving(requestItem.id)
  ) {
    return
  }

  if (requestItem.status !== 'AWAITING_APPROVAL') {
    setWarrantyRequestActionError(
      requestItem.id,
      'Solo se puede devolver una solicitud pendiente de aprobación.'
    )
    return
  }

  const form =
    warrantyReturnForms.value[requestItem.id] ||
    emptyWarrantyReturnForm()

  const reason = String(form.reason ?? '').trim()

  clearWarrantyRequestActionMessages(requestItem.id)

  if (!reason) {
    setWarrantyRequestActionError(
      requestItem.id,
      'Indica el motivo de la devolución al técnico.'
    )
    return
  }

  const sequence = loadSequence
  const orderId = order.value.id
  warrantyRequestActionSavingId.value = requestItem.id

  try {
    const response = await authenticatedFetch(
      `/api/orders/${orderId}/warranty-requests/${requestItem.id}/return/`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
      }
    )

    const data = await response.json().catch(() => null)

    if (sequence !== loadSequence) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(
          data,
          'No fue posible devolver la solicitud al técnico.'
        )
      )
    }

    warrantyReturnForms.value = {
      ...warrantyReturnForms.value,
      [requestItem.id]: emptyWarrantyReturnForm(),
    }

    await refreshWarrantyRequestAfterAction(requestItem.id)

    if (sequence !== loadSequence) return

    setWarrantyRequestActionSuccess(
      requestItem.id,
      'Solicitud devuelta al técnico para correcciones.'
    )
  } catch (err) {
    if (sequence === loadSequence) {
      setWarrantyRequestActionError(
        requestItem.id,
        err?.message || 'Error al devolver la solicitud.'
      )
    }
  } finally {
    if (
      sequence === loadSequence &&
      isWarrantyRequestActionSaving(requestItem.id)
    ) {
      warrantyRequestActionSavingId.value = null
    }
  }
}

async function resolveWarrantyRequest(requestItem) {
  if (
    !order.value ||
    !canAdminResolveWarrantyRequest ||
    isWarrantyRequestActionSaving(requestItem.id)
  ) {
    return
  }

  if (requestItem.status === 'RESOLVED') {
    setWarrantyRequestActionError(
      requestItem.id,
      'La solicitud ya fue resuelta.'
    )
    return
  }

  const form =
    warrantyResolutionForms.value[requestItem.id] ||
    emptyWarrantyResolutionForm(requestItem)

  const decision = String(form.decision ?? '').trim()
  const rationale = String(form.rationale ?? '').trim()
  const actionType = String(form.action_type ?? '').trim()
  const actionDescription = String(form.action_description ?? '').trim()

  clearWarrantyRequestActionMessages(requestItem.id)

  if (!['ACCEPTED', 'REJECTED'].includes(decision)) {
    setWarrantyRequestActionError(
      requestItem.id,
      'Selecciona si la solicitud será aceptada o rechazada.'
    )
    return
  }

  if (!rationale) {
    setWarrantyRequestActionError(
      requestItem.id,
      'El fundamento de la decisión es obligatorio.'
    )
    return
  }

  if (decision === 'ACCEPTED') {
    if (!['REPAIR', 'PART_REPLACEMENT', 'OTHER'].includes(actionType)) {
      setWarrantyRequestActionError(
        requestItem.id,
        'Indica la acción realizada o autorizada.'
      )
      return
    }

    if (!actionDescription) {
      setWarrantyRequestActionError(
        requestItem.id,
        'Describe la acción realizada o autorizada.'
      )
      return
    }
  }

  const sequence = loadSequence
  const orderId = order.value.id
  warrantyRequestActionSavingId.value = requestItem.id

  const payload = {
    decision,
    rationale,
  }

  if (decision === 'ACCEPTED') {
    payload.action_type = actionType
    payload.action_description = actionDescription
  }

  try {
    const response = await authenticatedFetch(
      `/api/orders/${orderId}/warranty-requests/${requestItem.id}/resolve/`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }
    )

    const data = await response.json().catch(() => null)

    if (sequence !== loadSequence) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(
          data,
          'No fue posible registrar la resolución administrativa.'
        )
      )
    }

    warrantyResolutionForms.value = {
      ...warrantyResolutionForms.value,
      [requestItem.id]: emptyWarrantyResolutionForm(),
    }

    await refreshWarrantyRequestAfterAction(requestItem.id)

    if (sequence !== loadSequence) return

    setWarrantyRequestActionSuccess(
      requestItem.id,
      decision === 'ACCEPTED'
        ? 'Solicitud aceptada y resolución final registrada.'
        : 'Solicitud rechazada y resolución final registrada.'
    )
  } catch (err) {
    if (sequence === loadSequence) {
      setWarrantyRequestActionError(
        requestItem.id,
        err?.message || 'Error al resolver la solicitud.'
      )
    }
  } finally {
    if (
      sequence === loadSequence &&
      isWarrantyRequestActionSaving(requestItem.id)
    ) {
      warrantyRequestActionSavingId.value = null
    }
  }
}

async function addWarrantyRequestAdminNote(requestItem) {
  if (
    !order.value ||
    !canAdminResolveWarrantyRequest ||
    isWarrantyRequestActionSaving(requestItem.id)
  ) {
    return
  }

  if (requestItem.status !== 'RESOLVED') {
    setWarrantyRequestActionError(
      requestItem.id,
      'Las observaciones administrativas solo se agregan a solicitudes resueltas.'
    )
    return
  }

  const form =
    warrantyAdminNoteForms.value[requestItem.id] ||
    emptyWarrantyAdminNoteForm()

  const observation = String(form.observation ?? '').trim()

  clearWarrantyRequestActionMessages(requestItem.id)

  if (!observation) {
    setWarrantyRequestActionError(
      requestItem.id,
      'La observación administrativa es obligatoria.'
    )
    return
  }

  const sequence = loadSequence
  const orderId = order.value.id
  warrantyRequestActionSavingId.value = requestItem.id

  try {
    const response = await authenticatedFetch(
      `/api/orders/${orderId}/warranty-requests/${requestItem.id}/admin-note/`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ observation }),
      }
    )

    const data = await response.json().catch(() => null)

    if (sequence !== loadSequence) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(
          data,
          'No fue posible registrar la observación administrativa.'
        )
      )
    }

    warrantyAdminNoteForms.value = {
      ...warrantyAdminNoteForms.value,
      [requestItem.id]: emptyWarrantyAdminNoteForm(),
    }

    await refreshWarrantyRequestAfterAction(requestItem.id)

    if (sequence !== loadSequence) return

    setWarrantyRequestActionSuccess(
      requestItem.id,
      'Observación administrativa agregada al historial.'
    )
  } catch (err) {
    if (sequence === loadSequence) {
      setWarrantyRequestActionError(
        requestItem.id,
        err?.message || 'Error al registrar la observación.'
      )
    }
  } finally {
    if (
      sequence === loadSequence &&
      isWarrantyRequestActionSaving(requestItem.id)
    ) {
      warrantyRequestActionSavingId.value = null
    }
  }
}


// HU-16: evaluación manual e índice de viabilidad calculado por Django.
const viability = ref(null)
const viabilityLoading = ref(false)
const viabilityError = ref('')
const viabilitySaving = ref(false)
const viabilityFormError = ref('')
const viabilitySuccess = ref('')
let viabilityRequestId = 0

const emptyViabilityForm = () => ({
  difficulty: '',
  warranty_risk: '',
  notes: '',
})

const viabilityForm = ref(emptyViabilityForm())

const viabilityMissingLabels = {
  difficulty: 'Dificultad técnica',
  warranty_risk: 'Riesgo de garantía',
  margin: 'Margen estimado',
  time: 'Tiempo técnico',
  parts: 'Disponibilidad de repuestos',
}

const viabilitySaveLabel = computed(() => {
  if (viabilitySaving.value) return 'Guardando...'
  return viability.value?.assessment
    ? 'Guardar y recalcular'
    : 'Registrar evaluación y calcular'
})

function resetViability() {
  ++viabilityRequestId
  viability.value = null
  viabilityLoading.value = false
  viabilityError.value = ''
  viabilitySaving.value = false
  viabilityFormError.value = ''
  viabilitySuccess.value = ''
  viabilityForm.value = emptyViabilityForm()
}

function syncViabilityForm(data) {
  const assessment = data?.assessment

  if (!assessment) {
    viabilityForm.value = emptyViabilityForm()
    return
  }

  viabilityForm.value = {
    difficulty: assessment.difficulty || '',
    warranty_risk: assessment.warranty_risk || '',
    notes: assessment.notes || '',
  }
}

function viabilityLevelClass(level) {
  if (level === 'HIGH') return 'bg-success'
  if (level === 'MEDIUM') return 'bg-warning text-dark'
  if (level === 'LOW') return 'bg-danger'
  return 'bg-secondary'
}

function viabilityFactorWidth(factor) {
  if (factor?.score === null || factor?.score === undefined) return '0%'

  const maxScore = Number(factor.max_score || 0)

  if (!maxScore) return '0%'

  const percentage = (
    Number(factor.score) / maxScore
  ) * 100

  return `${Math.max(0, Math.min(100, percentage))}%`
}

function viabilityMissingLabel(key) {
  return viabilityMissingLabels[key] || key
}

function viabilityMissingActionLabel(key) {
  if (key === 'difficulty' || key === 'warranty_risk') {
    return 'Completar'
  }

  if (key === 'margin') {
    return canEditFinancial
      ? 'Completar datos financieros'
      : 'Revisar datos financieros'
  }

  if (key === 'parts') {
    return 'Ir a repuestos'
  }

  if (key === 'time') {
    return 'Revisar línea de tiempo'
  }

  return 'Revisar'
}

async function focusElement(elementId) {
  await nextTick()

  const element = document.getElementById(elementId)

  if (!element) return

  element.scrollIntoView({
    behavior: 'smooth',
    block: 'center',
  })

  window.setTimeout(() => {
    element.focus({
      preventScroll: true,
    })
  }, 350)
}

async function goToViabilityMissingFactor(key) {
  viabilityFormError.value = ''
  viabilitySuccess.value = ''

  if (key === 'difficulty') {
    await focusElement('viability-difficulty')
    return
  }

  if (key === 'warranty_risk') {
    await focusElement('viability-warranty-risk')
    return
  }

  if (key === 'margin') {
    tab.value = 'repuestos'

    await refreshPartsAndFinancial()
    await nextTick()

    if (canEditFinancial) {
      await focusElement('financial-price')
    }

    return
  }

  if (key === 'parts') {
    tab.value = 'repuestos'

    await loadOrderParts()
    await focusElement('order-part-select')
    return
  }

  if (key === 'time') {
    tab.value = 'linea'

    await refreshOrderTracking()
    await nextTick()

    document.querySelector('.section-tabs')?.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    })
  }
}

async function loadViability() {
  if (!order.value || !canViewViability) return

  const orderId = order.value.id
  const sequence = loadSequence
  const requestId = ++viabilityRequestId
  const isCurrent = () => (
    sequence === loadSequence
    && requestId === viabilityRequestId
  )

  viabilityLoading.value = true
  viabilityError.value = ''
  viabilitySuccess.value = ''

  try {
    const response = await getResponse(
      `/api/orders/${orderId}/viability/`
    )

    if (!isCurrent()) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(
          response.data,
          'No fue posible consultar el índice de viabilidad.'
        )
      )
    }

    viability.value = response.data
    syncViabilityForm(response.data)
  } catch (err) {
    if (isCurrent()) {
      viability.value = null
      viabilityError.value = (
        err?.message
        || 'Error al consultar el índice de viabilidad.'
      )
    }
  } finally {
    if (isCurrent()) viabilityLoading.value = false
  }
}

async function saveViability() {
  if (
    !order.value
    || !canManageViability
    || viabilitySaving.value
    || viabilityLoading.value
  ) {
    return
  }

  viabilityFormError.value = ''
  viabilitySuccess.value = ''

  const difficulty = viabilityForm.value.difficulty
  const warrantyRisk = viabilityForm.value.warranty_risk

  if (!['LOW', 'MEDIUM', 'HIGH'].includes(difficulty)) {
    viabilityFormError.value = 'Selecciona la dificultad técnica.'
    return
  }

  if (!['LOW', 'MEDIUM', 'HIGH'].includes(warrantyRisk)) {
    viabilityFormError.value = 'Selecciona el riesgo de garantía.'
    return
  }

  const orderId = order.value.id
  const sequence = loadSequence
  viabilitySaving.value = true

  try {
    const response = await authenticatedFetch(
      `/api/orders/${orderId}/viability/`,
      {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          difficulty,
          warranty_risk: warrantyRisk,
          notes: String(
            viabilityForm.value.notes ?? ''
          ).trim(),
        }),
      }
    )

    const data = await response.json().catch(() => null)

    if (sequence !== loadSequence) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(
          data,
          'No fue posible guardar la evaluación de viabilidad.'
        )
      )
    }

    viability.value = data
    viabilityError.value = ''
    syncViabilityForm(data)
    viabilitySuccess.value = (
      'Evaluación guardada e índice recalculado correctamente.'
    )
  } catch (err) {
    if (sequence === loadSequence) {
      viabilityFormError.value = (
        err?.message
        || 'Error al guardar la evaluación de viabilidad.'
      )
    }
  } finally {
    if (sequence === loadSequence) viabilitySaving.value = false
  }
}

function formatMoney(value) {
  return new Intl.NumberFormat('es-CL', {
    style: 'currency',
    currency: 'CLP',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(Number(value) || 0)
}

function resetOrderParts() {
  ++orderPartsRequestId
  ++orderPartCorrectionHistoryRequestId
  orderPartCorrectionHistoryLatestById = {}
  usedParts.value = []
  partCatalog.value = []
  orderPartsLoading.value = false
  orderPartsError.value = ''
  partCatalogError.value = ''
  orderPartSaving.value = false
  orderPartFormError.value = ''
  orderPartSuccess.value = ''
  orderPartForm.value = emptyOrderPartForm()
  orderPartCorrectionOpenId.value = null
  orderPartCorrectionForms.value = {}
  orderPartCorrectionSavingId.value = null
  orderPartCorrectionErrors.value = {}
  orderPartCorrectionSuccess.value = {}
  orderPartCorrectionHistoryById.value = {}
  orderPartCorrectionHistoryLoading.value = {}
  orderPartCorrectionHistoryErrors.value = {}
  expandedOrderPartCorrectionHistoryId.value = null
  orderPartCancellationOpenId.value = null
  orderPartCancellationForms.value = {}
  orderPartCancellationSavingId.value = null
  orderPartCancellationErrors.value = {}
  orderPartCancellationSuccess.value = {}
}

async function loadOrderParts() {
  if (!order.value) return

  const orderId = order.value.id
  const sequence = loadSequence
  const requestId = ++orderPartsRequestId
  orderPartsLoading.value = true
  orderPartsError.value = ''
  partCatalogError.value = ''

  const isCurrent = () => sequence === loadSequence && requestId === orderPartsRequestId

  try {
    const [usageResult, catalogResult] = await Promise.allSettled([
      getResponse(`/api/inventory/orders/${orderId}/parts/`),
      getResponse('/api/inventory/parts/'),
    ])
    if (!isCurrent()) return

    if (usageResult.status === 'fulfilled' && usageResult.value.ok) {
      const data = usageResult.value.data
      usedParts.value = Array.isArray(data) ? data : (data?.results || [])
    } else {
      usedParts.value = []
      orderPartsError.value = usageResult.status === 'fulfilled'
        ? evidenceApiError(usageResult.value.data, 'No fue posible cargar los repuestos utilizados.')
        : (usageResult.reason?.message || 'No fue posible cargar los repuestos utilizados.')
    }

    if (catalogResult.status === 'fulfilled' && catalogResult.value.ok) {
      const data = catalogResult.value.data
      partCatalog.value = Array.isArray(data) ? data : (data?.results || [])
    } else {
      partCatalog.value = []
      partCatalogError.value = catalogResult.status === 'fulfilled'
        ? evidenceApiError(catalogResult.value.data, 'No fue posible cargar el catálogo de repuestos.')
        : (catalogResult.reason?.message || 'No fue posible cargar el catálogo de repuestos.')
    }
  } finally {
    if (isCurrent()) orderPartsLoading.value = false
  }
}

async function registerOrderPart() {
  if (!order.value || !canRegisterParts || orderPartSaving.value || orderPartsLoading.value) return
  orderPartFormError.value = ''
  orderPartSuccess.value = ''

  if (['DELIVERED', 'CLOSED'].includes(order.value.status)) {
    orderPartFormError.value = 'No se pueden agregar repuestos a una orden entregada o cerrada.'
    return
  }

  const part = selectedPart.value
  const quantity = Number(orderPartForm.value.quantity)
  if (!part || !part.is_active) {
    orderPartFormError.value = 'Selecciona un repuesto activo.'
    return
  }
  if (!Number.isInteger(quantity) || quantity < 1) {
    orderPartFormError.value = 'La cantidad debe ser un número entero igual o mayor que uno.'
    return
  }
  if (quantity > part.stock) {
    orderPartFormError.value = `Stock insuficiente. Disponible: ${part.stock}.`
    return
  }

  const orderId = order.value.id
  const sequence = loadSequence
  orderPartSaving.value = true

  try {
    const response = await authenticatedFetch(`/api/inventory/orders/${orderId}/parts/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        part: part.id,
        quantity,
        note: orderPartForm.value.note.trim(),
      }),
    })
    const data = await response.json().catch(() => null)
    if (sequence !== loadSequence) return
    if (!response.ok) {
      throw new Error(evidenceApiError(data, 'No fue posible registrar el repuesto utilizado.'))
    }

    orderPartForm.value = emptyOrderPartForm()
    orderPartSuccess.value = 'Repuesto asociado a la orden y stock actualizado correctamente.'
    // Refrescar el listado y el stock actual desde PostgreSQL.
    await loadOrderParts()
    if (sequence === loadSequence && canViewFinancial) await loadFinancial()
  } catch (err) {
    if (sequence === loadSequence) {
      orderPartFormError.value = err?.message || 'Error al registrar el repuesto utilizado.'
    }
  } finally {
    if (sequence === loadSequence) orderPartSaving.value = false
  }
}


function toggleOrderPartCorrection(item) {
  if (!canCorrectParts || item.is_cancelled) return

  if (Number(orderPartCorrectionOpenId.value) === Number(item.id)) {
    orderPartCorrectionOpenId.value = null
    return
  }

  orderPartCorrectionForms.value = {
    ...orderPartCorrectionForms.value,
    [item.id]: emptyOrderPartCorrectionForm(item),
  }
  clearOrderPartCorrectionMessages(item.id)
  orderPartCorrectionOpenId.value = item.id
}

async function submitOrderPartCorrection(item) {
  if (
    !order.value
    || !canCorrectParts
    || isOrderPartCorrectionSaving(item.id)
  ) return

  clearOrderPartCorrectionMessages(item.id)

  if (item.is_cancelled) {
    setOrderPartCorrectionError(
      item.id,
      'No se puede corregir un uso de repuesto que ya fue anulado.'
    )
    return
  }

  if (['DELIVERED', 'CLOSED'].includes(order.value.status)) {
    setOrderPartCorrectionError(
      item.id,
      'No se pueden corregir repuestos de una orden entregada o cerrada.'
    )
    return
  }

  const form = orderPartCorrectionForms.value[item.id]
  if (!form) return

  const reason = String(form.reason ?? '').trim()
  if (!reason) {
    setOrderPartCorrectionError(item.id, 'Debes indicar el motivo de la corrección.')
    return
  }

  let newValue = ''

  if (form.field_name === 'QUANTITY') {
    const quantity = Number(form.quantity)

    if (!Number.isInteger(quantity) || quantity < 1) {
      setOrderPartCorrectionError(
        item.id,
        'La nueva cantidad debe ser un número entero igual o mayor que uno.'
      )
      return
    }

    if (quantity === Number(item.quantity)) {
      setOrderPartCorrectionError(
        item.id,
        'La nueva cantidad debe ser distinta de la cantidad actual.'
      )
      return
    }

    newValue = String(quantity)
  } else if (form.field_name === 'NOTE') {
    const note = String(form.note ?? '')

    if (note.length > 250) {
      setOrderPartCorrectionError(item.id, 'La nota no puede superar los 250 caracteres.')
      return
    }

    if (note === String(item.note ?? '')) {
      setOrderPartCorrectionError(
        item.id,
        'La nueva nota debe ser distinta de la nota actual.'
      )
      return
    }

    newValue = note
  } else {
    setOrderPartCorrectionError(item.id, 'Selecciona un dato válido para corregir.')
    return
  }

  const sequence = loadSequence
  const orderId = order.value.id
  orderPartCorrectionSavingId.value = item.id

  try {
    const response = await authenticatedFetch(
      `/api/inventory/orders/${orderId}/parts/${item.id}/correction/`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          field_name: form.field_name,
          new_value: newValue,
          reason,
        }),
      }
    )
    const data = await response.json().catch(() => null)

    if (sequence !== loadSequence) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(data, 'No fue posible corregir el repuesto registrado.')
      )
    }

    const updatedUsage = data?.used_part
    if (updatedUsage) {
      usedParts.value = usedParts.value.map((usage) =>
        Number(usage.id) === Number(updatedUsage.id) ? updatedUsage : usage
      )
      orderPartCorrectionForms.value = {
        ...orderPartCorrectionForms.value,
        [item.id]: emptyOrderPartCorrectionForm(updatedUsage),
      }
    }

    setOrderPartCorrectionSuccess(
      item.id,
      'Corrección guardada. El cambio quedó registrado en el historial.'
    )

    await loadOrderParts()
    if (sequence === loadSequence && canViewFinancial) {
      await loadFinancial()
    }
    if (sequence === loadSequence) {
      await loadOrderPartCorrectionHistory(item.id)
    }
  } catch (err) {
    if (sequence === loadSequence) {
      setOrderPartCorrectionError(
        item.id,
        err?.message || 'Error al corregir el repuesto registrado.'
      )
    }
  } finally {
    if (sequence === loadSequence) {
      orderPartCorrectionSavingId.value = null
    }
  }
}

async function loadOrderPartCorrectionHistory(orderPartId) {
  if (!order.value || !canCorrectParts) return

  const orderId = order.value.id
  const sequence = loadSequence
  const requestId = ++orderPartCorrectionHistoryRequestId
  orderPartCorrectionHistoryLatestById[orderPartId] = requestId

  const isCurrent = () =>
    sequence === loadSequence
    && orderPartCorrectionHistoryLatestById[orderPartId] === requestId

  orderPartCorrectionHistoryLoading.value = {
    ...orderPartCorrectionHistoryLoading.value,
    [orderPartId]: true,
  }
  orderPartCorrectionHistoryErrors.value = {
    ...orderPartCorrectionHistoryErrors.value,
    [orderPartId]: '',
  }

  try {
    const response = await getResponse(
      `/api/inventory/orders/${orderId}/parts/${orderPartId}/correction-history/`
    )

    if (!isCurrent()) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(response.data, 'No fue posible cargar el historial de correcciones.')
      )
    }

    const data = response.data
    orderPartCorrectionHistoryById.value = {
      ...orderPartCorrectionHistoryById.value,
      [orderPartId]: Array.isArray(data) ? data : (data?.results || []),
    }
  } catch (err) {
    if (isCurrent()) {
      orderPartCorrectionHistoryErrors.value = {
        ...orderPartCorrectionHistoryErrors.value,
        [orderPartId]: err?.message || 'Error al consultar el historial de correcciones.',
      }
    }
  } finally {
    if (isCurrent()) {
      orderPartCorrectionHistoryLoading.value = {
        ...orderPartCorrectionHistoryLoading.value,
        [orderPartId]: false,
      }
    }
  }
}

async function toggleOrderPartCorrectionHistory(item) {
  if (!canCorrectParts) return

  if (Number(expandedOrderPartCorrectionHistoryId.value) === Number(item.id)) {
    expandedOrderPartCorrectionHistoryId.value = null
    return
  }

  expandedOrderPartCorrectionHistoryId.value = item.id
  await loadOrderPartCorrectionHistory(item.id)
}

function toggleOrderPartCancellation(item) {
  if (!canCancelParts || item.is_cancelled) return

  if (Number(orderPartCancellationOpenId.value) === Number(item.id)) {
    orderPartCancellationOpenId.value = null
    return
  }

  orderPartCancellationForms.value = {
    ...orderPartCancellationForms.value,
    [item.id]: emptyOrderPartCancellationForm(),
  }
  clearOrderPartCancellationMessages(item.id)
  orderPartCorrectionOpenId.value = null
  orderPartCancellationOpenId.value = item.id
}

async function submitOrderPartCancellation(item) {
  if (
    !order.value
    || !canCancelParts
    || item.is_cancelled
    || isOrderPartCancellationSaving(item.id)
  ) {
    return
  }

  clearOrderPartCancellationMessages(item.id)

  if (['DELIVERED', 'CLOSED'].includes(order.value.status)) {
    setOrderPartCancellationError(
      item.id,
      'No se pueden anular repuestos de una orden entregada o cerrada.'
    )
    return
  }

  const form = orderPartCancellationForms.value[item.id]
  if (!form) return

  const reason = String(form.reason ?? '').trim()
  if (!reason) {
    setOrderPartCancellationError(
      item.id,
      'Debes indicar el motivo de la anulación.'
    )
    return
  }

  const orderId = order.value.id
  const sequence = loadSequence
  orderPartCancellationSavingId.value = item.id

  try {
    const response = await authenticatedFetch(
      `/api/inventory/orders/${orderId}/parts/${item.id}/cancellation/`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason }),
      }
    )
    const data = await response.json().catch(() => null)

    if (sequence !== loadSequence) return

    if (!response.ok) {
      throw new Error(
        evidenceApiError(data, 'No fue posible anular el repuesto registrado.')
      )
    }

    const updatedUsage = data?.used_part
    if (updatedUsage) {
      usedParts.value = usedParts.value.map((usage) =>
        Number(usage.id) === Number(updatedUsage.id) ? updatedUsage : usage
      )
    }

    setOrderPartCancellationSuccess(
      item.id,
      'Uso de repuesto anulado. El stock y los costos vigentes fueron actualizados.'
    )
    orderPartCancellationOpenId.value = null
    orderPartCorrectionOpenId.value = null

    await loadOrderParts()
    if (sequence === loadSequence && canViewFinancial) {
      await loadFinancial()
    }
    if (sequence === loadSequence && canViewWarranties) {
      await loadWarranties()
    }
  } catch (err) {
    if (sequence === loadSequence) {
      setOrderPartCancellationError(
        item.id,
        err?.message || 'Error al anular el repuesto registrado.'
      )
    }
  } finally {
    if (sequence === loadSequence) {
      orderPartCancellationSavingId.value = null
    }
  }
}


// Conservamos la estructura de pestañas del prototipo.
// Las secciones pendientes se habilitarán al integrar sus historias.

function resetReceptionReceipt() {
  ++receptionReceiptRequestId
  receptionReceipt.value = null
  receptionReceiptLoading.value = false
  receptionReceiptError.value = ''
  receptionReceiptSaving.value = false
  receptionReceiptDeliveryMethod.value = ''
  receptionReceiptDeliverySaving.value = false
  receptionReceiptDeliveryError.value = ''
  receptionReceiptDeliverySuccess.value = ''
  receptionReceiptWhatsappUrl.value = ''
}

function receptionReceiptApiError(data, fallback) {
  if (typeof data?.detail === 'string') return data.detail
  if (!data || typeof data !== 'object') return fallback

  return Object.entries(data)
    .map(([field, messages]) => {
      const message = Array.isArray(messages)
        ? messages.join(' ')
        : String(messages)

      return `${field}: ${message}`
    })
    .join(' ') || fallback
}

async function loadReceptionReceipt() {
  if (!canManageReceptionReceipt || !order.value) return

  const orderId = order.value.id
  const sequence = loadSequence
  const requestId = ++receptionReceiptRequestId

  receptionReceiptLoading.value = true
  receptionReceiptError.value = ''
  receptionReceiptDeliveryError.value = ''
  receptionReceiptDeliverySuccess.value = ''
  receptionReceiptWhatsappUrl.value = ''

  try {
    const response = await authenticatedFetch(
      `/api/orders/${orderId}/reception-receipt/`
    )
    const data = await response.json().catch(() => null)

    if (
      sequence !== loadSequence ||
      requestId !== receptionReceiptRequestId
    ) {
      return
    }

    if (response.status === 404) {
      receptionReceipt.value = null
      return
    }

    if (!response.ok) {
      throw new Error(
        receptionReceiptApiError(
          data,
          'No fue posible cargar el comprobante de recepción.'
        )
      )
    }

    receptionReceipt.value = data

    if (!receptionReceiptDeliveryMethod.value) {
      if (String(data?.snapshot?.client?.email || '').trim()) {
        receptionReceiptDeliveryMethod.value = 'EMAIL'
      } else if (String(data?.snapshot?.client?.phone || '').trim()) {
        receptionReceiptDeliveryMethod.value = 'WHATSAPP'
      } else {
        receptionReceiptDeliveryMethod.value = 'PRINT'
      }
    }
  } catch (err) {
    if (
      sequence === loadSequence &&
      requestId === receptionReceiptRequestId
    ) {
      receptionReceiptError.value =
        err?.message || 'Error al consultar el comprobante de recepción.'
    }
  } finally {
    if (
      sequence === loadSequence &&
      requestId === receptionReceiptRequestId
    ) {
      receptionReceiptLoading.value = false
    }
  }
}

async function generateReceptionReceipt() {
  if (
    !canManageReceptionReceipt ||
    !order.value ||
    receptionReceiptSaving.value
  ) {
    return
  }

  const orderId = order.value.id
  const sequence = loadSequence
  const requestId = ++receptionReceiptRequestId

  receptionReceiptSaving.value = true
  receptionReceiptError.value = ''
  receptionReceiptDeliveryError.value = ''
  receptionReceiptDeliverySuccess.value = ''

  try {
    const response = await authenticatedFetch(
      `/api/orders/${orderId}/reception-receipt/`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      }
    )
    const data = await response.json().catch(() => null)

    if (
      sequence !== loadSequence ||
      requestId !== receptionReceiptRequestId
    ) {
      return
    }

    if (!response.ok) {
      throw new Error(
        receptionReceiptApiError(
          data,
          'No fue posible generar el comprobante de recepción.'
        )
      )
    }

    receptionReceipt.value = data

    if (String(data?.snapshot?.client?.email || '').trim()) {
      receptionReceiptDeliveryMethod.value = 'EMAIL'
    } else if (String(data?.snapshot?.client?.phone || '').trim()) {
      receptionReceiptDeliveryMethod.value = 'WHATSAPP'
    } else {
      receptionReceiptDeliveryMethod.value = 'PRINT'
    }

    receptionReceiptDeliverySuccess.value =
      response.status === 201
        ? 'Comprobante de recepción generado correctamente.'
        : 'El comprobante de recepción ya existía y fue recuperado.'
  } catch (err) {
    if (
      sequence === loadSequence &&
      requestId === receptionReceiptRequestId
    ) {
      receptionReceiptError.value =
        err?.message || 'Error al generar el comprobante de recepción.'
    }
  } finally {
    if (
      sequence === loadSequence &&
      requestId === receptionReceiptRequestId
    ) {
      receptionReceiptSaving.value = false
    }
  }
}

async function ensureReceptionReceiptPrintChannel() {
  if (receptionReceiptHasEmail.value) {
    return true
  }

  if (!receptionReceiptHasPhone.value) {
    throw new Error(
      'El cliente no tiene correo ni teléfono registrado. ' +
      'Actualiza sus datos de contacto antes de registrar una nueva impresión.'
    )
  }

  if (order.value?.preferred_notification_channel === 'WHATSAPP') {
    return true
  }

  const response = await authenticatedFetch(
    `/api/orders/${order.value.id}/`,
    {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        preferred_notification_channel: 'WHATSAPP',
      }),
    }
  )
  const data = await response.json().catch(() => null)

  if (!response.ok) {
    throw new Error(
      receptionReceiptApiError(
        data,
        'No fue posible definir WhatsApp como canal de notificaciones.'
      )
    )
  }

  order.value = data
  return true
}

async function deliverReceptionReceipt(method) {
  if (
    !canManageReceptionReceipt ||
    !order.value ||
    !receptionReceipt.value ||
    receptionReceiptDeliverySaving.value
  ) {
    return
  }

  receptionReceiptDeliverySaving.value = true
  receptionReceiptDeliveryError.value = ''
  receptionReceiptDeliverySuccess.value = ''
  receptionReceiptWhatsappUrl.value = ''

  const printWindow = method === 'PRINT' ? window.open('', '_blank') : null

  try {
    if (method === 'PRINT' && !printWindow) {
      throw new Error('El navegador bloqueó la impresión. Permite ventanas emergentes y vuelve a intentarlo.')
    }

    if (method === 'PRINT') {
      await ensureReceptionReceiptPrintChannel()
    }

    const response = await authenticatedFetch(
      `/api/orders/${order.value.id}/reception-receipt/deliver/`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          delivery_method: method,
        }),
      }
    )
    const data = await response.json().catch(() => null)

    if (!response.ok) {
      throw new Error(
        receptionReceiptApiError(
          data,
          'No fue posible procesar el comprobante.'
        )
      )
    }

    if (data?.preferred_notification_channel) {
      order.value = {
        ...order.value,
        preferred_notification_channel:
          data.preferred_notification_channel,
        preferred_notification_channel_display:
          data.preferred_notification_channel === 'EMAIL'
            ? 'Correo electrónico'
            : 'WhatsApp',
      }
    }

    await loadReceptionReceipt()

    receptionReceiptDeliverySuccess.value =
      data?.detail || 'Comprobante procesado correctamente.'
    if (method === 'WHATSAPP') {
      receptionReceiptWhatsappUrl.value = data?.whatsapp_url || ''
    }

    if (method === 'PRINT') {
      printReceptionReceipt(printWindow)
    }
  } catch (err) {
    printWindow?.close()
    receptionReceiptDeliveryError.value =
      err?.message || 'Error al procesar el comprobante.'
  } finally {
    receptionReceiptDeliverySaving.value = false
  }
}

function escapeReceptionReceiptHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;')
}

function printReceptionReceipt(preopenedWindow = null) {
  if (!receptionReceiptSnapshot.value) return

  const snapshot = receptionReceiptSnapshot.value
  const orderData = snapshot.order || {}
  const clientData = snapshot.client || {}
  const equipmentData = snapshot.equipment || {}
  const receptionData = snapshot.reception || {}
  const trackingData = snapshot.tracking || {}

  const printWindow = preopenedWindow?.document
    ? preopenedWindow
    : window.open('', '_blank')

  if (!printWindow) {
    receptionReceiptDeliveryError.value =
      'El navegador bloqueó la ventana de impresión. ' +
      'Permite ventanas emergentes e inténtalo nuevamente.'
    return
  }

  const identifier = equipmentData.identifier
    ? `
      <div class="row">
        <span>${escapeReceptionReceiptHtml(
          equipmentData.identifier_label || 'Identificador'
        )}</span>
        <strong>${escapeReceptionReceiptHtml(
          equipmentData.identifier
        )}</strong>
      </div>
    `
    : ''

  printWindow.document.open()
  printWindow.document.write(`
    <!doctype html>
    <html lang="es">
      <head>
        <meta charset="utf-8">
        <title>Comprobante ${escapeReceptionReceiptHtml(
          orderData.tracking_code
        )}</title>
        <style>
          * { box-sizing: border-box; }
          body {
            font-family: Arial, sans-serif;
            color: #111;
            margin: 32px;
            line-height: 1.4;
          }
          .header {
            display: flex;
            justify-content: space-between;
            gap: 24px;
            border-bottom: 2px solid #111;
            padding-bottom: 16px;
            margin-bottom: 20px;
          }
          h1 { margin: 0; font-size: 24px; }
          h2 { font-size: 16px; margin: 22px 0 10px; }
          .code { font-size: 20px; font-weight: 700; }
          .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px 24px;
          }
          .row {
            display: flex;
            flex-direction: column;
            border-bottom: 1px solid #ddd;
            padding: 7px 0;
          }
          .row span { color: #555; font-size: 12px; }
          .box {
            border: 1px solid #bbb;
            padding: 12px;
            min-height: 56px;
            white-space: pre-wrap;
          }
          .confirmation {
            margin-top: 22px;
            border: 1px solid #111;
            padding: 14px;
          }
          .signatures {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 50px;
            margin-top: 70px;
          }
          .signature {
            border-top: 1px solid #111;
            text-align: center;
            padding-top: 6px;
          }
          .small { font-size: 12px; color: #555; }
          @media print {
            body { margin: 15mm; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <h1>${escapeReceptionReceiptHtml(
              snapshot.business?.name || 'Martini Cell'
            )}</h1>
            <div>Comprobante de recepción</div>
          </div>
          <div>
            <div class="small">Código de orden y seguimiento</div>
            <div class="code">${escapeReceptionReceiptHtml(
              orderData.tracking_code
            )}</div>
          </div>
        </div>

        <div class="grid">
          <div class="row">
            <span>Fecha y hora de recepción</span>
            <strong>${escapeReceptionReceiptHtml(
              formatDate(orderData.received_at)
            )}</strong>
          </div>
          <div class="row">
            <span>Recibido por</span>
            <strong>${escapeReceptionReceiptHtml(
              receptionData.received_by || 'Martini Cell'
            )}</strong>
          </div>
        </div>

        <h2>Cliente</h2>
        <div class="grid">
          <div class="row">
            <span>Nombre</span>
            <strong>${escapeReceptionReceiptHtml(clientData.name)}</strong>
          </div>
          <div class="row">
            <span>Teléfono</span>
            <strong>${escapeReceptionReceiptHtml(
              clientData.phone || 'No registrado'
            )}</strong>
          </div>
          <div class="row">
            <span>Correo</span>
            <strong>${escapeReceptionReceiptHtml(
              clientData.email || 'No registrado'
            )}</strong>
          </div>
        </div>

        <h2>Equipo recibido</h2>
        <div class="grid">
          <div class="row">
            <span>Tipo</span>
            <strong>${escapeReceptionReceiptHtml(
              equipmentData.type_display || equipmentData.type
            )}</strong>
          </div>
          <div class="row">
            <span>Marca</span>
            <strong>${escapeReceptionReceiptHtml(
              equipmentData.brand
            )}</strong>
          </div>
          <div class="row">
            <span>Modelo</span>
            <strong>${escapeReceptionReceiptHtml(
              equipmentData.model
            )}</strong>
          </div>
          <div class="row">
            <span>Color</span>
            <strong>${escapeReceptionReceiptHtml(
              equipmentData.color || 'No registrado'
            )}</strong>
          </div>
          ${identifier}
        </div>

        <h2>Recepción</h2>
        <div class="small">Falla o problema informado</div>
        <div class="box">${escapeReceptionReceiptHtml(
          receptionData.reported_issue
        )}</div>

        <div class="small" style="margin-top:12px;">
          Condición / observaciones iniciales
        </div>
        <div class="box">${escapeReceptionReceiptHtml(
          receptionData.initial_observations ||
          'Sin observaciones adicionales'
        )}</div>

        <div class="small" style="margin-top:12px;">
          Accesorios entregados
        </div>
        <div class="box">${escapeReceptionReceiptHtml(
          receptionData.received_accessories ||
          'Sin accesorios registrados'
        )}</div>

        <div class="row" style="margin-top:12px;">
          <span>Abono recibido</span>
          <strong>${escapeReceptionReceiptHtml(
            formatMoney(receptionData.deposit_amount)
          )}</strong>
        </div>

        <div class="confirmation">
          <strong>${escapeReceptionReceiptHtml(
            receptionData.confirmation ||
            'Martini Cell confirma la recepción del equipo descrito.'
          )}</strong>
          <div class="small" style="margin-top:8px;">
            ${escapeReceptionReceiptHtml(
              trackingData.instructions || ''
            )}
          </div>
        </div>

        <div class="signatures">
          <div class="signature">Firma cliente</div>
          <div class="signature">Firma recepción Martini Cell</div>
        </div>
      </body>
    </html>
  `)

  printWindow.document.close()
  printWindow.focus()

  setTimeout(() => {
    printWindow.print()
  }, 250)
}

const tabs = [
  { key: 'resumen', label: 'Resumen', enabled: true },
  ...(canManageReceptionReceipt
    ? [{ key: 'comprobante', label: 'Comprobante', enabled: true }]
    : []),
  { key: 'diagnostico', label: 'Diagnóstico', enabled: true },
  { key: 'linea', label: 'Línea de tiempo', enabled: true },
  { key: 'evidencias', label: 'Evidencias', enabled: true },
  { key: 'repuestos', label: 'Repuestos y costos', enabled: true },
  { key: 'garantia', label: 'Garantías', enabled: true },
  { key: 'viabilidad', label: 'Índice de viabilidad', enabled: true },
]

function formatDate(value) {
  if (!value) return 'No disponible'

  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return 'Fecha no disponible'

  return date.toLocaleString('es-CL', {
    dateStyle: 'short',
    timeStyle: 'short',
  })
}

async function getResponse(url) {
  const response = await authenticatedFetch(url)
  const data = await response.json().catch(() => null)

  return {
    ok: response.ok,
    status: response.status,
    data,
  }
}



function stageLabel(value) {
  return evidenceStages.find((item) => item.value === value)?.label || value
}

function releaseImageUrls() {
  Object.values(imageUrls.value).forEach((url) => URL.revokeObjectURL(url))
  imageUrls.value = {}
  imageLoading.value = {}
  imageErrors.value = {}
}

function resetEvidence() {
  ++evidenceRequestId
  releaseImageUrls()
  evidences.value = []
  evidenceLoading.value = false
  evidenceError.value = ''
  uploadingEvidence.value = false
  uploadError.value = ''
  uploadSuccess.value = ''
  evidenceStage.value = 'RECEPCION'
  evidenceDescription.value = ''
  evidenceFile.value = null
  if (evidenceInput.value) evidenceInput.value.value = ''
}

function evidenceApiError(data, fallback) {
  if (typeof data?.detail === 'string') return data.detail
  if (!data || typeof data !== 'object') return fallback
  return Object.entries(data).map(([field, messages]) => {
    const message = Array.isArray(messages) ? messages.join(' ') : String(messages)
    return `${field}: ${message}`
  }).join(' ') || fallback
}

async function loadEvidences() {
  if (!order.value) return
  const orderId = order.value.id
  const requestId = ++evidenceRequestId
  evidenceLoading.value = true
  evidenceError.value = ''
  releaseImageUrls()

  try {
    const response = await authenticatedFetch(`/api/orders/${orderId}/evidence/`)
    const data = await response.json().catch(() => null)
    if (requestId !== evidenceRequestId) return
    if (!response.ok) {
      throw new Error(evidenceApiError(data, 'No fue posible cargar las evidencias.'))
    }
    evidences.value = Array.isArray(data) ? data : (data?.results || [])
  } catch (err) {
    if (requestId === evidenceRequestId) {
      evidences.value = []
      evidenceError.value = err?.message || 'Error al cargar las evidencias.'
    }
  } finally {
    if (requestId === evidenceRequestId) evidenceLoading.value = false
  }
}

function selectTab(key) {
  tab.value = key
  if (key === 'comprobante' && order.value && canManageReceptionReceipt) {
    loadReceptionReceipt()
  }
  if (key === 'evidencias' && order.value) loadEvidences()
  if (key === 'linea' && order.value) refreshOrderTracking()
  if (key === 'repuestos' && order.value) refreshPartsAndFinancial()
  if (key === 'garantia' && order.value && canViewWarranties) {
    Promise.allSettled([
      loadWarranties(),
      loadOrderParts(),
      loadWarrantyRequests(),
    ])
  }
  if (key === 'viabilidad' && order.value && canViewViability) {
    loadViability()
  }
}

function openRequestedTab(value) {
  const requestedKey = String(value || '').trim()
  const target = tabs.find(
    (item) => item.key === requestedKey && item.enabled,
  )

  if (!target) return

  selectTab(target.key)
}

function selectEvidenceFile(event) {
  evidenceFile.value = event.target.files?.[0] || null
  uploadError.value = ''
  uploadSuccess.value = ''
}

async function uploadEvidence() {
  if (uploadingEvidence.value || !order.value) return
  uploadError.value = ''
  uploadSuccess.value = ''
  const file = evidenceFile.value

  if (!file) {
    uploadError.value = 'Selecciona una fotografía.'
    return
  }
  if (!/\.(jpe?g|png|webp)$/i.test(file.name)) {
    uploadError.value = 'Formato no permitido. Usa JPG, JPEG, PNG o WEBP.'
    return
  }
  if (file.size > maxEvidenceSize) {
    uploadError.value = 'La fotografía no puede superar los 20 MB.'
    return
  }

  const orderId = order.value.id
  const requestId = evidenceRequestId
  const formData = new FormData()
  formData.append('stage', evidenceStage.value)
  formData.append('description', evidenceDescription.value.trim())
  formData.append('image', file)
  uploadingEvidence.value = true

  try {
    // No establecer Content-Type: el navegador agrega el boundary de multipart/form-data.
    const response = await authenticatedFetch(`/api/orders/${orderId}/evidence/`, {
      method: 'POST',
      body: formData,
    })
    const data = await response.json().catch(() => null)
    if (!response.ok) {
      throw new Error(evidenceApiError(data, 'No fue posible adjuntar la fotografía.'))
    }
    if (requestId !== evidenceRequestId) return
    uploadSuccess.value = 'Evidencia registrada correctamente en Django.'
    evidenceFile.value = null
    evidenceDescription.value = ''
    evidenceStage.value = 'RECEPCION'
    if (evidenceInput.value) evidenceInput.value.value = ''
    uploadingEvidence.value = false
    await loadEvidences()
  } catch (err) {
    if (requestId === evidenceRequestId) {
      uploadError.value = err?.message || 'Error al subir la fotografía.'
    }
  } finally {
    if (order.value?.id === orderId) uploadingEvidence.value = false
  }
}

async function toggleEvidenceImage(item) {
  const id = item.id
  if (imageUrls.value[id]) {
    URL.revokeObjectURL(imageUrls.value[id])
    const urls = { ...imageUrls.value }
    delete urls[id]
    imageUrls.value = urls
    return
  }
  if (imageLoading.value[id] || !order.value) return

  const orderId = order.value.id
  const requestId = evidenceRequestId
  imageLoading.value = { ...imageLoading.value, [id]: true }
  imageErrors.value = { ...imageErrors.value, [id]: '' }

  try {
    // La URL privada requiere Authorization; un <img src="/api/..."> no envía el JWT.
    const response = await authenticatedFetch(
      `/api/orders/${orderId}/evidence/${id}/download/`
    )
    if (!response.ok) throw new Error('No fue posible recuperar la fotografía.')
    const blob = await response.blob()
    if (!blob.type.startsWith('image/')) {
      throw new Error('El servidor no devolvió una imagen válida.')
    }
    if (requestId !== evidenceRequestId) return
    imageUrls.value = { ...imageUrls.value, [id]: URL.createObjectURL(blob) }
  } catch (err) {
    if (requestId === evidenceRequestId) {
      imageErrors.value = { ...imageErrors.value, [id]: err?.message || 'Error al abrir la imagen.' }
    }
  } finally {
    if (requestId === evidenceRequestId) {
      imageLoading.value = { ...imageLoading.value, [id]: false }
    }
  }
}

onBeforeUnmount(() => {
  ++evidenceRequestId
  ++viabilityRequestId
  ++warrantyClaimRequestId
  releaseImageUrls()
  releaseWarrantyRequestImages()
})


// Administradores pueden asignar técnicos activos; un técnico puede
// registrar el trabajo a su nombre sin acceder a la API de usuarios.
async function loadTechnicians(sequence) {
  technicians.value = []
  techniciansError.value = ''
  if (!canEditReport) return

  if (currentUser?.role === 'TECH') {
    technicians.value = [{
      id: currentUser.id,
      username: currentUser.username,
      is_active: true,
    }]
    return
  }

  techniciansLoading.value = true
  try {
    const response = await getResponse('/api/users/')
    if (sequence !== loadSequence) return
    if (!response.ok) throw new Error('No fue posible consultar los técnicos activos.')

    const users = Array.isArray(response.data)
      ? response.data
      : (response.data?.results || [])
    technicians.value = users.filter((user) => user.role === 'TECH' && user.is_active)
  } catch (err) {
    if (sequence === loadSequence) {
      techniciansError.value = err?.message || 'Error al cargar los técnicos.'
    }
  } finally {
    if (sequence === loadSequence) techniciansLoading.value = false
  }
}

// Conservar el técnico previamente asignado al visualizar un informe
// aunque ya no aparezca en la lista de técnicos activos.
function availableTechnicians() {
  const list = [...technicians.value]
  const assigned = technicalReport.value
  if (assigned?.technician && !list.some((user) => Number(user.id) === Number(assigned.technician))) {
    list.push({
      id: assigned.technician,
      username: `${assigned.technician_username || 'Técnico anterior'} (asignado anteriormente)`,
    })
  }
  return list
}

function resetReportForm() {
  const report = technicalReport.value
  reportForm.value = report
    ? {
        diagnosis: report.diagnosis || '',
        repair_actions: report.repair_actions || '',
        repair_observations: report.repair_observations || '',
        parts_description: report.parts_description || '',
        result: report.result || '',
        technician: report.technician || '',
      }
    : {
        ...emptyReportForm(),
        technician: currentUser?.role === 'TECH' ? currentUser.id : '',
      }
  reportFormError.value = ''
}

async function loadTechnicalReportHistory(orderId, sequence) {
  if (!canViewTechnicalReportHistory) {
    technicalReportHistory.value = []
    reportHistoryLoading.value = false
    reportHistoryError.value = ''
    return
  }

  reportHistoryLoading.value = true
  reportHistoryError.value = ''
  try {
    const response = await getResponse(`/api/orders/${orderId}/technical-report/history/`)
    if (sequence !== loadSequence) return
    if (!response.ok) throw new Error('No fue posible cargar las revisiones del informe.')
    technicalReportHistory.value = Array.isArray(response.data)
      ? response.data
      : (response.data?.results || [])
  } catch (err) {
    if (sequence === loadSequence) {
      reportHistoryError.value = err?.message || 'Error al cargar el historial del informe.'
    }
  } finally {
    if (sequence === loadSequence) reportHistoryLoading.value = false
  }
}

// POST para el primer informe; PATCH para modificarlo sin perder las
// revisiones históricas que registra Django.
async function saveTechnicalReport() {
  if (reportSaving.value || !order.value || !canEditReport) return
  const orderId = order.value.id
  const sequence = loadSequence
  const isEditing = Boolean(technicalReport.value)
  reportFormError.value = ''
  reportSuccess.value = ''

  const payload = {
    diagnosis: reportForm.value.diagnosis.trim(),
    repair_actions: reportForm.value.repair_actions.trim(),
    repair_observations: reportForm.value.repair_observations.trim(),
    parts_description: reportForm.value.parts_description.trim(),
    result: reportForm.value.result,
  }

  if (!payload.diagnosis || !payload.repair_actions || !payload.result) {
    reportFormError.value = 'Completa diagnóstico, reparación y resultado.'
    return
  }

  if (!isEditing || Number(reportForm.value.technician) !== Number(technicalReport.value.technician)) {
    if (!Number(reportForm.value.technician)) {
      reportFormError.value = 'Selecciona un técnico responsable.'
      return
    }
    payload.technician = Number(reportForm.value.technician)
  }

  reportSaving.value = true
  try {
    const response = await authenticatedFetch(`/api/orders/${orderId}/technical-report/`, {
      method: isEditing ? 'PATCH' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
    const data = await response.json().catch(() => null)
    if (!response.ok) {
      throw new Error(evidenceApiError(data, 'No fue posible guardar el informe técnico.'))
    }
    if (sequence !== loadSequence) return

    technicalReport.value = data
    reportError.value = ''
    resetReportForm()
    reportSuccess.value = isEditing
      ? 'Informe actualizado y revisión registrada cuando hubo cambios.'
      : 'Informe técnico registrado correctamente.'
    await loadTechnicalReportHistory(orderId, sequence)
  } catch (err) {
    if (sequence === loadSequence) {
      reportFormError.value = err?.message || 'Error al guardar el informe técnico.'
    }
  } finally {
    if (sequence === loadSequence) reportSaving.value = false
  }
}

let loadSequence = 0

// HU-10 y HU-11: consultar de nuevo orden, transiciones, historial y tiempos
// para que el cambio se refleje tanto en Resumen como en Línea de tiempo.
async function refreshOrderTracking() {
  if (!order.value) return
  const orderId = order.value.id
  const sequence = loadSequence
  statusLoading.value = true
  statusError.value = ''

  try {
    const [orderResult, statusResult, historyResult, timesResult] = await Promise.allSettled([
      getResponse(`/api/orders/${orderId}/`),
      getResponse(`/api/orders/${orderId}/status/`),
      getResponse(`/api/orders/${orderId}/status/history/`),
      getResponse(`/api/orders/${orderId}/times/`),
    ])
    if (sequence !== loadSequence) return

    if (orderResult.status === 'fulfilled' && orderResult.value.ok) {
      order.value = orderResult.value.data
    } else {
      statusError.value = 'No fue posible actualizar los datos generales de la orden.'
    }

    if (statusResult.status === 'fulfilled' && statusResult.value.ok) {
      statusInfo.value = statusResult.value.data
      order.value = {
        ...order.value,
        status: statusInfo.value.status,
        status_display: statusInfo.value.status_display,
      }
      nextStatus.value = ''
    } else {
      statusError.value = 'No fue posible consultar el estado y las transiciones permitidas.'
    }

    if (historyResult.status === 'fulfilled' && historyResult.value.ok &&
        Array.isArray(historyResult.value.data)) {
      history.value = historyResult.value.data
      historyError.value = ''
    } else {
      historyError.value = 'No fue posible actualizar la línea de tiempo.'
    }

    if (timesResult.status === 'fulfilled' && timesResult.value.ok) {
      times.value = timesResult.value.data
      timesError.value = ''
    } else {
      times.value = null
      timesError.value = timesResult.status === 'fulfilled' && timesResult.value.status === 409
        ? (timesResult.value.data?.detail || 'El historial no permite calcular los tiempos.')
        : 'No fue posible actualizar los tiempos del servicio.'
    }
  } catch (err) {
    if (sequence === loadSequence) {
      statusError.value = err?.message || 'No fue posible actualizar el seguimiento.'
    }
  } finally {
    if (sequence === loadSequence) statusLoading.value = false
  }
}

async function changeOrderStatus() {
  if (!order.value || !canChangeStatus || statusSaving.value || statusLoading.value) return
  statusFormError.value = ''
  statusSuccess.value = ''
  statusNotificationFeedback.value = null

  const selected = statusInfo.value?.allowed_transitions?.find(
    (item) => item.status === nextStatus.value
  )
  if (!selected) {
    statusFormError.value = 'Selecciona una transición permitida.'
    return
  }

  const orderId = order.value.id
  const sequence = loadSequence
  statusSaving.value = true
  try {
    const response = await authenticatedFetch(`/api/orders/${orderId}/status/`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: selected.status, note: statusNote.value.trim() }),
    })
    const data = await response.json().catch(() => null)
    if (sequence !== loadSequence) return
    if (!response.ok) {
      throw new Error(evidenceApiError(data, 'No fue posible cambiar el estado de la orden.'))
    }

    statusInfo.value = data
    order.value = {
      ...order.value,
      status: data.status,
      status_display: data.status_display,
    }
    statusNote.value = ''
    nextStatus.value = ''
    statusSuccess.value = `Estado actualizado a ${data.status_display}. El cambio quedó registrado en el historial.`
    statusNotificationFeedback.value = data?.notification_result || null

    await refreshOrderTracking()
  } catch (err) {
    if (sequence === loadSequence) {
      statusFormError.value = err?.message || 'Error al actualizar el estado.'
    }
  } finally {
    if (sequence === loadSequence) statusSaving.value = false
  }
}

async function loadOrder() {
  const sequence = ++loadSequence
  const orderId = String(route.params.id ?? '')

  loading.value = true
  error.value = ''
  historyError.value = ''
  reportError.value = ''
  timesError.value = ''
  statusInfo.value = null
  statusLoading.value = false
  statusSaving.value = false
  statusError.value = ''
  statusFormError.value = ''
  statusSuccess.value = ''
  statusNotificationFeedback.value = null
  nextStatus.value = ''
  statusNote.value = ''
  technicalReportHistory.value = []
  reportHistoryLoading.value = false
  reportHistoryError.value = ''
  reportSaving.value = false
  reportSuccess.value = ''
  reportFormError.value = ''
  technicians.value = []
  techniciansError.value = ''
  techniciansLoading.value = false
  resetEvidence()
  resetOrderParts()
  resetFinancial()
  resetWarranties()
  resetViability()
  resetSensitiveOrderState()
  resetReceptionReceipt()

  order.value = null
  history.value = []
  technicalReport.value = null
  times.value = null
  resetReportForm()
  tab.value = 'resumen'

  if (!/^[1-9]\d*$/.test(orderId)) {
    error.value = 'El ID de la orden no es válido.'
    loading.value = false
    return
  }

  try {
    const orderResponse = await getResponse(`/api/orders/${orderId}/`)
    if (sequence !== loadSequence) return

    if (!orderResponse.ok) {
      error.value = orderResponse.status === 404
        ? 'La orden solicitada no existe.'
        : 'No fue posible cargar la orden de servicio.'
      return
    }

    order.value = orderResponse.data

    // Estas consultas son de lectura. Si alguna falla, conservamos
    // el detalle principal y mostramos el problema en su sección.
    const [historyResult, reportResult, timesResult, statusResult] = await Promise.allSettled([
      getResponse(`/api/orders/${orderId}/status/history/`),
      getResponse(`/api/orders/${orderId}/technical-report/`),
      getResponse(`/api/orders/${orderId}/times/`),
      getResponse(`/api/orders/${orderId}/status/`),
    ])

    if (sequence !== loadSequence) return

    if (
      historyResult.status === 'fulfilled' &&
      historyResult.value.ok &&
      Array.isArray(historyResult.value.data)
    ) {
      history.value = historyResult.value.data
    } else {
      historyError.value = 'No fue posible cargar la línea de tiempo.'
    }

    if (reportResult.status === 'fulfilled') {
      if (reportResult.value.ok) {
        technicalReport.value = reportResult.value.data
      } else if (reportResult.value.status !== 404) {
        reportError.value = 'No fue posible consultar el informe técnico.'
      }
    } else {
      reportError.value = 'No fue posible consultar el informe técnico.'
    }
    resetReportForm()

    if (statusResult.status === 'fulfilled' && statusResult.value.ok) {
      statusInfo.value = statusResult.value.data
      order.value = {
        ...order.value,
        status: statusInfo.value.status,
        status_display: statusInfo.value.status_display,
      }
    } else {
      statusError.value = 'No fue posible consultar las transiciones permitidas.'
    }

    // Las revisiones y los técnicos se consultan separadamente.
    // Fallar en una de estas consultas no oculta el detalle principal.
    await Promise.allSettled([
      loadTechnicians(sequence),
      ...(technicalReport.value && canViewTechnicalReportHistory
        ? [loadTechnicalReportHistory(orderId, sequence)]
        : []),
      ...(canViewSensitiveHistory
        ? [loadSensitiveHistory(orderId, sequence)]
        : []),
    ])
    if (sequence !== loadSequence) return

    if (timesResult.status === 'fulfilled') {
      if (timesResult.value.ok) {
        times.value = timesResult.value.data
      } else {
        timesError.value = timesResult.value.status === 409
          ? (timesResult.value.data?.detail || 'El historial no permite calcular los tiempos.')
          : 'No fue posible calcular los tiempos del servicio.'
      }
    } else {
      timesError.value = 'No fue posible calcular los tiempos del servicio.'
    }
  } catch (err) {
    if (sequence === loadSequence) {
      error.value = err?.message || 'No fue posible cargar la orden de servicio.'
    }
  } finally {
    if (sequence === loadSequence) loading.value = false
  }
}

// Permite cambiar entre órdenes y abrir una pestaña específica desde enlaces externos.
watch(
  () => route.params.id,
  async () => {
    await loadOrder()
    openRequestedTab(route.query.tab)
  },
  { immediate: true },
)

watch(
  () => route.query.tab,
  (requestedTab) => {
    if (order.value) {
      openRequestedTab(requestedTab)
    }
  },
)
</script>

<template>
  <AdminLayout>
    <div v-if="loading" class="mc-card p-4 text-center">
      <div class="spinner-border text-primary mb-2" role="status"></div>
      <div class="text-muted">Cargando orden de servicio...</div>
    </div>

    <div v-else-if="error" class="alert alert-warning" role="alert">
      {{ error }}
      <div class="mt-3">
        <router-link to="/ordenes" class="btn btn-outline-secondary btn-sm">
          Volver a órdenes
        </router-link>
        <button type="button" class="btn btn-outline-primary btn-sm ms-2" @click="loadOrder">
          Reintentar
        </button>
      </div>
    </div>

    <template v-else-if="order">
      <PageHeader>
        {{ order.tracking_code }}
        <StatusBadge
          :status="order.status"
          :label="order.status_display || order.status"
        />

        <template #subtitle>
          {{ order.equipment_description }} · Cliente: {{ order.client_name }}
          · Registrado por: {{ order.created_by_username || 'No disponible' }}
        </template>

        <template #actions>
          <router-link to="/ordenes" class="btn btn-outline-secondary">
            Volver a órdenes
          </router-link>
        </template>
      </PageHeader>

      <div class="section-tabs mb-4">
        <button
          v-for="item in tabs"
          :key="item.key"
          type="button"
          :class="{ active: tab === item.key }"
          :disabled="!item.enabled"
          :title="item.enabled ? item.label : `${item.label}: integración pendiente`"
          @click="selectTab(item.key)"
        >
          {{ item.label }}
          <span v-if="!item.enabled" class="small">(pendiente)</span>
        </button>
      </div>

      <!-- RESUMEN: información real de la orden y sus tiempos -->
      <section v-if="tab === 'resumen'" class="row g-3">
        <div class="col-12">
          <div class="mc-card p-4">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
              <div>
                <h5 class="mb-1">Trazabilidad de esta orden</h5>
                <div class="small text-muted">
                  Los cambios de estado conservan fecha, responsable y observación.
                  La vista del cliente muestra solo estados y fechas.
                </div>
              </div>
              <StatusBadge
                :status="order.status"
                :label="order.status_display || order.status"
              />
            </div>

            <div v-if="historyError" class="alert alert-warning small mt-3 mb-0" role="alert">
              {{ historyError }}
            </div>
            <div v-else-if="latestStatusEvent" class="small mt-3">
              Último movimiento:
              <strong>{{ latestStatusEvent.to_status_display || latestStatusEvent.to_status }}</strong>
              · {{ formatDate(latestStatusEvent.changed_at) }}
              · {{ latestStatusEvent.changed_by_username || 'Usuario no disponible' }}
            </div>
            <div v-else class="small text-muted mt-3">
              Aún no hay movimientos para mostrar.
            </div>

            <div class="d-flex flex-wrap gap-2 mt-3">
              <button type="button" class="btn btn-primary" @click="selectTab('linea')">
                Ver línea de tiempo
              </button>
              <router-link
                :to="{ path: '/consulta', query: { codigo: order.tracking_code } }"
                target="_blank"
                rel="noopener noreferrer"
                class="btn btn-outline-primary"
              >
                Ver seguimiento como cliente
              </router-link>
            </div>
          </div>
        </div>

        <div class="col-lg-8">
          <div class="mc-card p-4 h-100">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
              <h5 class="mb-0">Información general</h5>
              <button
                v-if="canEditSensitiveOrder && !sensitiveOrderLocked && !sensitiveEditOpen"
                type="button"
                class="btn btn-sm btn-outline-primary"
                @click="openSensitiveOrderEdit"
              >
                <i class="bi bi-pencil-square me-1"></i>
                Editar datos
              </button>
            </div>

            <div
              v-if="canEditSensitiveOrder && sensitiveOrderLocked"
              class="alert alert-light border small mt-3 mb-0"
            >
              Los datos generales no se pueden modificar porque la orden está
              {{ order.status === 'CLOSED' ? 'cerrada' : 'entregada' }}.
            </div>

            <div v-if="sensitiveSuccess" class="alert alert-success mt-3" role="status">
              {{ sensitiveSuccess }}
            </div>

            <div v-if="sensitiveReferenceError" class="alert alert-warning mt-3" role="alert">
              {{ sensitiveReferenceError }}
            </div>

            <form
              v-if="sensitiveEditOpen"
              class="border rounded p-3 mt-3"
              @submit.prevent="saveSensitiveOrder"
            >
              <h6>Modificar datos sensibles</h6>
              <div class="small text-muted mb-3">
                Los cambios quedan registrados con valor anterior, valor nuevo,
                fecha y usuario responsable.
              </div>

              <div v-if="sensitiveFormError" class="alert alert-danger" role="alert">
                {{ sensitiveFormError }}
              </div>

              <div class="row g-3">
                <div class="col-md-6">
                  <label for="sensitive-client" class="form-label">Cliente asociado</label>
                  <select
                    id="sensitive-client"
                    v-model="sensitiveOrderForm.client"
                    class="form-select"
                    :disabled="sensitiveSaving || sensitiveReferenceLoading"
                    required
                    @change="onSensitiveClientChange"
                  >
                    <option value="">Seleccionar cliente...</option>
                    <option
                      v-for="client in sensitiveClients"
                      :key="client.id"
                      :value="client.id"
                    >
                      {{ client.client_code }} · {{ client.name }} · {{ clientIdentificationLabel(client) }}
                    </option>
                  </select>
                </div>

                <div class="col-md-6">
                  <label for="sensitive-equipment" class="form-label">Equipo asociado</label>
                  <select
                    id="sensitive-equipment"
                    v-model="sensitiveOrderForm.equipment"
                    class="form-select"
                    :disabled="sensitiveSaving || sensitiveReferenceLoading || !sensitiveOrderForm.client"
                    required
                  >
                    <option value="">Seleccionar equipo...</option>
                    <option
                      v-for="device in availableSensitiveDevices"
                      :key="device.id"
                      :value="device.id"
                    >
                      Equipo #{{ device.id }} · {{ device.brand }} {{ device.model }}
                    </option>
                  </select>
                </div>

                <div class="col-12">
                  <label for="sensitive-reported-issue" class="form-label">
                    Falla reportada
                  </label>
                  <textarea
                    id="sensitive-reported-issue"
                    v-model="sensitiveOrderForm.reported_issue"
                    class="form-control"
                    rows="3"
                    :disabled="sensitiveSaving"
                    required
                  ></textarea>
                </div>

                <div class="col-12">
                  <label for="sensitive-initial-observations" class="form-label">
                    Observaciones iniciales
                  </label>
                  <textarea
                    id="sensitive-initial-observations"
                    v-model="sensitiveOrderForm.initial_observations"
                    class="form-control"
                    rows="3"
                    :disabled="sensitiveSaving"
                  ></textarea>
                </div>

                <div class="col-12">
                  <label for="sensitive-change-reason" class="form-label">
                    Motivo del cambio
                    <span v-if="sensitiveRelationChanged" class="text-danger">*</span>
                  </label>
                  <textarea
                    id="sensitive-change-reason"
                    v-model="sensitiveOrderForm.change_reason"
                    class="form-control"
                    rows="2"
                    :disabled="sensitiveSaving"
                    :required="sensitiveRelationChanged"
                    placeholder="Obligatorio si cambias el cliente o el equipo."
                  ></textarea>
                  <div class="form-text">
                    Para cambios solo de falla u observaciones, el motivo es opcional.
                  </div>
                </div>
              </div>

              <div class="d-flex gap-2 mt-3">
                <button
                  type="submit"
                  class="btn btn-primary"
                  :disabled="sensitiveSaving || sensitiveReferenceLoading"
                >
                  <span
                    v-if="sensitiveSaving"
                    class="spinner-border spinner-border-sm me-2"
                    role="status"
                  ></span>
                  {{ sensitiveSaving ? 'Guardando...' : 'Guardar cambios' }}
                </button>
                <button
                  type="button"
                  class="btn btn-outline-secondary"
                  :disabled="sensitiveSaving"
                  @click="cancelSensitiveOrderEdit"
                >
                  Cancelar
                </button>
              </div>
            </form>

            <div class="row g-3 mt-1">
              <div class="col-md-6">
                <div class="mc-muted small">Equipo</div>
                <strong>{{ order.equipment_description }}</strong>
                <div class="small text-muted">Equipo #{{ order.equipment }}</div>
              </div>

              <div class="col-md-6">
                <div class="mc-muted small">Estado actual</div>
                <StatusBadge
                  :status="order.status"
                  :label="order.status_display || order.status"
                />
              </div>

              <div class="col-md-6">
                <div class="mc-muted small">Falla reportada</div>
                <div>{{ order.reported_issue }}</div>
              </div>

              <div class="col-md-6">
                <div class="mc-muted small">Observaciones iniciales</div>
                <div>{{ order.initial_observations || 'Sin observaciones adicionales' }}</div>
              </div>

              <div class="col-md-6">
                <div class="mc-muted small">Ingreso</div>
                <div>{{ formatDate(order.received_at) }}</div>
              </div>

              <div class="col-md-6">
                <div class="mc-muted small">Última actualización</div>
                <div>{{ formatDate(order.updated_at) }}</div>
              </div>

              <div class="col-md-6">
                <div class="mc-muted small">Diagnóstico actual</div>
                <div>{{ technicalReport?.diagnosis || (reportError || 'Pendiente') }}</div>
              </div>

              <div class="col-md-6">
                <div class="mc-muted small">Trabajo realizado</div>
                <div>{{ technicalReport?.repair_actions || (reportError || 'Pendiente') }}</div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="mc-card p-4">
            <h5>Tiempos del servicio</h5>
            <div v-if="timesError" class="alert alert-warning small mb-0">
              {{ timesError }}
            </div>
            <table v-else-if="times" class="table small mb-0">
              <tbody>
                <tr>
                  <td>Tiempo técnico</td>
                  <td class="text-end fw-semibold">{{ times.technical_display }}</td>
                </tr>
                <tr>
                  <td>Tiempo de espera</td>
                  <td class="text-end">{{ times.waiting_display }}</td>
                </tr>
                <tr class="fw-bold">
                  <td>Total</td>
                  <td class="text-end">{{ times.total_display }}</td>
                </tr>
              </tbody>
            </table>
            <div v-else class="text-muted">Sin datos disponibles.</div>
            <div v-if="times" class="small text-muted mt-2">
              Calculado al consultar la orden. Los tiempos pueden seguir aumentando.
            </div>
          </div>
        </div>

        <div v-if="canViewSensitiveHistory" class="col-12">
          <div class="mc-card p-4">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
              <div>
                <h5 class="mb-1">Historial de cambios sensibles</h5>
                <div class="small text-muted">
                  Auditoría de cliente, equipo, falla reportada y observaciones iniciales.
                </div>
              </div>
              <button
                type="button"
                class="btn btn-sm btn-outline-secondary"
                :disabled="sensitiveHistoryLoading"
                @click="loadSensitiveHistory()"
              >
                Actualizar
              </button>
            </div>

            <div v-if="sensitiveHistoryLoading" class="text-muted">
              <span class="spinner-border spinner-border-sm me-2" role="status"></span>
              Cargando historial...
            </div>

            <div
              v-else-if="sensitiveHistoryError"
              class="alert alert-warning mb-0"
              role="alert"
            >
              {{ sensitiveHistoryError }}
            </div>

            <div v-else-if="!sensitiveChanges.length" class="text-muted">
              Aún no existen cambios sensibles registrados para esta orden.
            </div>

            <div v-else class="table-responsive">
              <table class="table table-sm align-middle mb-0">
                <thead>
                  <tr>
                    <th>Fecha</th>
                    <th>Campo</th>
                    <th>Anterior</th>
                    <th>Nuevo</th>
                    <th>Motivo</th>
                    <th>Usuario</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="item in sensitiveChanges" :key="item.id">
                    <td class="text-nowrap">{{ formatDate(item.changed_at) }}</td>
                    <td>{{ item.field_display || item.field }}</td>
                    <td style="min-width: 160px; white-space: pre-wrap;">
                      {{ formatSensitiveValue(item.old_value) }}
                    </td>
                    <td style="min-width: 160px; white-space: pre-wrap;">
                      {{ formatSensitiveValue(item.new_value) }}
                    </td>
                    <td style="min-width: 160px; white-space: pre-wrap;">
                      {{ item.reason || 'Sin motivo registrado' }}
                    </td>
                    <td class="text-nowrap">
                      {{ item.changed_by_username || 'No disponible' }}
                      <div class="small text-muted">
                        {{ sensitiveRoleLabel(item.changed_by_role) }}
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      <!-- HU-34: comprobante de recepción y reenvíos -->
      <section v-if="tab === 'comprobante'">
        <div
          v-if="!canManageReceptionReceipt"
          class="alert alert-info"
        >
          Tu perfil no tiene permiso para gestionar el comprobante de recepción.
        </div>

        <template v-else>
          <div
            v-if="receptionReceiptLoading"
            class="mc-card p-4 text-center"
          >
            <div
              class="spinner-border text-primary mb-2"
              role="status"
            ></div>
            <div class="text-muted">
              Cargando comprobante de recepción...
            </div>
          </div>

          <div
            v-else-if="receptionReceiptError"
            class="mc-card p-4"
          >
            <div class="alert alert-warning mb-3">
              {{ receptionReceiptError }}
            </div>

            <button
              type="button"
              class="btn btn-outline-primary"
              @click="loadReceptionReceipt"
            >
              Reintentar
            </button>
          </div>

          <div
            v-else-if="!receptionReceipt"
            class="mc-card p-4"
          >
            <h5>Comprobante de recepción</h5>

            <p class="text-muted mb-3">
              Esta orden todavía no tiene un comprobante de recepción
              generado. Al generarlo se guardará una copia de los datos
              actuales de recepción para futuras reimpresiones o reenvíos.
            </p>

            <button
              type="button"
              class="btn btn-primary"
              :disabled="receptionReceiptSaving"
              @click="generateReceptionReceipt"
            >
              <span
                v-if="receptionReceiptSaving"
                class="spinner-border spinner-border-sm me-2"
                aria-hidden="true"
              ></span>
              {{
                receptionReceiptSaving
                  ? 'Generando...'
                  : 'Generar comprobante'
              }}
            </button>
          </div>

          <template v-else>
            <div class="row g-3">
              <div class="col-xl-8">
                <div class="mc-card p-4 h-100">
                  <div
                    class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4"
                  >
                    <div>
                      <h5 class="mb-1">Comprobante de recepción</h5>
                      <div class="small text-muted">
                        Generado:
                        {{ formatDate(receptionReceipt.generated_at) }}
                        · por
                        {{
                          receptionReceipt.generated_by_username ||
                          'usuario no disponible'
                        }}
                      </div>
                    </div>

                    <div class="text-end">
                      <div class="small text-muted">
                        Código de orden y seguimiento
                      </div>
                      <strong class="fs-5">
                        {{ receptionReceiptOrder.tracking_code }}
                      </strong>
                    </div>
                  </div>

                  <div class="row g-3">
                    <div class="col-md-6">
                      <div class="border rounded p-3 h-100">
                        <h6>Cliente</h6>
                        <div class="fw-semibold">
                          {{ receptionReceiptClient.name }}
                        </div>
                        <div class="small mt-2">
                          <strong>Teléfono:</strong>
                          {{
                            receptionReceiptClient.phone ||
                            'No registrado'
                          }}
                        </div>
                        <div class="small">
                          <strong>Correo:</strong>
                          {{
                            receptionReceiptClient.email ||
                            'No registrado'
                          }}
                        </div>
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="border rounded p-3 h-100">
                        <h6>Equipo recibido</h6>
                        <div class="fw-semibold">
                          {{
                            receptionReceiptEquipment.type_display ||
                            receptionReceiptEquipment.type
                          }}
                          ·
                          {{ receptionReceiptEquipment.brand }}
                          {{ receptionReceiptEquipment.model }}
                        </div>

                        <div
                          v-if="receptionReceiptEquipment.color"
                          class="small mt-2"
                        >
                          <strong>Color:</strong>
                          {{ receptionReceiptEquipment.color }}
                        </div>

                        <div
                          v-if="receptionReceiptEquipment.identifier"
                          class="small"
                        >
                          <strong>
                            {{ receptionReceiptEquipment.identifier_label }}:
                          </strong>
                          {{ receptionReceiptEquipment.identifier }}
                        </div>
                      </div>
                    </div>

                    <div class="col-12">
                      <div class="border rounded p-3">
                        <div class="row g-3">
                          <div class="col-md-6">
                            <div class="small text-muted">
                              Fecha y hora de recepción
                            </div>
                            <strong>
                              {{
                                formatDate(
                                  receptionReceiptOrder.received_at
                                )
                              }}
                            </strong>
                          </div>

                          <div class="col-md-6">
                            <div class="small text-muted">
                              Recibido por
                            </div>
                            <strong>
                              {{
                                receptionReceiptData.received_by ||
                                'Martini Cell'
                              }}
                            </strong>
                          </div>

                          <div class="col-12">
                            <div class="small text-muted">
                              Falla reportada
                            </div>
                            <div>
                              {{ receptionReceiptData.reported_issue }}
                            </div>
                          </div>

                          <div class="col-md-6">
                            <div class="small text-muted">
                              Condición / observaciones iniciales
                            </div>
                            <div>
                              {{
                                receptionReceiptData.initial_observations ||
                                'Sin observaciones adicionales'
                              }}
                            </div>
                          </div>

                          <div class="col-md-6">
                            <div class="small text-muted">
                              Accesorios entregados
                            </div>
                            <div>
                              {{
                                receptionReceiptData.received_accessories ||
                                'Sin accesorios registrados'
                              }}
                            </div>
                          </div>

                          <div class="col-md-6">
                            <div class="small text-muted">
                              Abono recibido
                            </div>
                            <strong>
                              {{
                                formatMoney(
                                  receptionReceiptData.deposit_amount
                                )
                              }}
                            </strong>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="alert alert-light border mt-3 mb-0">
                    <strong>
                      {{
                        receptionReceiptData.confirmation ||
                        'Martini Cell confirma la recepción del equipo descrito.'
                      }}
                    </strong>

                    <div class="small text-muted mt-2">
                      {{ receptionReceiptTracking.instructions }}
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-4">
                <div class="mc-card p-4 mb-3">
                  <h5>Entregar nuevamente</h5>

                  <div class="small text-muted mb-3">
                    Canal preferido actual:
                    <strong>
                      {{
                        order.preferred_notification_channel_display ||
                        (
                          order.preferred_notification_channel === 'EMAIL'
                            ? 'Correo electrónico'
                            : order.preferred_notification_channel === 'WHATSAPP'
                              ? 'WhatsApp'
                              : 'No definido'
                        )
                      }}
                    </strong>
                  </div>

                  <div
                    v-if="receptionReceiptDeliverySuccess"
                    class="alert alert-success"
                    role="status"
                  >
                    {{ receptionReceiptDeliverySuccess }}
                  </div>

                  <div
                    v-if="receptionReceiptDeliveryError"
                    class="alert alert-danger"
                    role="alert"
                  >
                    {{ receptionReceiptDeliveryError }}
                  </div>

                  <a
                    v-if="receptionReceiptWhatsappUrl"
                    :href="receptionReceiptWhatsappUrl"
                    target="_blank"
                    rel="noopener noreferrer"
                    class="btn btn-success w-100 mb-3"
                  >
                    Abrir WhatsApp y confirmar el envío
                  </a>

                  <label
                    for="receipt-delivery-method"
                    class="form-label"
                  >
                    Medio
                  </label>

                  <select
                    id="receipt-delivery-method"
                    v-model="receptionReceiptDeliveryMethod"
                    class="form-select mb-3"
                    :disabled="receptionReceiptDeliverySaving"
                  >
                    <option value="">Seleccionar...</option>
                    <option
                      value="EMAIL"
                      :disabled="!receptionReceiptHasEmail"
                    >
                      Correo electrónico
                    </option>
                    <option
                      value="WHATSAPP"
                      :disabled="!receptionReceiptHasPhone"
                    >
                      WhatsApp
                    </option>
                    <option
                      value="PRINT"
                      :disabled="
                        !receptionReceiptHasEmail &&
                        !receptionReceiptHasPhone
                      "
                    >
                      Impreso
                    </option>
                  </select>

                  <div
                    v-if="
                      receptionReceiptDeliveryMethod === 'PRINT' &&
                      !receptionReceiptHasEmail &&
                      receptionReceiptHasPhone
                    "
                    class="alert alert-info small"
                  >
                    Como el cliente no tiene correo, WhatsApp quedará
                    como canal preferido para las notificaciones posteriores.
                  </div>

                  <button
                    type="button"
                    class="btn btn-primary w-100"
                    :disabled="
                      receptionReceiptDeliverySaving ||
                      !receptionReceiptDeliveryMethod ||
                      (
                        receptionReceiptDeliveryMethod === 'EMAIL' &&
                        !receptionReceiptHasEmail
                      ) ||
                      (
                        receptionReceiptDeliveryMethod === 'WHATSAPP' &&
                        !receptionReceiptHasPhone
                      )
                    "
                    @click="
                      deliverReceptionReceipt(
                        receptionReceiptDeliveryMethod
                      )
                    "
                  >
                    <span
                      v-if="receptionReceiptDeliverySaving"
                      class="spinner-border spinner-border-sm me-2"
                      aria-hidden="true"
                    ></span>

                    {{
                      receptionReceiptDeliverySaving
                        ? 'Procesando...'
                        : receptionReceiptDeliveryMethod === 'EMAIL'
                          ? 'Reenviar por correo'
                          : receptionReceiptDeliveryMethod === 'WHATSAPP'
                            ? 'Preparar WhatsApp'
                            : receptionReceiptDeliveryMethod === 'PRINT'
                              ? 'Registrar e imprimir'
                              : 'Seleccionar medio'
                    }}
                  </button>

                  <button
                    type="button"
                    class="btn btn-outline-secondary w-100 mt-2"
                    :disabled="receptionReceiptDeliverySaving"
                    @click="printReceptionReceipt"
                  >
                    <i class="bi bi-printer me-1"></i>
                    Vista de impresión
                  </button>
                </div>

                <div class="mc-card p-4">
                  <h5>Historial de entrega</h5>

                  <div
                    v-if="!receptionReceipt.deliveries?.length"
                    class="text-muted small"
                  >
                    Todavía no hay entregas registradas.
                  </div>

                  <div
                    v-else
                    class="d-flex flex-column gap-3"
                  >
                    <div
                      v-for="item in receptionReceipt.deliveries"
                      :key="item.id"
                      class="border rounded p-3"
                    >
                      <div
                        class="d-flex justify-content-between gap-2"
                      >
                        <strong>
                          {{
                            item.delivery_method_display ||
                            item.delivery_method
                          }}
                        </strong>

                        <span class="badge text-bg-light">
                          {{
                            item.status_display ||
                            item.status
                          }}
                        </span>
                      </div>

                      <div class="small text-muted mt-2">
                        {{ formatDate(item.created_at) }}
                      </div>

                      <div
                        v-if="item.destination"
                        class="small mt-1"
                      >
                        <strong>Destino:</strong>
                        {{ item.destination }}
                      </div>

                      <div
                        v-if="item.delivered_by_username"
                        class="small"
                      >
                        <strong>Usuario:</strong>
                        {{ item.delivered_by_username }}
                      </div>

                      <div
                        v-if="notificationDisplayDetail(item.detail)"
                        class="small text-muted mt-1"
                      >
                        {{ notificationDisplayDetail(item.detail) }}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </template>
        </template>
      </section>

      <!-- HU-09: diagnóstico, reparación e historial real -->
      <section v-if="tab === 'diagnostico'" class="row g-3">
        <div :class="canViewTechnicalReportHistory ? 'col-lg-7' : 'col-12'">
          <div class="mc-card p-4">
            <h5>Diagnóstico y reparación</h5>
            <div class="small text-muted mb-3">
              Orden #{{ order.id }} · {{ order.equipment_description }} · Cliente: {{ order.client_name }}
            </div>

            <div v-if="reportError" class="alert alert-warning" role="alert">
              {{ reportError }}
            </div>
            <div v-else-if="!technicalReport" class="alert alert-info">
              Esta orden aún no tiene informe técnico. El formulario registra el diagnóstico,
              la reparación y el resultado en una sola operación.
            </div>
            <div v-else class="alert alert-light border small">
              Informe registrado por {{ technicalReport.created_by_username || 'usuario no disponible' }}
              el {{ formatDate(technicalReport.created_at) }}.
              Última actualización: {{ formatDate(technicalReport.updated_at) }}.
            </div>

            <div v-if="reportSuccess" class="alert alert-success" role="status">
              {{ reportSuccess }}
            </div>
            <div v-if="reportFormError" class="alert alert-danger" role="alert">
              {{ reportFormError }}
            </div>

            <form
              v-if="canEditReport && !['DELIVERED', 'CLOSED'].includes(order.status) && !reportError"
              @submit.prevent="saveTechnicalReport"
            >
              <label for="report-technician" class="form-label">Técnico responsable</label>
              <select
                id="report-technician"
                v-model.number="reportForm.technician"
                class="form-select mb-2"
                :disabled="reportSaving || techniciansLoading"
                required
              >
                <option value="">Seleccionar técnico...</option>
                <option
                  v-for="user in availableTechnicians()"
                  :key="user.id"
                  :value="user.id"
                >
                  {{ user.username }}
                </option>
              </select>
              <div v-if="techniciansLoading" class="form-text mb-2">Cargando técnicos...</div>
              <div v-if="techniciansError" class="alert alert-warning small" role="alert">
                {{ techniciansError }}
                <button type="button" class="btn btn-sm btn-outline-secondary ms-2" @click="loadTechnicians(loadSequence)">
                  Reintentar
                </button>
              </div>
              <div v-if="!techniciansLoading && !availableTechnicians().length" class="form-text mb-3">
                No hay técnicos disponibles. Registra o activa uno desde Usuarios.
              </div>
              <div v-else class="mb-3"></div>

              <label for="report-diagnosis" class="form-label">Diagnóstico definitivo</label>
              <textarea
                id="report-diagnosis"
                v-model="reportForm.diagnosis"
                class="form-control mb-3"
                rows="3"
                :disabled="reportSaving"
                required
              ></textarea>

              <label for="report-actions" class="form-label">Acciones de reparación</label>
              <textarea
                id="report-actions"
                v-model="reportForm.repair_actions"
                class="form-control mb-3"
                rows="3"
                :disabled="reportSaving"
                required
              ></textarea>

              <label for="report-observations" class="form-label">Observaciones de reparación (opcional)</label>
              <textarea
                id="report-observations"
                v-model="reportForm.repair_observations"
                class="form-control mb-3"
                rows="2"
                :disabled="reportSaving"
              ></textarea>

              <label for="report-parts" class="form-label">Descripción de repuestos (opcional)</label>
              <textarea
                id="report-parts"
                v-model="reportForm.parts_description"
                class="form-control mb-3"
                rows="2"
                :disabled="reportSaving"
                placeholder="Si no se utilizaron repuestos, deja este campo vacío."
              ></textarea>
              <div class="form-text mb-3">
                La vinculación con catálogo y proveedores se integrará en HU-13.
              </div>

              <label for="report-result" class="form-label">Resultado del servicio</label>
              <select
                id="report-result"
                v-model="reportForm.result"
                class="form-select mb-3"
                :disabled="reportSaving"
                required
              >
                <option value="">Seleccionar resultado...</option>
                <option v-for="result in reportResults" :key="result.value" :value="result.value">
                  {{ result.label }}
                </option>
              </select>

              <button type="submit" class="btn btn-primary" :disabled="reportSaving || techniciansLoading">
                <span v-if="reportSaving" class="spinner-border spinner-border-sm me-2"></span>
                {{ reportSaving ? 'Guardando...' : technicalReport ? 'Guardar cambios' : 'Registrar informe técnico' }}
              </button>
              <button
                v-if="technicalReport"
                type="button"
                class="btn btn-outline-secondary ms-2"
                :disabled="reportSaving"
                @click="resetReportForm"
              >
                Descartar cambios
              </button>
            </form>
            <div v-else-if="!canEditReport" class="alert alert-secondary mb-0">
              Tu rol permite consultar el informe, pero no modificarlo.
            </div>
            <div v-else-if="['DELIVERED', 'CLOSED'].includes(order.status)" class="alert alert-secondary mb-0">
              La orden ya fue entregada o cerrada. El informe se conserva para consulta.
            </div>

            <div v-if="technicalReport && (!canEditReport || ['DELIVERED', 'CLOSED'].includes(order.status))" class="mt-3">
              <div class="mb-2"><strong>Técnico:</strong> {{ technicalReport.technician_username }}</div>
              <div class="mb-2"><strong>Diagnóstico:</strong> {{ technicalReport.diagnosis }}</div>
              <div class="mb-2"><strong>Reparación:</strong> {{ technicalReport.repair_actions }}</div>
              <div class="mb-2"><strong>Observaciones:</strong> {{ technicalReport.repair_observations || 'Sin observaciones' }}</div>
              <div class="mb-2"><strong>Repuestos:</strong> {{ technicalReport.parts_description || 'Sin repuestos descritos' }}</div>
              <div><strong>Resultado:</strong> {{ technicalReport.result_display || technicalReport.result }}</div>
            </div>
          </div>
        </div>

        <div v-if="canViewTechnicalReportHistory" class="col-lg-5">
          <div class="mc-card p-4">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
              <h5 class="mb-0">Historial del informe</h5>
              <button
                v-if="technicalReport"
                type="button"
                class="btn btn-sm btn-outline-secondary"
                :disabled="reportHistoryLoading"
                @click="loadTechnicalReportHistory(order.id, loadSequence)"
              >
                Actualizar
              </button>
            </div>
            <div v-if="reportHistoryLoading" class="text-muted">Cargando revisiones...</div>
            <div v-else-if="reportHistoryError" class="alert alert-warning" role="alert">{{ reportHistoryError }}</div>
            <div v-else-if="!technicalReport" class="text-muted small">
              Las revisiones aparecerán cuando se registre el primer informe.
            </div>
            <div v-else-if="!technicalReportHistory.length" class="text-muted small">
              No hay revisiones disponibles.
            </div>
            <div v-else class="d-flex flex-column gap-3">
              <div
                v-for="revision in [...technicalReportHistory].reverse()"
                :key="revision.id"
                class="border rounded p-3"
              >
                <div class="fw-semibold">Revisión #{{ revision.revision }}</div>
                <div class="small text-muted mb-2">
                  {{ formatDate(revision.changed_at) }} ·
                  {{ revision.changed_by_username || 'Usuario no disponible' }}
                </div>
                <div class="small"><strong>Técnico:</strong> {{ revision.technician_username }}</div>
                <div class="small mt-1"><strong>Diagnóstico:</strong> {{ revision.diagnosis }}</div>
                <div class="small mt-1"><strong>Reparación:</strong> {{ revision.repair_actions }}</div>
                <div v-if="revision.repair_observations" class="small mt-1">
                  <strong>Observaciones:</strong> {{ revision.repair_observations }}
                </div>
                <div v-if="revision.parts_description" class="small mt-1">
                  <strong>Repuestos:</strong> {{ revision.parts_description }}
                </div>
                <div class="small mt-1">
                  <strong>Resultado:</strong> {{ revision.result_display || revision.result }}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- LÍNEA DE TIEMPO: historial persistido en PostgreSQL -->
      <section v-if="tab === 'linea'" class="row g-4">
        <div class="col-lg-7">
          <div class="mc-card p-4">
            <h5>Línea de tiempo</h5>
            <div v-if="historyError" class="alert alert-warning mt-3">
              {{ historyError }}
            </div>
            <div v-else-if="!history.length" class="text-muted mt-3">
              No hay eventos registrados para esta orden.
            </div>
            <div v-else class="timeline mt-4">
              <div
                v-for="event in [...history].reverse()"
                :key="event.id"
                class="timeline-item"
              >
                <div class="fw-semibold">
                  <template v-if="event.from_status">
                    {{ event.from_status_display || event.from_status }} →
                  </template>
                  {{ event.to_status_display || event.to_status }}
                </div>
                <div class="small text-muted">
                  {{ formatDate(event.changed_at) }}
                  · {{ event.changed_by_username || 'Usuario no disponible' }}
                </div>
                <div v-if="event.note" class="mt-1">{{ event.note }}</div>

                <div
                  v-if="event.notifications?.length"
                  class="mt-2"
                >
                  <div
                    v-for="notification in event.notifications"
                    :key="notification.id"
                    class="border rounded p-2 small mt-2"
                  >
                    <div class="d-flex flex-wrap align-items-center gap-2">
                      <strong>
                        {{ statusNotificationChannelLabel(notification) }}
                      </strong>
                      <span
                        class="badge"
                        :class="
                          notification.status === 'SENT'
                            ? 'text-bg-success'
                            : notification.status === 'PREPARED'
                              ? 'text-bg-info'
                              : 'text-bg-warning'
                        "
                      >
                        {{ notification.status_display || notification.status }}
                      </span>
                    </div>

                    <div
                      v-if="notification.destination"
                      class="text-muted mt-1"
                    >
                      Destino: {{ notification.destination }}
                    </div>

                    <div
                      v-if="notificationDisplayDetail(notification.detail)"
                      class="text-muted mt-1"
                    >
                      {{ notificationDisplayDetail(notification.detail) }}
                    </div>

                    <div class="text-muted mt-1">
                      {{ formatDate(notification.created_at) }}
                      <template v-if="notification.triggered_by_username">
                        · {{ notification.triggered_by_username }}
                      </template>
                    </div>

                    <a
                      v-if="
                        notification.status === 'PREPARED' &&
                        notification.action_url
                      "
                      :href="notification.action_url"
                      target="_blank"
                      rel="noopener noreferrer"
                      class="btn btn-sm btn-outline-success mt-2"
                    >
                      Abrir WhatsApp
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-5">
          <div class="mc-card p-4">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
              <h5 class="mb-0">Estado de la orden</h5>
              <button type="button" class="btn btn-sm btn-outline-secondary"
                :disabled="statusLoading || statusSaving" @click="refreshOrderTracking">
                {{ statusLoading ? 'Actualizando...' : 'Actualizar' }}
              </button>
            </div>
            <StatusBadge
              :status="order.status"
              :label="order.status_display || order.status"
            />
            <div v-if="statusError" class="alert alert-warning small mt-3" role="alert">
              {{ statusError }}
            </div>
            <div v-if="statusSuccess" class="alert alert-success small mt-3" role="status">
              {{ statusSuccess }}
            </div>

            <div
              v-if="statusNotificationFeedback"
              class="alert small mt-3"
              :class="statusNotificationAlertClass(statusNotificationFeedback)"
              role="status"
            >
              <div class="fw-semibold">
                {{ statusNotificationTitle(statusNotificationFeedback) }}
              </div>

              <div class="mt-1">
                Canal:
                <strong>
                  {{ statusNotificationChannelLabel(statusNotificationFeedback) }}
                </strong>
              </div>

              <div
                v-if="statusNotificationFeedback.destination"
                class="mt-1"
              >
                Destino: {{ statusNotificationFeedback.destination }}
              </div>

              <div
                v-if="notificationDisplayDetail(statusNotificationFeedback.detail)"
                class="mt-1"
              >
                {{ notificationDisplayDetail(statusNotificationFeedback.detail) }}
              </div>

              <a
                v-if="
                  statusNotificationFeedback.status === 'PREPARED' &&
                  statusNotificationFeedback.action_url
                "
                :href="statusNotificationFeedback.action_url"
                target="_blank"
                rel="noopener noreferrer"
                class="btn btn-sm btn-success mt-2"
              >
                Abrir WhatsApp
              </a>
            </div>

            <div v-if="statusFormError" class="alert alert-danger small mt-3" role="alert">
              {{ statusFormError }}
            </div>
            <form v-if="canChangeStatus && statusInfo?.allowed_transitions?.length"
              class="mt-3" @submit.prevent="changeOrderStatus">
              <label class="form-label" for="next-order-status">Siguiente estado permitido</label>
              <select id="next-order-status" v-model="nextStatus" class="form-select mb-3"
                :disabled="statusSaving || statusLoading" required>
                <option value="" disabled>Seleccionar estado...</option>
                <option v-for="item in statusInfo.allowed_transitions" :key="item.status"
                  :value="item.status">{{ item.status_display }}</option>
              </select>
              <label class="form-label" for="order-status-note">Observación del cambio (opcional)</label>
              <textarea id="order-status-note" v-model="statusNote" class="form-control mb-3"
                rows="3" maxlength="1000" :disabled="statusSaving || statusLoading"
                placeholder="Ej.: Se inicia el diagnóstico del equipo."></textarea>
              <button type="submit" class="btn btn-primary"
                :disabled="statusSaving || statusLoading || !nextStatus">
                <span v-if="statusSaving" class="spinner-border spinner-border-sm me-2"></span>
                {{ statusSaving ? 'Guardando...' : 'Guardar cambio de estado' }}
              </button>
              <p class="small text-muted mt-2 mb-0">
                Django valida la transición y registra estado anterior, nuevo estado, fecha y usuario.
              </p>
            </form>
            <p v-else-if="canChangeStatus && statusInfo && !statusInfo.allowed_transitions?.length"
              class="small text-muted mt-3 mb-0">
              Esta orden no tiene transiciones disponibles desde su estado actual.
            </p>
            <p v-else-if="!canChangeStatus" class="small text-muted mt-3 mb-0">
              Tu perfil puede consultar el estado y el historial, pero no modificarlos.
            </p>
          </div>
        </div>
      </section>

      <!-- HU-08: evidencias fotográficas privadas de esta orden -->
      <section v-if="tab === 'evidencias'" class="row g-3">
        <div class="col-lg-5">
          <div class="mc-card p-4">
            <h5>Adjuntar evidencia</h5>
            <div class="alert alert-info small mb-3" role="status">
              <div class="fw-semibold mb-1">Esta fotografía se asociará a:</div>
              <div><strong>Orden:</strong> #{{ order.id }} · {{ order.tracking_code }}</div>
              <div><strong>Cliente:</strong> {{ order.client_name }}</div>
              <div><strong>Equipo:</strong> {{ order.equipment_description }} · Equipo #{{ order.equipment }}</div>
              <div class="mt-1">La asociación se realiza automáticamente con la orden abierta.</div>
            </div>
            <p class="small text-muted">
              Usa fotografías ficticias o sin datos identificatorios. Antes de publicar
              imágenes en presentaciones o repositorios, oculta los datos personales
              y los identificadores del equipo.
            </p>

            <div v-if="uploadError" class="alert alert-danger" role="alert">{{ uploadError }}</div>
            <div v-if="uploadSuccess" class="alert alert-success" role="status">{{ uploadSuccess }}</div>

            <form @submit.prevent="uploadEvidence">
              <label for="evidence-stage" class="form-label">Etapa del servicio</label>
              <select
                id="evidence-stage"
                v-model="evidenceStage"
                class="form-select mb-3"
                :disabled="uploadingEvidence"
                required
              >
                <option v-for="stage in evidenceStages" :key="stage.value" :value="stage.value">
                  {{ stage.label }}
                </option>
              </select>

              <label for="evidence-description" class="form-label">Descripción (opcional)</label>
              <textarea
                id="evidence-description"
                v-model="evidenceDescription"
                class="form-control mb-3"
                maxlength="250"
                rows="2"
                :disabled="uploadingEvidence"
                placeholder="Ej.: Estado del equipo al ingresar."
              ></textarea>

              <label for="evidence-file" class="form-label">Fotografía</label>
              <input
                id="evidence-file"
                ref="evidenceInput"
                type="file"
                accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                class="form-control mb-2"
                :disabled="uploadingEvidence"
                required
                @change="selectEvidenceFile"
              >
              <div class="form-text mb-3">JPG, JPEG, PNG o WEBP; máximo 20 MB por archivo.</div>

              <button
                type="submit"
                class="btn btn-primary"
                :disabled="uploadingEvidence || !evidenceFile"
              >
                <span v-if="uploadingEvidence" class="spinner-border spinner-border-sm me-2"></span>
                {{ uploadingEvidence ? 'Subiendo...' : 'Guardar evidencia' }}
              </button>
            </form>
          </div>
        </div>

        <div class="col-lg-7">
          <div class="mc-card p-4">
            <div class="d-flex justify-content-between gap-2 align-items-center mb-3">
              <h5 class="mb-0">Evidencias registradas</h5>
              <button
                type="button"
                class="btn btn-sm btn-outline-secondary"
                :disabled="evidenceLoading"
                @click="loadEvidences"
              >
                Actualizar
              </button>
            </div>
            <div v-if="evidenceLoading" class="text-muted">Cargando evidencias...</div>
            <div v-else-if="evidenceError" class="alert alert-danger" role="alert">
              {{ evidenceError }}
            </div>
            <div v-else-if="!evidences.length" class="text-muted">
              Esta orden todavía no tiene evidencias fotográficas.
            </div>
            <div v-else class="d-flex flex-column gap-3">
              <div v-for="item in evidences" :key="item.id" class="border rounded p-3">
                <div class="d-flex flex-wrap justify-content-between gap-2">
                  <strong>{{ stageLabel(item.stage) }} · Evidencia #{{ item.id }}</strong>
                  <span class="small text-muted">{{ formatDate(item.created_at) }}</span>
                </div>
                <div class="small mt-1">Registrada por: {{ item.uploaded_by_username || 'No disponible' }}</div>
                <div v-if="item.description" class="mt-2">{{ item.description }}</div>

                <div v-if="imageErrors[item.id]" class="alert alert-warning small mt-2 mb-0">
                  {{ imageErrors[item.id] }}
                </div>
                <div class="d-flex flex-wrap gap-2 mt-3">
                  <button
                    type="button"
                    class="btn btn-sm btn-outline-primary"
                    :disabled="imageLoading[item.id]"
                    @click="toggleEvidenceImage(item)"
                  >
                    {{ imageLoading[item.id] ? 'Cargando imagen...' : imageUrls[item.id] ? 'Ocultar fotografía' : 'Ver fotografía' }}
                  </button>
                  <a
                    v-if="imageUrls[item.id]"
                    :href="imageUrls[item.id]"
                    :download="`evidencia-${item.id}`"
                    class="btn btn-sm btn-outline-secondary"
                  >
                    Descargar
                  </a>
                </div>
                <img
                  v-if="imageUrls[item.id]"
                  :src="imageUrls[item.id]"
                  :alt="`Evidencia ${item.id}: ${stageLabel(item.stage)}`"
                  class="img-fluid rounded border mt-3"
                  style="max-height: 360px; object-fit: contain;"
                >
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- HU-13: uso real de repuestos y costos históricos de esta orden. -->
      <section v-if="tab === 'repuestos'" class="row g-3">
        <div class="col-lg-7">
          <div class="mc-card p-4">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
              <h5 class="mb-0">Repuestos utilizados</h5>
              <button
                type="button"
                class="btn btn-sm btn-outline-secondary"
                :disabled="orderPartsLoading || orderPartSaving"
                @click="refreshPartsAndFinancial"
              >
                {{ orderPartsLoading ? 'Actualizando...' : 'Actualizar' }}
              </button>
            </div>
            <div v-if="canViewFinancial" class="small text-muted mb-3">
              Orden #{{ order.id }} · {{ order.tracking_code }}. Los costos registrados aquí
              se conservan aunque cambie el catálogo.
            </div>
            <div v-if="orderPartsError" class="alert alert-danger" role="alert">
              {{ orderPartsError }}
            </div>
            <div v-if="orderPartsLoading" class="text-muted">Cargando repuestos utilizados...</div>
            <div v-else-if="!orderPartsError && !usedParts.length" class="text-muted">
              Esta orden todavía no tiene repuestos asociados.
            </div>
            <div v-else-if="usedParts.length" class="table-responsive">
              <table class="table table-hover align-middle mb-0">
                <thead>
                  <tr>
                    <th>Repuesto / proveedor</th>
                    <th class="text-end">Cantidad</th>
                    <th v-if="canViewFinancial" class="text-end">Costo unitario</th>
                    <th v-if="canViewFinancial" class="text-end">Subtotal</th>
                    <th v-if="canCorrectParts || canCancelParts" class="text-end">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  <template v-for="item in usedParts" :key="item.id">
                    <tr :class="{ 'table-secondary': item.is_cancelled }">
                      <td>
                        <div class="d-flex flex-wrap align-items-center gap-2">
                          <strong :class="{ 'text-decoration-line-through': item.is_cancelled }">
                            {{ item.part_name }}
                          </strong>
                          <span v-if="item.is_cancelled" class="badge bg-secondary">
                            ANULADO
                          </span>
                        </div>
                        <div class="small text-muted">{{ item.supplier_name }}</div>
                        <div class="small text-muted">
                          {{ formatDate(item.created_at) }} · {{ item.created_by_username || 'Usuario no disponible' }}
                        </div>
                        <div v-if="item.note" class="small mt-1">{{ item.note }}</div>
                        <div v-if="item.is_cancelled" class="small text-muted mt-2">
                          <div>
                            <strong>Anulación:</strong>
                            {{ item.cancellation_reason || 'Sin motivo disponible' }}
                          </div>
                          <div>
                            {{ formatDate(item.cancelled_at) }} ·
                            {{ item.cancelled_by_username || 'Usuario no disponible' }}
                            <span v-if="item.cancelled_by_role"> · {{ item.cancelled_by_role }}</span>
                          </div>
                        </div>
                        <div
                          v-if="orderPartCancellationSuccess[item.id]"
                          class="small text-success mt-2"
                        >
                          {{ orderPartCancellationSuccess[item.id] }}
                        </div>
                      </td>
                      <td class="text-end" :class="{ 'text-decoration-line-through': item.is_cancelled }">
                        {{ item.quantity }}
                      </td>
                      <td
                        v-if="canViewFinancial"
                        class="text-end"
                        :class="{ 'text-decoration-line-through': item.is_cancelled }"
                      >
                        {{ formatMoney(item.unit_cost) }}
                      </td>
                      <td v-if="canViewFinancial" class="text-end">
                        <span :class="{ 'text-decoration-line-through text-muted': item.is_cancelled }">
                          {{ formatMoney(item.subtotal) }}
                        </span>
                        <div v-if="item.is_cancelled" class="small text-muted">No vigente</div>
                      </td>
                      <td v-if="canCorrectParts || canCancelParts" class="text-end text-nowrap">
                        <button
                          v-if="canCorrectParts && !item.is_cancelled"
                          type="button"
                          class="btn btn-sm btn-outline-primary me-1"
                          :disabled="
                            ['DELIVERED', 'CLOSED'].includes(order.status)
                            || isOrderPartCorrectionSaving(item.id)
                            || isOrderPartCancellationSaving(item.id)
                          "
                          @click="toggleOrderPartCorrection(item)"
                        >
                          {{ Number(orderPartCorrectionOpenId) === Number(item.id) ? 'Cerrar' : 'Corregir' }}
                        </button>
                        <button
                          v-if="canCancelParts && !item.is_cancelled"
                          type="button"
                          class="btn btn-sm btn-outline-danger me-1"
                          :disabled="
                            ['DELIVERED', 'CLOSED'].includes(order.status)
                            || isOrderPartCorrectionSaving(item.id)
                            || isOrderPartCancellationSaving(item.id)
                          "
                          @click="toggleOrderPartCancellation(item)"
                        >
                          {{
                            Number(orderPartCancellationOpenId) === Number(item.id)
                              ? 'Cerrar anulación'
                              : 'Anular'
                          }}
                        </button>
                        <button
                          v-if="canCorrectParts"
                          type="button"
                          class="btn btn-sm btn-outline-secondary"
                          :disabled="orderPartCorrectionHistoryLoading[item.id]"
                          @click="toggleOrderPartCorrectionHistory(item)"
                        >
                          {{
                            Number(expandedOrderPartCorrectionHistoryId) === Number(item.id)
                              ? 'Ocultar historial'
                              : 'Historial'
                          }}
                        </button>
                      </td>
                    </tr>

                    <tr
                      v-if="
                        canCorrectParts
                        && !item.is_cancelled
                        && Number(orderPartCorrectionOpenId) === Number(item.id)
                      "
                    >
                      <td colspan="5" class="bg-light">
                        <div class="p-2">
                          <h6 class="mb-2">Corregir uso de repuesto #{{ item.id }}</h6>
                          <p class="small text-muted mb-3">
                            HU-24 permite corregir cantidad o nota. Repuesto, proveedor y costo unitario
                            conservan su valor histórico. Si existe una garantía asociada, la cantidad no
                            puede modificarse.
                          </p>

                          <div
                            v-if="orderPartCorrectionSuccess[item.id]"
                            class="alert alert-success py-2"
                            role="status"
                          >
                            {{ orderPartCorrectionSuccess[item.id] }}
                          </div>
                          <div
                            v-if="orderPartCorrectionErrors[item.id]"
                            class="alert alert-danger py-2"
                            role="alert"
                          >
                            {{ orderPartCorrectionErrors[item.id] }}
                          </div>

                          <form
                            v-if="orderPartCorrectionForms[item.id]"
                            @submit.prevent="submitOrderPartCorrection(item)"
                          >
                            <div class="row g-3">
                              <div class="col-md-3">
                                <label :for="`correction-field-${item.id}`" class="form-label">
                                  Dato a corregir
                                </label>
                                <select
                                  :id="`correction-field-${item.id}`"
                                  v-model="orderPartCorrectionForms[item.id].field_name"
                                  class="form-select"
                                  :disabled="isOrderPartCorrectionSaving(item.id)"
                                >
                                  <option value="QUANTITY">Cantidad</option>
                                  <option value="NOTE">Nota</option>
                                </select>
                              </div>

                              <div
                                v-if="orderPartCorrectionForms[item.id].field_name === 'QUANTITY'"
                                class="col-md-3"
                              >
                                <label :for="`correction-quantity-${item.id}`" class="form-label">
                                  Nueva cantidad
                                </label>
                                <input
                                  :id="`correction-quantity-${item.id}`"
                                  v-model.number="orderPartCorrectionForms[item.id].quantity"
                                  type="number"
                                  min="1"
                                  step="1"
                                  class="form-control"
                                  :disabled="isOrderPartCorrectionSaving(item.id)"
                                  required
                                >
                                <div class="form-text">Cantidad actual: {{ item.quantity }}</div>
                              </div>

                              <div v-else class="col-md-5">
                                <label :for="`correction-note-${item.id}`" class="form-label">
                                  Nueva nota
                                </label>
                                <textarea
                                  :id="`correction-note-${item.id}`"
                                  v-model="orderPartCorrectionForms[item.id].note"
                                  class="form-control"
                                  rows="2"
                                  maxlength="250"
                                  :disabled="isOrderPartCorrectionSaving(item.id)"
                                ></textarea>
                              </div>

                              <div class="col-md">
                                <label :for="`correction-reason-${item.id}`" class="form-label">
                                  Motivo de la corrección
                                </label>
                                <textarea
                                  :id="`correction-reason-${item.id}`"
                                  v-model="orderPartCorrectionForms[item.id].reason"
                                  class="form-control"
                                  rows="2"
                                  :disabled="isOrderPartCorrectionSaving(item.id)"
                                  placeholder="Explica por qué se corrige este registro."
                                  required
                                ></textarea>
                              </div>
                            </div>

                            <div class="mt-3 d-flex flex-wrap gap-2">
                              <button
                                type="submit"
                                class="btn btn-primary btn-sm"
                                :disabled="isOrderPartCorrectionSaving(item.id)"
                              >
                                <span
                                  v-if="isOrderPartCorrectionSaving(item.id)"
                                  class="spinner-border spinner-border-sm me-2"
                                ></span>
                                {{
                                  isOrderPartCorrectionSaving(item.id)
                                    ? 'Guardando corrección...'
                                    : 'Guardar corrección'
                                }}
                              </button>
                              <button
                                type="button"
                                class="btn btn-outline-secondary btn-sm"
                                :disabled="isOrderPartCorrectionSaving(item.id)"
                                @click="orderPartCorrectionOpenId = null"
                              >
                                Cancelar
                              </button>
                            </div>
                          </form>
                        </div>
                      </td>
                    </tr>

                    <tr
                      v-if="
                        canCancelParts
                        && !item.is_cancelled
                        && Number(orderPartCancellationOpenId) === Number(item.id)
                      "
                    >
                      <td colspan="5" class="bg-light">
                        <div class="p-2">
                          <h6 class="mb-2 text-danger">
                            Anular uso de repuesto #{{ item.id }}
                          </h6>
                          <p class="small text-muted mb-3">
                            La anulación conserva el antecedente histórico, devuelve
                            {{ item.quantity }} unidad(es) al stock y elimina este consumo
                            de los costos vigentes. No se puede realizar si existe una
                            garantía asociada o si la orden está entregada o cerrada.
                          </p>

                          <div
                            v-if="orderPartCancellationErrors[item.id]"
                            class="alert alert-danger py-2"
                            role="alert"
                          >
                            {{ orderPartCancellationErrors[item.id] }}
                          </div>

                          <form
                            v-if="orderPartCancellationForms[item.id]"
                            @submit.prevent="submitOrderPartCancellation(item)"
                          >
                            <label
                              :for="`cancellation-reason-${item.id}`"
                              class="form-label"
                            >
                              Motivo de la anulación
                            </label>
                            <textarea
                              :id="`cancellation-reason-${item.id}`"
                              v-model="orderPartCancellationForms[item.id].reason"
                              class="form-control"
                              rows="3"
                              :disabled="isOrderPartCancellationSaving(item.id)"
                              placeholder="Explica por qué este uso de repuesto debe anularse."
                              required
                            ></textarea>

                            <div class="mt-3 d-flex flex-wrap gap-2">
                              <button
                                type="submit"
                                class="btn btn-danger btn-sm"
                                :disabled="isOrderPartCancellationSaving(item.id)"
                              >
                                <span
                                  v-if="isOrderPartCancellationSaving(item.id)"
                                  class="spinner-border spinner-border-sm me-2"
                                ></span>
                                {{
                                  isOrderPartCancellationSaving(item.id)
                                    ? 'Anulando...'
                                    : 'Confirmar anulación'
                                }}
                              </button>
                              <button
                                type="button"
                                class="btn btn-outline-secondary btn-sm"
                                :disabled="isOrderPartCancellationSaving(item.id)"
                                @click="orderPartCancellationOpenId = null"
                              >
                                Cancelar
                              </button>
                            </div>
                          </form>
                        </div>
                      </td>
                    </tr>

                    <tr
                      v-if="
                        canCorrectParts
                        && Number(expandedOrderPartCorrectionHistoryId) === Number(item.id)
                      "
                    >
                      <td colspan="5" class="bg-light">
                        <div class="p-2">
                          <div class="d-flex justify-content-between align-items-center gap-2 mb-2">
                            <h6 class="mb-0">Historial de correcciones</h6>
                            <button
                              type="button"
                              class="btn btn-sm btn-outline-secondary"
                              :disabled="orderPartCorrectionHistoryLoading[item.id]"
                              @click="loadOrderPartCorrectionHistory(item.id)"
                            >
                              {{
                                orderPartCorrectionHistoryLoading[item.id]
                                  ? 'Actualizando...'
                                  : 'Actualizar'
                              }}
                            </button>
                          </div>

                          <div
                            v-if="orderPartCorrectionHistoryErrors[item.id]"
                            class="alert alert-danger py-2"
                            role="alert"
                          >
                            {{ orderPartCorrectionHistoryErrors[item.id] }}
                          </div>
                          <div
                            v-else-if="orderPartCorrectionHistoryLoading[item.id]"
                            class="text-muted small"
                          >
                            Cargando historial...
                          </div>
                          <div
                            v-else-if="!(orderPartCorrectionHistoryById[item.id] || []).length"
                            class="text-muted small"
                          >
                            Este uso todavía no tiene correcciones registradas.
                          </div>
                          <div v-else class="vstack gap-2">
                            <div
                              v-for="change in orderPartCorrectionHistoryById[item.id]"
                              :key="change.id"
                              class="border rounded bg-white p-3"
                            >
                              <div class="d-flex flex-wrap justify-content-between gap-2">
                                <strong>{{ change.field_display || change.field_name }}</strong>
                                <span class="small text-muted">{{ formatDate(change.changed_at) }}</span>
                              </div>
                              <div class="small mt-1">
                                <span class="text-muted">Anterior:</span>
                                {{ change.old_value === '' ? 'Sin nota' : change.old_value }}
                                <span class="mx-1">→</span>
                                <span class="text-muted">Nuevo:</span>
                                {{ change.new_value === '' ? 'Sin nota' : change.new_value }}
                              </div>
                              <div class="small mt-1">
                                <span class="text-muted">Motivo:</span> {{ change.reason }}
                              </div>
                              <div class="small text-muted mt-1">
                                {{ change.changed_by_username || 'Usuario no disponible' }}
                                <span v-if="change.changed_by_role"> · {{ change.changed_by_role }}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </template>
                </tbody>
                <tfoot v-if="canViewFinancial">
                  <tr class="fw-bold">
                    <td :colspan="(canCorrectParts || canCancelParts) ? 4 : 3" class="text-end">Total de repuestos vigentes</td>
                    <td class="text-end">{{ formatMoney(financial?.parts_cost ?? usedPartsTotal) }}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>

        <div class="col-lg-5">
          <div class="mc-card p-4">
            <h5>Asociar repuesto a esta orden</h5>
            <p class="small text-muted">
              Registrar un uso descontará inmediatamente la cantidad del stock del catálogo.
              Si luego detectas un error en la cantidad o nota, puedes corregirlo con trazabilidad.
              También puedes anular completamente un consumo ingresado por error; el registro
              histórico se conserva y el stock se devuelve una sola vez.
            </p>
            <div v-if="orderPartSuccess" class="alert alert-success" role="status">
              {{ orderPartSuccess }}
            </div>
            <div v-if="orderPartFormError" class="alert alert-danger" role="alert">
              {{ orderPartFormError }}
            </div>
            <div v-if="partCatalogError" class="alert alert-warning" role="alert">
              {{ partCatalogError }}
            </div>
            <div v-if="['DELIVERED', 'CLOSED'].includes(order.status)" class="alert alert-secondary">
              No es posible registrar repuestos en una orden entregada o cerrada.
            </div>
            <div v-else-if="!canRegisterParts" class="alert alert-info">
              Tu perfil puede consultar los repuestos, pero no registrar nuevos usos.
            </div>
            <template v-else>
              <div v-if="!orderPartsLoading && !partCatalogError && !partCatalog.some(item => item.is_active && item.stock > 0)" class="alert alert-info small">
                No hay repuestos activos con stock disponible. Registra o actualiza
                el catálogo desde <router-link to="/repuestos">Repuestos</router-link>.
              </div>
              <form @submit.prevent="registerOrderPart">
                <label for="order-part-select" class="form-label">Repuesto</label>
                <select
                  id="order-part-select"
                  v-model.number="orderPartForm.part"
                  class="form-select mb-3"
                  :disabled="orderPartSaving || orderPartsLoading || !!partCatalogError"
                  required
                >
                  <option value="" disabled>Seleccionar repuesto...</option>
                  <option
                    v-for="item in partCatalog.filter(item => item.is_active && item.stock > 0)"
                    :key="item.id"
                    :value="item.id"
                  >
                    {{ item.name }} · {{ item.supplier_name }} ({{ item.stock }} disponibles)
                  </option>
                </select>
                <div v-if="selectedPart" class="alert alert-light border small">
                  Stock disponible: <strong>{{ selectedPart.stock }}</strong> ·
                  Costo unitario actual: <strong>{{ formatMoney(selectedPart.unit_cost) }}</strong>
                </div>
                <label for="order-part-quantity" class="form-label">Cantidad utilizada</label>
                <input
                  id="order-part-quantity"
                  v-model.number="orderPartForm.quantity"
                  type="number"
                  min="1"
                  step="1"
                  :max="selectedPart?.stock || undefined"
                  class="form-control mb-3"
                  :disabled="orderPartSaving || orderPartsLoading"
                  required
                >
                <label for="order-part-note" class="form-label">Observación (opcional)</label>
                <textarea
                  id="order-part-note"
                  v-model="orderPartForm.note"
                  class="form-control mb-3"
                  rows="2"
                  maxlength="250"
                  :disabled="orderPartSaving || orderPartsLoading"
                  placeholder="Ej.: Pantalla instalada durante reparación."
                ></textarea>
                <button
                  type="submit"
                  class="btn btn-primary"
                  :disabled="orderPartSaving || orderPartsLoading || !!partCatalogError || !selectedPart || !selectedPart.is_active || selectedPart.stock < 1"
                >
                  <span v-if="orderPartSaving" class="spinner-border spinner-border-sm me-2"></span>
                  {{ orderPartSaving ? 'Registrando...' : 'Registrar uso y descontar stock' }}
                </button>
              </form>
            </template>
          </div>
        </div>

        <!-- HU-14: costos directos y margen calculados por el backend. -->
        <div class="col-12">
          <div class="mc-card p-4">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
              <h5 class="mb-0">Costos, precio y margen estimado</h5>
              <button
                v-if="canViewFinancial"
                type="button"
                class="btn btn-sm btn-outline-secondary"
                :disabled="financialLoading || financialSaving"
                @click="loadFinancial"
              >
                {{ financialLoading ? 'Actualizando...' : 'Actualizar cálculo' }}
              </button>
            </div>
            <div v-if="!canViewFinancial" class="alert alert-info mb-0" role="status">
              Tu perfil puede consultar los repuestos, pero no la información financiera de la orden.
            </div>
            <template v-else>
              <div v-if="financialError" class="alert alert-danger" role="alert">{{ financialError }}</div>
              <div v-if="financialLoading" class="text-muted">Cargando resumen financiero...</div>
              <template v-else-if="financial">
                <div v-if="!financial.has_financial_record" class="alert alert-info small" role="status">
                  Aún no hay un registro financiero. El costo de los repuestos se calcula igualmente desde sus usos vigentes.
                </div>

                <div class="row g-3 mb-3">
                  <div class="col-md-4 col-lg-3">
                    <div class="small text-muted">Precio cobrado</div>
                    <div class="fs-5 fw-semibold">{{ financial.price_charged === null ? 'Pendiente' : formatMoney(financial.price_charged) }}</div>
                  </div>
                  <div class="col-md-4 col-lg-3">
                    <div class="small text-muted">Repuestos (HU-13)</div>
                    <div class="fs-5 fw-semibold">{{ formatMoney(financial.parts_cost) }}</div>
                  </div>
                  <div class="col-md-4 col-lg-3">
                    <div class="small text-muted">Mano de obra</div>
                    <div class="fs-5 fw-semibold">{{ formatMoney(financial.labor_cost) }}</div>
                  </div>
                  <div class="col-md-4 col-lg-3">
                    <div class="small text-muted">Otros costos directos</div>
                    <div class="fs-5 fw-semibold">{{ formatMoney(financial.other_direct_cost) }}</div>
                  </div>
                  <div class="col-md-4 col-lg-4">
                    <div class="small text-muted">Costo directo total</div>
                    <div class="fs-5 fw-semibold">{{ formatMoney(financial.total_direct_cost) }}</div>
                  </div>
                  <div class="col-md-4 col-lg-4">
                    <div class="small text-muted">Margen estimado</div>
                    <div class="fs-5 fw-semibold" :class="{ 'text-danger': financial.estimated_margin !== null && Number(financial.estimated_margin) < 0 }">
                      {{ financial.estimated_margin === null ? 'Pendiente de precio' : formatMoney(financial.estimated_margin) }}
                    </div>
                  </div>
                  <div class="col-md-4 col-lg-4">
                    <div class="small text-muted">Margen estimado (%)</div>
                    <div class="fs-5 fw-semibold">
                      {{ financial.estimated_margin_percent !== null ? `${financial.estimated_margin_percent} %` : (financial.price_charged === null ? 'Pendiente' : 'No calculable con precio $0') }}
                    </div>
                  </div>
                </div>
                <p class="small text-muted mb-0">
                  Costo directo total = repuestos + mano de obra + otros costos directos.
                  Margen estimado = precio cobrado − costo directo total. El porcentaje se calcula solo si el precio es mayor que cero.
                  Los resultados proceden de Django; los usos de repuesto anulados se conservan como historial, pero no se incluyen en el costo vigente.
                </p>

                <hr class="my-4">
                <div v-if="financialSuccess" class="alert alert-success" role="status">{{ financialSuccess }}</div>
                <div v-if="financialFormError" class="alert alert-danger" role="alert">{{ financialFormError }}</div>
                <div v-if="canEditFinancial">
                  <h6 class="mb-3">Registrar o modificar datos financieros</h6>
                  <form @submit.prevent="saveFinancial">
                    <div class="row g-3">
                      <div class="col-md-4">
                        <label for="financial-price" class="form-label">Precio cobrado (CLP)</label>
                        <input
                          id="financial-price"
                          v-model="financialForm.price_charged"
                          type="number"
                          min="0"
                          step="0.01"
                          class="form-control"
                          placeholder="Dejar vacío si está pendiente"
                          :disabled="financialSaving"
                        >
                        <div class="form-text">Déjalo vacío si todavía no hay un precio definido. Un valor de 0 es distinto de pendiente.</div>
                      </div>
                      <div class="col-md-4">
                        <label for="financial-labor" class="form-label">Costo de mano de obra (CLP)</label>
                        <input
                          id="financial-labor"
                          v-model="financialForm.labor_cost"
                          type="number"
                          min="0"
                          step="0.01"
                          class="form-control"
                          :disabled="financialSaving"
                          required
                        >
                      </div>
                      <div class="col-md-4">
                        <label for="financial-other" class="form-label">Otros costos directos (CLP)</label>
                        <input
                          id="financial-other"
                          v-model="financialForm.other_direct_cost"
                          type="number"
                          min="0"
                          step="0.01"
                          class="form-control"
                          :disabled="financialSaving"
                          required
                        >
                      </div>
                      <div class="col-12">
                        <label for="financial-notes" class="form-label">Observaciones financieras (opcional)</label>
                        <textarea
                          id="financial-notes"
                          v-model="financialForm.notes"
                          class="form-control"
                          rows="2"
                          :disabled="financialSaving"
                          placeholder="Ej.: Precio acordado al aprobar el presupuesto."
                        ></textarea>
                      </div>
                      <div class="col-12">
                        <button type="submit" class="btn btn-primary" :disabled="financialSaving || financialLoading">
                          <span v-if="financialSaving" class="spinner-border spinner-border-sm me-2"></span>
                          {{ financialSaving ? 'Guardando...' : 'Guardar datos financieros' }}
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
                <p v-else class="small text-muted mb-0">Solo un administrador puede modificar los datos financieros.</p>
              </template>
            </template>
          </div>
        </div>
      </section>

      <!-- HU-15: garantías del servicio/repuestos y trazabilidad de revisiones. -->
      <section v-if="tab === 'garantia'" class="row g-3">
        <div v-if="!canViewWarranties" class="col-12">
          <div class="alert alert-info" role="status">
            Tu perfil no tiene permiso para consultar las garantías de esta orden.
          </div>
        </div>
        <template v-else>
          <div class="col-lg-7">
            <div class="mc-card p-4">
              <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <h5 class="mb-0">Garantías registradas</h5>
                <button
                  type="button"
                  class="btn btn-sm btn-outline-secondary"
                  :disabled="warrantyLoading || warrantySaving || warrantyDeletingId !== null"
                  @click="loadWarranties"
                >
                  {{ warrantyLoading ? 'Actualizando...' : 'Actualizar' }}
                </button>
              </div>
              <p class="small text-muted">
                Garantías de la orden #{{ order.id }} · {{ order.tracking_code }}.
                La vigencia se calcula a partir de las fechas registradas.
              </p>
              <div v-if="warrantyError" class="alert alert-danger" role="alert">
                {{ warrantyError }}
              </div>
              <div v-if="warrantyLoading" class="text-muted">Cargando garantías...</div>
              <div v-else-if="!warrantyError && !warranties.length" class="alert alert-info mb-0" role="status">
                Esta orden todavía no tiene garantías registradas.
              </div>
              <div v-else class="d-flex flex-column gap-3">
                <div v-for="item in warranties" :key="item.id" class="border rounded p-3">
                  <div class="d-flex flex-wrap align-items-center justify-content-between gap-2">
                    <strong>{{ item.warranty_type_display || (item.warranty_type === 'SERVICE' ? 'Garantía del servicio' : 'Garantía de repuesto') }} #{{ item.id }}</strong>
                    <div class="d-flex flex-wrap align-items-center gap-2">
                      <span class="badge" :class="warrantyBadgeClass(item.status)">
                        {{ warrantyStatusLabels[item.status] || item.status }}
                      </span>
                      <span class="badge bg-light text-dark border">
                        {{ warrantyRequestCount(item.id) }}
                        {{ warrantyRequestCount(item.id) === 1 ? 'solicitud' : 'solicitudes' }}
                      </span>
                    </div>
                  </div>
                  <div v-if="item.warranty_type === 'PART'" class="small mt-2">
                    <strong>Repuesto:</strong> {{ item.part_name || warrantyPartDescription(item.order_part) }}
                    <div><strong>Proveedor de la operación:</strong> {{ item.supplier_name || 'No disponible' }}</div>
                    <div class="text-muted">Uso registrado #{{ item.order_part }}</div>
                  </div>
                  <div class="row g-2 small mt-2">
                    <div class="col-sm-6"><strong>Inicio:</strong> {{ formatWarrantyDate(item.starts_on) }}</div>
                    <div class="col-sm-6"><strong>Término:</strong> {{ formatWarrantyDate(item.ends_on) }}</div>
                  </div>
                  <div class="small mt-2" style="white-space: pre-wrap;"><strong>Condiciones:</strong> {{ item.conditions || 'Sin condiciones registradas' }}</div>
                  <div class="small text-muted mt-2">Actualizada: {{ formatDate(item.updated_at) }}</div>
                  <div class="d-flex flex-wrap gap-2 mt-3">
                    <button
                      v-if="canManageWarranties"
                      type="button"
                      class="btn btn-sm btn-outline-primary"
                      :disabled="warrantySaving || warrantyDeletingId !== null"
                      @click="startEditWarranty(item)"
                    >
                      Modificar
                    </button>
                    <button
                      v-if="canManageWarranties"
                      type="button"
                      class="btn btn-sm btn-outline-success"
                      :disabled="warrantySaving || warrantyDeletingId !== null"
                      @click="selectWarrantyForRequest(item)"
                    >
                      Ingresar solicitud
                    </button>
                    <button
                      v-if="canManageWarranties"
                      type="button"
                      class="btn btn-sm btn-outline-danger"
                      :disabled="warrantySaving || warrantyDeletingId !== null || warrantyHasRequests(item.id)"
                      :title="warrantyHasRequests(item.id) ? 'No se puede eliminar una garantía con solicitudes asociadas.' : 'Eliminar garantía'"
                      @click="deleteWarranty(item)"
                    >
                      <span
                        v-if="warrantyDeletingId === item.id"
                        class="spinner-border spinner-border-sm me-1"
                        aria-hidden="true"
                      ></span>
                      {{ warrantyDeletingId === item.id ? 'Eliminando...' : 'Eliminar' }}
                    </button>
                    <button
                      type="button"
                      class="btn btn-sm btn-outline-secondary"
                      :disabled="!!warrantyHistoryLoading[item.id] || warrantyDeletingId !== null"
                      @click="toggleWarrantyHistory(item.id)"
                    >
                      {{ expandedWarrantyHistoryId === item.id ? 'Ocultar historial' : 'Ver historial' }}
                    </button>
                  </div>
                  <div v-if="warrantyHasRequests(item.id)" class="small text-muted mt-2">
                    Esta garantía tiene solicitudes asociadas y ya no puede eliminarse, para conservar su trazabilidad.
                  </div>
                  <div v-if="expandedWarrantyHistoryId === item.id" class="mt-3 border-top pt-3">
                    <h6>Historial de revisiones</h6>
                    <div v-if="warrantyHistoryLoading[item.id]" class="text-muted small">Cargando historial...</div>
                    <div v-else-if="warrantyHistoryErrors[item.id]" class="alert alert-warning small" role="alert">
                      {{ warrantyHistoryErrors[item.id] }}
                      <button type="button" class="btn btn-sm btn-outline-secondary ms-2" @click="loadWarrantyHistory(item.id)">Reintentar</button>
                    </div>
                    <div v-else-if="!warrantyHistoryById[item.id]?.length" class="text-muted small">No hay revisiones disponibles.</div>
                    <div v-else class="d-flex flex-column gap-2">
                      <div v-for="revision in [...warrantyHistoryById[item.id]].reverse()" :key="revision.id" class="border rounded p-2 small">
                        <div class="fw-semibold">Revisión #{{ revision.revision }} · {{ revision.action === 'CREATED' ? 'Creación' : 'Actualización' }}</div>
                        <div class="text-muted">{{ formatDate(revision.changed_at) }} · {{ revision.changed_by_username || 'Usuario no disponible' }}</div>
                        <div v-if="revision.order_part" class="mt-1"><strong>Repuesto:</strong> {{ warrantyPartDescription(revision.order_part) }}</div>
                        <div class="mt-1"><strong>Aplica:</strong> {{ revision.is_applicable ? 'Sí' : 'No' }}</div>
                        <div v-if="revision.is_applicable" class="mt-1">
                          <strong>Vigencia:</strong> {{ formatWarrantyDate(revision.starts_on) }} al {{ formatWarrantyDate(revision.ends_on) }}
                        </div>
                        <div class="mt-1" style="white-space: pre-wrap;"><strong>Condiciones:</strong> {{ revision.conditions || 'Sin condiciones registradas' }}</div>
                        <div v-if="revision.change_note" class="mt-1"><strong>Motivo del cambio:</strong> {{ revision.change_note }}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-5">
            <div class="mc-card p-4">
              <h5>{{ editingWarrantyId !== null ? 'Modificar garantía' : 'Registrar garantía' }}</h5>
              <p class="small text-muted">
                La garantía del servicio se registra una vez por orden. Cada uso de repuesto puede tener
                su propia garantía, vinculada al proveedor histórico de HU-13.
              </p>
              <div v-if="warrantySuccess" class="alert alert-success" role="status">{{ warrantySuccess }}</div>
              <div v-if="warrantyFormError" class="alert alert-danger" role="alert">{{ warrantyFormError }}</div>
              <div v-if="!canManageWarranties" class="alert alert-secondary mb-0">Tu rol permite consultar garantías, pero no modificarlas.</div>
              <form v-else @submit.prevent="saveWarranty">
                <label for="warranty-type" class="form-label">Tipo de garantía</label>
                <select
                  id="warranty-type"
                  v-model="warrantyForm.warranty_type"
                  class="form-select mb-3"
                  :disabled="editingWarrantyId !== null || warrantySaving || warrantyLoading"
                  required
                  @change="warrantyForm.order_part = ''"
                >
                  <option value="SERVICE" :disabled="serviceWarrantyExists && editingWarrantyId === null">Garantía del servicio</option>
                  <option value="PART">Garantía de repuesto</option>
                </select>
                <div v-if="serviceWarrantyExists && editingWarrantyId === null" class="form-text mb-3">
                  La garantía del servicio ya está registrada. Para cambiarla, utiliza «Modificar» en su tarjeta.
                </div>

                <template v-if="warrantyForm.warranty_type === 'PART'">
                  <label for="warranty-order-part" class="form-label">Repuesto utilizado en esta orden</label>
                  <div v-if="editingWarrantyId !== null" class="alert alert-light border small mb-3">
                    {{ selectedWarrantyPart ? `${selectedWarrantyPart.part_name} · ${selectedWarrantyPart.supplier_name}` : `Uso registrado #${warrantyForm.order_part}` }}
                    <div class="text-muted">El repuesto asociado no se cambia desde este formulario.</div>
                  </div>
                  <template v-else>
                    <select
                      id="warranty-order-part"
                      v-model="warrantyForm.order_part"
                      class="form-select mb-2"
                      :disabled="warrantySaving || orderPartsLoading || !!orderPartsError"
                      required
                    >
                      <option value="" disabled>Seleccionar repuesto...</option>
                      <option v-for="usage in availableWarrantyParts" :key="usage.id" :value="usage.id">
                        {{ usage.part_name }} · {{ usage.supplier_name }} · Uso #{{ usage.id }}
                      </option>
                    </select>
                    <div v-if="orderPartsLoading" class="form-text mb-2">Cargando repuestos utilizados...</div>
                    <div v-if="orderPartsError" class="alert alert-warning small mb-2" role="alert">
                      {{ orderPartsError }}
                      <button type="button" class="btn btn-sm btn-outline-secondary ms-2" @click="loadOrderParts">Reintentar</button>
                    </div>
                    <div v-if="!orderPartsLoading && !orderPartsError && !availableWarrantyParts.length" class="alert alert-info small mb-3">
                      No hay usos de repuestos sin garantía. Regístralos desde «Repuestos y costos».
                    </div>
                  </template>
                </template>

                <div class="form-check mb-3">
                  <input
                    id="warranty-applicable"
                    v-model="warrantyForm.is_applicable"
                    type="checkbox"
                    class="form-check-input"
                    :disabled="warrantySaving"
                  >
                  <label for="warranty-applicable" class="form-check-label">La garantía aplica</label>
                </div>
                <div v-if="warrantyForm.is_applicable" class="row g-2 mb-3">
                  <div class="col-sm-6">
                    <label for="warranty-start" class="form-label">Fecha de inicio</label>
                    <input id="warranty-start" v-model="warrantyForm.starts_on" type="date" class="form-control" :disabled="warrantySaving" required>
                  </div>
                  <div class="col-sm-6">
                    <label for="warranty-end" class="form-label">Fecha de término</label>
                    <input id="warranty-end" v-model="warrantyForm.ends_on" type="date" :min="warrantyForm.starts_on || undefined" class="form-control" :disabled="warrantySaving" required>
                  </div>
                </div>
                <div v-else class="alert alert-light border small mb-3">
                  No aplica: se guardará sin fechas y se mostrará con el estado «No aplica».
                </div>
                <label for="warranty-conditions" class="form-label">Condiciones {{ warrantyForm.is_applicable ? '' : '(opcional)' }}</label>
                <textarea
                  id="warranty-conditions"
                  v-model="warrantyForm.conditions"
                  class="form-control mb-3"
                  rows="3"
                  :disabled="warrantySaving"
                  :required="warrantyForm.is_applicable"
                  placeholder="Ej.: Cubre fallas relacionadas con la reparación realizada."
                ></textarea>
                <template v-if="editingWarrantyId !== null">
                  <label for="warranty-change-note" class="form-label">Motivo de la modificación</label>
                  <textarea
                    id="warranty-change-note"
                    v-model="warrantyForm.change_note"
                    class="form-control mb-3"
                    rows="2"
                    :disabled="warrantySaving"
                    placeholder="Ej.: Corrección de fecha o condiciones."
                    required
                  ></textarea>
                </template>
                <div class="d-flex flex-wrap gap-2">
                  <button type="submit" class="btn btn-primary" :disabled="warrantySaving || warrantyLoading || warrantyDeletingId !== null || (warrantyForm.warranty_type === 'PART' && !editingWarrantyId && (orderPartsLoading || !!orderPartsError || !availableWarrantyParts.length))">
                    <span v-if="warrantySaving" class="spinner-border spinner-border-sm me-2"></span>
                    {{ warrantySaving ? 'Guardando...' : editingWarrantyId !== null ? 'Guardar cambios y revisión' : 'Registrar garantía' }}
                  </button>
                  <button v-if="editingWarrantyId !== null" type="button" class="btn btn-outline-secondary" :disabled="warrantySaving || warrantyDeletingId !== null" @click="resetWarrantyForm">
                    Cancelar edición
                  </button>
                </div>
              </form>
            </div>
          </div>

          <!-- HU-22: historial general de solicitudes/reclamos de garantía. -->
          <div class="col-lg-7">
            <div class="mc-card p-4">
              <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <h5 class="mb-0">Solicitudes de garantía</h5>
                <button
                  type="button"
                  class="btn btn-sm btn-outline-secondary"
                  :disabled="warrantyRequestsLoading || warrantyRequestSaving"
                  @click="loadWarrantyRequests"
                >
                  {{ warrantyRequestsLoading ? 'Actualizando...' : 'Actualizar' }}
                </button>
              </div>

              <p class="small text-muted">
                Historial general de reclamos de esta orden. Cada solicitud conserva
                la garantía asociada, el cliente registrado al momento del ingreso,
                el responsable y su propio historial.
              </p>

              <div v-if="warrantyRequestsError" class="alert alert-danger" role="alert">
                {{ warrantyRequestsError }}
              </div>

              <div v-if="warrantyRequestsLoading" class="text-muted">
                Cargando solicitudes de garantía...
              </div>

              <div
                v-else-if="!warrantyRequestsError && !warrantyRequests.length"
                class="alert alert-info mb-0"
                role="status"
              >
                Esta orden todavía no tiene solicitudes de garantía.
              </div>

              <div v-else class="d-flex flex-column gap-3">
                <div
                  v-for="requestItem in warrantyRequests"
                  :key="requestItem.id"
                  class="border rounded p-3"
                >
                  <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <strong>
                      Solicitud #{{ requestItem.id }} ·
                      {{ requestItem.warranty_type_display || 'Garantía' }}
                      #{{ requestItem.warranty }}
                    </strong>
                    <span
                      class="badge"
                      :class="warrantyRequestStatusBadgeClass(requestItem.status)"
                    >
                      {{ requestItem.status_display || requestItem.status }}
                    </span>
                  </div>

                  <div
                    v-if="requestItem.coverage_warning"
                    class="alert alert-warning small py-2 mt-3 mb-2"
                    role="alert"
                  >
                    {{ requestItem.coverage_warning }}
                  </div>

                  <div class="row g-2 small mt-2">
                    <div class="col-sm-6">
                      <strong>Fecha de solicitud:</strong>
                      {{ formatWarrantyDate(requestItem.requested_on) }}
                    </div>
                    <div class="col-sm-6">
                      <strong>Responsable de ingreso:</strong>
                      {{ requestItem.created_by_username || 'Usuario no disponible' }}
                    </div>
                    <div class="col-sm-6">
                      <strong>Cliente:</strong>
                      {{ requestItem.client_name || 'No disponible' }}
                    </div>
                    <div class="col-sm-6">
                      <strong>Identificación:</strong>
                      {{
                        requestItem.client_identification ||
                        requestItem.client_rut ||
                        'No disponible'
                      }}
                    </div>
                  </div>

                  <div class="small mt-2" style="white-space: pre-wrap;">
                    <strong>Problema reportado:</strong>
                    {{ requestItem.problem_description }}
                  </div>

                  <div
                    v-if="requestItem.concurrent_open_reason"
                    class="small mt-2"
                    style="white-space: pre-wrap;"
                  >
                    <strong>Motivo de nueva solicitud con otra pendiente:</strong>
                    {{ requestItem.concurrent_open_reason }}
                  </div>

                  <div class="small text-muted mt-2">
                    Evidencia adjunta: {{ requestItem.evidence ? 'Sí' : 'No' }} ·
                    Registrada: {{ formatDate(requestItem.created_at) }}
                  </div>
                  <div v-if="requestItem.evidence_download_url" class="mt-2">
                    <div
                      v-if="warrantyRequestImageErrors[requestItem.id]"
                      class="alert alert-warning small mb-2"
                      role="alert"
                    >
                      {{ warrantyRequestImageErrors[requestItem.id] }}
                    </div>
                    <button
                      type="button"
                      class="btn btn-sm btn-outline-primary"
                      :disabled="warrantyRequestImageLoading[requestItem.id]"
                      @click="toggleWarrantyRequestImage(requestItem)"
                    >
                      {{ warrantyRequestImageLoading[requestItem.id] ? 'Cargando fotografía...' : warrantyRequestImageUrls[requestItem.id] ? 'Ocultar fotografía' : 'Ver fotografía' }}
                    </button>
                    <a
                      v-if="warrantyRequestImageUrls[requestItem.id]"
                      :href="warrantyRequestImageUrls[requestItem.id]"
                      :download="warrantyRequestImageFilenames[requestItem.id]"
                      class="btn btn-sm btn-outline-secondary ms-2"
                    >
                      Descargar
                    </a>
                    <img
                      v-if="warrantyRequestImageUrls[requestItem.id]"
                      :src="warrantyRequestImageUrls[requestItem.id]"
                      :alt="`Evidencia de solicitud de garantía #${requestItem.id}`"
                      class="img-fluid rounded border d-block mt-2"
                      style="max-height: 360px; object-fit: contain;"
                    >
                  </div>

                  <!-- HU-23: propuestas, resolución y acciones según el rol. -->
                  <div
                    v-if="requestItem.proposals?.length"
                    class="mt-3 border rounded bg-light p-3"
                  >
                    <h6 class="mb-2">Propuestas técnicas</h6>

                    <div
                      v-for="proposal in [...requestItem.proposals].reverse()"
                      :key="proposal.id"
                      class="small border-top pt-2 mt-2"
                    >
                      <div class="fw-semibold">
                        Propuesta #{{ proposal.revision }} ·
                        {{ warrantyActionTypeLabel(proposal.action_type) }}
                      </div>
                      <div class="text-muted">
                        {{ proposal.proposed_by_username || 'Técnico no disponible' }} ·
                        {{ formatDate(proposal.proposed_at) }}
                      </div>
                      <div class="mt-1" style="white-space: pre-wrap;">
                        <strong>Fundamento técnico:</strong>
                        {{ proposal.technical_rationale }}
                      </div>
                      <div class="mt-1" style="white-space: pre-wrap;">
                        <strong>Acción propuesta:</strong>
                        {{ proposal.action_description }}
                      </div>
                    </div>
                  </div>

                  <div
                    v-if="requestItem.resolution"
                    class="alert mt-3 mb-0"
                    :class="warrantyResolutionAlertClass(requestItem.resolution.decision)"
                    role="status"
                  >
                    <div class="fw-semibold">
                      Resolución final:
                      {{
                        requestItem.resolution.decision_display ||
                        requestItem.resolution.decision
                      }}
                    </div>
                    <div class="small mt-1">
                      {{ requestItem.resolution.resolved_by_username || 'Administrador no disponible' }} ·
                      {{ formatDate(requestItem.resolution.resolved_at) }}
                    </div>
                    <div class="small mt-2" style="white-space: pre-wrap;">
                      <strong>Fundamento:</strong>
                      {{ requestItem.resolution.rationale }}
                    </div>
                    <template v-if="requestItem.resolution.decision === 'ACCEPTED'">
                      <div class="small mt-2">
                        <strong>Acción:</strong>
                        {{ warrantyActionTypeLabel(requestItem.resolution.action_type) }}
                      </div>
                      <div class="small mt-1" style="white-space: pre-wrap;">
                        <strong>Detalle:</strong>
                        {{ requestItem.resolution.action_description }}
                      </div>
                    </template>
                  </div>

                  <div
                    v-if="warrantyRequestActionSuccess[requestItem.id]"
                    class="alert alert-success small mt-3 mb-0"
                    role="status"
                  >
                    {{ warrantyRequestActionSuccess[requestItem.id] }}
                  </div>

                  <div
                    v-if="warrantyRequestActionErrors[requestItem.id]"
                    class="alert alert-danger small mt-3 mb-0"
                    role="alert"
                  >
                    {{ warrantyRequestActionErrors[requestItem.id] }}
                  </div>

                  <div
                    v-if="
                      canProposeWarrantyResolution &&
                      ['PENDING', 'CHANGES_REQUESTED'].includes(requestItem.status)
                    "
                    class="border rounded p-3 mt-3"
                  >
                    <h6>
                      {{
                        requestItem.status === 'CHANGES_REQUESTED'
                          ? 'Corregir y reenviar propuesta'
                          : 'Enviar propuesta técnica'
                      }}
                    </h6>
                    <p
                      v-if="requestItem.status === 'CHANGES_REQUESTED'"
                      class="small text-muted"
                    >
                      La solicitud fue devuelta para correcciones. Se conserva la
                      propuesta anterior y este envío quedará como una nueva revisión.
                    </p>

                    <form @submit.prevent="submitWarrantyProposal(requestItem)">
                      <label
                        :for="`warranty-proposal-rationale-${requestItem.id}`"
                        class="form-label"
                      >
                        Fundamento técnico
                      </label>
                      <textarea
                        :id="`warranty-proposal-rationale-${requestItem.id}`"
                        v-model="warrantyProposalForms[requestItem.id].technical_rationale"
                        class="form-control mb-3"
                        rows="3"
                        :disabled="isWarrantyRequestActionSaving(requestItem.id)"
                        placeholder="Explica técnicamente la propuesta de resolución."
                        required
                      ></textarea>

                      <label
                        :for="`warranty-proposal-action-${requestItem.id}`"
                        class="form-label"
                      >
                        Acción propuesta
                      </label>
                      <select
                        :id="`warranty-proposal-action-${requestItem.id}`"
                        v-model="warrantyProposalForms[requestItem.id].action_type"
                        class="form-select mb-3"
                        :disabled="isWarrantyRequestActionSaving(requestItem.id)"
                        required
                      >
                        <option value="" disabled>Seleccionar acción...</option>
                        <option
                          v-for="option in warrantyActionOptions"
                          :key="option.value"
                          :value="option.value"
                        >
                          {{ option.label }}
                        </option>
                      </select>

                      <label
                        :for="`warranty-proposal-description-${requestItem.id}`"
                        class="form-label"
                      >
                        Descripción de la acción
                      </label>
                      <textarea
                        :id="`warranty-proposal-description-${requestItem.id}`"
                        v-model="warrantyProposalForms[requestItem.id].action_description"
                        class="form-control mb-3"
                        rows="3"
                        :disabled="isWarrantyRequestActionSaving(requestItem.id)"
                        placeholder="Describe lo que se propone realizar."
                        required
                      ></textarea>

                      <button
                        type="submit"
                        class="btn btn-primary btn-sm"
                        :disabled="isWarrantyRequestActionSaving(requestItem.id)"
                      >
                        <span
                          v-if="isWarrantyRequestActionSaving(requestItem.id)"
                          class="spinner-border spinner-border-sm me-2"
                          aria-hidden="true"
                        ></span>
                        {{
                          isWarrantyRequestActionSaving(requestItem.id)
                            ? 'Enviando...'
                            : requestItem.status === 'CHANGES_REQUESTED'
                              ? 'Reenviar propuesta'
                              : 'Enviar para aprobación'
                        }}
                      </button>
                    </form>
                  </div>

                  <div
                    v-else-if="
                      canProposeWarrantyResolution &&
                      requestItem.status === 'AWAITING_APPROVAL'
                    "
                    class="alert alert-info small mt-3 mb-0"
                    role="status"
                  >
                    La propuesta técnica está pendiente de revisión por un administrador.
                  </div>

                  <div
                    v-if="
                      canAdminResolveWarrantyRequest &&
                      requestItem.status !== 'RESOLVED'
                    "
                    class="border rounded p-3 mt-3"
                  >
                    <h6>Resolución administrativa</h6>

                    <div
                      v-if="
                        requestItem.status === 'AWAITING_APPROVAL' &&
                        requestItem.latest_proposal
                      "
                      class="alert alert-light border small"
                    >
                      <strong>
                        Propuesta técnica #{{ requestItem.latest_proposal.revision }}
                      </strong>
                      <div class="mt-1">
                        {{ warrantyActionTypeLabel(requestItem.latest_proposal.action_type) }}
                      </div>
                      <div class="mt-1" style="white-space: pre-wrap;">
                        {{ requestItem.latest_proposal.action_description }}
                      </div>
                    </div>

                    <form @submit.prevent="resolveWarrantyRequest(requestItem)">
                      <label
                        :for="`warranty-resolution-decision-${requestItem.id}`"
                        class="form-label"
                      >
                        Decisión
                      </label>
                      <select
                        :id="`warranty-resolution-decision-${requestItem.id}`"
                        v-model="warrantyResolutionForms[requestItem.id].decision"
                        class="form-select mb-3"
                        :disabled="isWarrantyRequestActionSaving(requestItem.id)"
                        required
                      >
                        <option value="" disabled>Seleccionar decisión...</option>
                        <option value="ACCEPTED">Aceptar solicitud</option>
                        <option value="REJECTED">Rechazar solicitud</option>
                      </select>

                      <label
                        :for="`warranty-resolution-rationale-${requestItem.id}`"
                        class="form-label"
                      >
                        Fundamento de la decisión
                      </label>
                      <textarea
                        :id="`warranty-resolution-rationale-${requestItem.id}`"
                        v-model="warrantyResolutionForms[requestItem.id].rationale"
                        class="form-control mb-3"
                        rows="3"
                        :disabled="isWarrantyRequestActionSaving(requestItem.id)"
                        placeholder="Justifica la decisión administrativa."
                        required
                      ></textarea>

                      <template
                        v-if="
                          warrantyResolutionForms[requestItem.id].decision === 'ACCEPTED'
                        "
                      >
                        <label
                          :for="`warranty-resolution-action-${requestItem.id}`"
                          class="form-label"
                        >
                          Acción realizada o autorizada
                        </label>
                        <select
                          :id="`warranty-resolution-action-${requestItem.id}`"
                          v-model="warrantyResolutionForms[requestItem.id].action_type"
                          class="form-select mb-3"
                          :disabled="isWarrantyRequestActionSaving(requestItem.id)"
                          required
                        >
                          <option value="" disabled>Seleccionar acción...</option>
                          <option
                            v-for="option in warrantyActionOptions"
                            :key="option.value"
                            :value="option.value"
                          >
                            {{ option.label }}
                          </option>
                        </select>

                        <label
                          :for="`warranty-resolution-description-${requestItem.id}`"
                          class="form-label"
                        >
                          Descripción de la acción
                        </label>
                        <textarea
                          :id="`warranty-resolution-description-${requestItem.id}`"
                          v-model="warrantyResolutionForms[requestItem.id].action_description"
                          class="form-control mb-3"
                          rows="3"
                          :disabled="isWarrantyRequestActionSaving(requestItem.id)"
                          placeholder="Describe la acción realizada o autorizada."
                          required
                        ></textarea>
                      </template>

                      <button
                        type="submit"
                        class="btn btn-primary btn-sm"
                        :disabled="isWarrantyRequestActionSaving(requestItem.id)"
                      >
                        <span
                          v-if="isWarrantyRequestActionSaving(requestItem.id)"
                          class="spinner-border spinner-border-sm me-2"
                          aria-hidden="true"
                        ></span>
                        {{
                          isWarrantyRequestActionSaving(requestItem.id)
                            ? 'Guardando...'
                            : 'Registrar resolución final'
                        }}
                      </button>
                    </form>

                    <form
                      v-if="requestItem.status === 'AWAITING_APPROVAL'"
                      class="border-top mt-3 pt-3"
                      @submit.prevent="returnWarrantyRequestToTech(requestItem)"
                    >
                      <label
                        :for="`warranty-return-reason-${requestItem.id}`"
                        class="form-label"
                      >
                        Devolver al técnico
                      </label>
                      <textarea
                        :id="`warranty-return-reason-${requestItem.id}`"
                        v-model="warrantyReturnForms[requestItem.id].reason"
                        class="form-control mb-2"
                        rows="2"
                        :disabled="isWarrantyRequestActionSaving(requestItem.id)"
                        placeholder="Indica qué debe corregir o complementar."
                        required
                      ></textarea>
                      <button
                        type="submit"
                        class="btn btn-outline-warning btn-sm"
                        :disabled="isWarrantyRequestActionSaving(requestItem.id)"
                      >
                        Solicitar correcciones
                      </button>
                    </form>
                  </div>

                  <div
                    v-if="
                      canAdminResolveWarrantyRequest &&
                      requestItem.status === 'RESOLVED'
                    "
                    class="border rounded p-3 mt-3"
                  >
                    <h6>Observación administrativa</h6>
                    <p class="small text-muted">
                      Agrega una aclaración posterior sin modificar ni reabrir la
                      resolución final.
                    </p>
                    <form @submit.prevent="addWarrantyRequestAdminNote(requestItem)">
                      <textarea
                        :id="`warranty-admin-note-${requestItem.id}`"
                        v-model="warrantyAdminNoteForms[requestItem.id].observation"
                        class="form-control mb-2"
                        rows="2"
                        :disabled="isWarrantyRequestActionSaving(requestItem.id)"
                        placeholder="Escribe la observación que quedará en el historial."
                        required
                      ></textarea>
                      <button
                        type="submit"
                        class="btn btn-outline-primary btn-sm"
                        :disabled="isWarrantyRequestActionSaving(requestItem.id)"
                      >
                        <span
                          v-if="isWarrantyRequestActionSaving(requestItem.id)"
                          class="spinner-border spinner-border-sm me-2"
                          aria-hidden="true"
                        ></span>
                        Agregar observación
                      </button>
                    </form>
                  </div>

                  <div class="mt-3">
                    <button
                      type="button"
                      class="btn btn-sm btn-outline-secondary"
                      :disabled="!!warrantyRequestHistoryLoading[requestItem.id]"
                      @click="toggleWarrantyRequestHistory(requestItem.id)"
                    >
                      {{
                        expandedWarrantyRequestHistoryId === requestItem.id
                          ? 'Ocultar historial'
                          : 'Ver historial'
                      }}
                    </button>
                  </div>

                  <div
                    v-if="expandedWarrantyRequestHistoryId === requestItem.id"
                    class="mt-3 border-top pt-3"
                  >
                    <h6>Historial de la solicitud</h6>

                    <div
                      v-if="warrantyRequestHistoryLoading[requestItem.id]"
                      class="text-muted small"
                    >
                      Cargando historial...
                    </div>

                    <div
                      v-else-if="warrantyRequestHistoryErrors[requestItem.id]"
                      class="alert alert-warning small"
                      role="alert"
                    >
                      {{ warrantyRequestHistoryErrors[requestItem.id] }}
                      <button
                        type="button"
                        class="btn btn-sm btn-outline-secondary ms-2"
                        @click="loadWarrantyRequestHistory(requestItem.id)"
                      >
                        Reintentar
                      </button>
                    </div>

                    <div
                      v-else-if="!warrantyRequestHistoryById[requestItem.id]?.length"
                      class="text-muted small"
                    >
                      No hay eventos disponibles.
                    </div>

                    <div v-else class="d-flex flex-column gap-2">
                      <div
                        v-for="event in [...warrantyRequestHistoryById[requestItem.id]].reverse()"
                        :key="event.id"
                        class="border rounded p-2 small"
                      >
                        <div class="fw-semibold">
                          Revisión #{{ event.revision }} ·
                          {{ event.action_display || event.action }}
                        </div>
                        <div class="text-muted">
                          {{ formatDate(event.changed_at) }} ·
                          {{ event.changed_by_username || 'Usuario no disponible' }}
                          <span v-if="event.changed_by_role">
                            · {{ event.changed_by_role }}
                          </span>
                        </div>
                        <div v-if="event.from_status" class="mt-1">
                          <strong>Cambio de estado:</strong>
                          {{ event.from_status_display || event.from_status }}
                          →
                          {{ event.to_status_display || event.to_status }}
                        </div>
                        <div v-else class="mt-1">
                          <strong>Estado:</strong>
                          {{ event.to_status_display || event.to_status }}
                        </div>
                        <div
                          v-if="event.decision"
                          class="mt-1"
                        >
                          <strong>Decisión:</strong>
                          {{ event.decision_display || event.decision }}
                        </div>
                        <div
                          v-if="event.observation"
                          class="mt-1"
                          style="white-space: pre-wrap;"
                        >
                          <strong>Observación:</strong> {{ event.observation }}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- HU-22: ingreso de una solicitud de garantía. -->
          <div class="col-lg-5">
            <div id="warranty-request-form" class="mc-card p-4">
              <h5>Ingresar solicitud de garantía</h5>
              <p class="small text-muted">
                El nombre y la identificación del cliente se obtienen
                automáticamente desde la orden. No es necesario volver a
                ingresarlos.
              </p>

              <div
                v-if="warrantyRequestSuccess"
                class="alert alert-success"
                role="status"
              >
                {{ warrantyRequestSuccess }}
              </div>

              <div
                v-if="warrantyRequestFormError"
                class="alert alert-danger"
                role="alert"
              >
                {{ warrantyRequestFormError }}
              </div>

              <div v-if="!canManageWarranties" class="alert alert-secondary mb-0">
                Tu rol permite consultar solicitudes, pero no ingresarlas.
              </div>

              <form v-else @submit.prevent="saveWarrantyRequest">
                <label for="warranty-request-warranty" class="form-label">
                  Garantía asociada
                </label>
                <select
                  id="warranty-request-warranty"
                  v-model="warrantyRequestForm.warranty"
                  class="form-select mb-2"
                  :disabled="warrantyRequestSaving || warrantyLoading"
                  required
                  @change="warrantyRequestForm.concurrent_open_reason = ''"
                >
                  <option value="" disabled>Seleccionar garantía...</option>
                  <option
                    v-for="item in warranties"
                    :key="item.id"
                    :value="item.id"
                  >
                    {{
                      item.warranty_type_display ||
                      (item.warranty_type === 'SERVICE'
                        ? 'Garantía del servicio'
                        : 'Garantía de repuesto')
                    }}
                    #{{ item.id }} ·
                    {{ warrantyStatusLabels[item.status] || item.status }}
                  </option>
                </select>

                <div
                  v-if="!warrantyLoading && !warranties.length"
                  class="alert alert-info small"
                >
                  Primero debes registrar una garantía en esta orden.
                </div>

                <div
                  v-if="warrantyRequestBlockedReason"
                  class="alert alert-danger small"
                  role="alert"
                >
                  {{ warrantyRequestBlockedReason }}
                </div>

                <div
                  v-else-if="selectedWarrantyForRequest?.status === 'EXPIRED'"
                  class="alert alert-warning small"
                  role="alert"
                >
                  La cobertura está vencida. La solicitud se puede registrar,
                  pero quedará identificada con esta advertencia.
                </div>

                <div
                  v-if="openWarrantyRequestExists"
                  class="alert alert-warning small"
                  role="alert"
                >
                  Esta garantía ya tiene una solicitud abierta. Puedes continuar
                  trabajando con la solicitud existente en el listado o registrar
                  otra. Si creas otra, debes justificar el motivo.
                </div>

                <label for="warranty-request-date" class="form-label">
                  Fecha de solicitud
                </label>
                <input
                  id="warranty-request-date"
                  v-model="warrantyRequestForm.requested_on"
                  type="date"
                  class="form-control mb-3"
                  :disabled="warrantyRequestSaving"
                  required
                >

                <label for="warranty-request-problem" class="form-label">
                  Problema reportado
                </label>
                <textarea
                  id="warranty-request-problem"
                  v-model="warrantyRequestForm.problem_description"
                  class="form-control mb-3"
                  rows="4"
                  :disabled="warrantyRequestSaving"
                  placeholder="Describe el problema informado por el cliente."
                  required
                ></textarea>

                <template v-if="openWarrantyRequestExists">
                  <label for="warranty-request-concurrent-reason" class="form-label">
                    Motivo para abrir otra solicitud
                  </label>
                  <textarea
                    id="warranty-request-concurrent-reason"
                    v-model="warrantyRequestForm.concurrent_open_reason"
                    class="form-control mb-3"
                    rows="3"
                    :disabled="warrantyRequestSaving"
                    placeholder="Explica por qué se requiere un reclamo separado."
                    required
                  ></textarea>
                </template>

                <label for="warranty-request-evidence" class="form-label">
                  Evidencia fotográfica
                  <span class="text-muted">(opcional)</span>
                </label>
                <input
                  id="warranty-request-evidence"
                  ref="warrantyRequestFileInput"
                  type="file"
                  class="form-control mb-2"
                  accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                  :disabled="warrantyRequestSaving"
                  @change="selectWarrantyRequestEvidence"
                >
                <div class="form-text mb-3">
                  Formatos permitidos: JPG, JPEG, PNG o WEBP. Máximo 20 MB.
                </div>

                <button
                  type="submit"
                  class="btn btn-primary"
                  :disabled="
                    warrantyRequestSaving ||
                    warrantyRequestsLoading ||
                    warrantyLoading ||
                    !selectedWarrantyForRequest ||
                    !!warrantyRequestBlockedReason
                  "
                >
                  <span
                    v-if="warrantyRequestSaving"
                    class="spinner-border spinner-border-sm me-2"
                    aria-hidden="true"
                  ></span>
                  {{
                    warrantyRequestSaving
                      ? 'Registrando...'
                      : 'Registrar solicitud'
                  }}
                </button>
              </form>
            </div>
          </div>
        </template>
      </section>

      <!-- HU-16: índice de viabilidad explicable y evaluación profesional. -->
      <section v-if="tab === 'viabilidad'" class="row g-3">
        <div v-if="!canViewViability" class="col-12">
          <div class="alert alert-info" role="status">
            Tu perfil no tiene permiso para consultar el índice de viabilidad.
          </div>
        </div>

        <template v-else>
          <div class="col-lg-7">
            <div class="mc-card p-4 h-100">
              <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <div>
                  <h5 class="mb-1">Índice de viabilidad</h5>
                  <div class="small text-muted">
                    Reglas {{ viability?.rule_version || 'HU16-v1' }} · resultado calculado en Django
                  </div>
                </div>

                <button
                  type="button"
                  class="btn btn-sm btn-outline-secondary"
                  :disabled="viabilityLoading || viabilitySaving"
                  @click="loadViability"
                >
                  {{ viabilityLoading ? 'Actualizando...' : 'Recalcular' }}
                </button>
              </div>

              <div
                v-if="viabilityError"
                class="alert alert-danger"
                role="alert"
              >
                {{ viabilityError }}
              </div>

              <div
                v-if="viabilityLoading && !viability"
                class="text-muted"
              >
                Calculando índice de viabilidad...
              </div>

              <template v-else-if="viability">
                <div class="row g-3 align-items-stretch mb-4">
                  <div class="col-md-4">
                    <div class="border rounded p-3 h-100 text-center">
                      <template v-if="viability.is_calculable">
                        <div class="display-6 fw-bold">
                          {{ viability.score }}/{{ viability.max_score }}
                        </div>

                        <span
                          class="badge mt-2"
                          :class="viabilityLevelClass(viability.level)"
                        >
                          Viabilidad {{ viability.level_display }}
                        </span>
                      </template>

                      <template v-else>
                        <i class="bi bi-exclamation-circle fs-2 text-warning"></i>
                        <div class="fw-semibold mt-2">
                          Información insuficiente
                        </div>
                        <div class="small text-muted mt-1">
                          Completa los factores pendientes para obtener el puntaje.
                        </div>
                      </template>
                    </div>
                  </div>

                  <div class="col-md-8">
                    <div class="alert alert-light border h-100 mb-0">
                      <strong>Importante</strong>

                      <div class="small mt-1">
                        {{ viability.advisory }}
                      </div>

                      <div
                        v-if="viability.missing_factors?.length"
                        class="small mt-3"
                      >
                        <strong>Factores pendientes:</strong>

                        <div class="d-flex flex-column gap-2 mt-2">
                          <button
                            v-for="key in viability.missing_factors"
                            :key="key"
                            type="button"
                            class="btn btn-sm btn-outline-primary d-flex align-items-center justify-content-between gap-3 text-start"
                            @click="goToViabilityMissingFactor(key)"
                          >
                            <span>{{ viabilityMissingLabel(key) }}</span>

                            <span class="text-nowrap">
                              {{ viabilityMissingActionLabel(key) }}
                              <i class="bi bi-arrow-right ms-1" aria-hidden="true"></i>
                            </span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <h6 class="mb-3">
                  Factores que explican el resultado
                </h6>

                <template v-if="viability.factors?.length">
                  <div
                    v-for="factor in viability.factors"
                    :key="factor.key"
                    class="border rounded p-3 mb-3"
                  >
                    <div class="d-flex justify-content-between gap-3">
                      <strong>{{ factor.label }}</strong>

                      <span
                        v-if="factor.score !== null && factor.score !== undefined"
                        class="fw-semibold"
                      >
                        {{ factor.score }}/{{ factor.max_score }}
                      </span>

                      <span v-else class="badge bg-secondary">
                        Pendiente
                      </span>
                    </div>

                    <div class="bar-track mt-2">
                      <div
                        class="bar-fill"
                        :style="{ width: viabilityFactorWidth(factor) }"
                      ></div>
                    </div>

                    <div class="small text-muted mt-2">
                      {{ factor.explanation }}
                    </div>
                  </div>
                </template>

                <div v-else class="alert alert-info mb-0">
                  Registra la dificultad técnica y el riesgo de garantía
                  para generar el detalle de factores.
                </div>
              </template>
            </div>
          </div>

          <div class="col-lg-5">
            <div class="mc-card p-4">
              <h5>Evaluación profesional</h5>

              <p class="small text-muted">
                La dificultad y el riesgo de garantía se registran de forma
                explícita. El sistema no los infiere automáticamente desde
                el diagnóstico.
              </p>

              <div
                v-if="viabilitySuccess"
                class="alert alert-success"
                role="status"
              >
                {{ viabilitySuccess }}
              </div>

              <div
                v-if="viabilityFormError"
                class="alert alert-danger"
                role="alert"
              >
                {{ viabilityFormError }}
              </div>

              <form
                v-if="canManageViability"
                @submit.prevent="saveViability"
              >
                <label
                  for="viability-difficulty"
                  class="form-label"
                >
                  Dificultad técnica
                </label>

                <select
                  id="viability-difficulty"
                  v-model="viabilityForm.difficulty"
                  class="form-select mb-3"
                  :disabled="viabilitySaving || viabilityLoading"
                  required
                >
                  <option value="">Seleccionar...</option>
                  <option value="LOW">Baja</option>
                  <option value="MEDIUM">Media</option>
                  <option value="HIGH">Alta</option>
                </select>

                <label
                  for="viability-warranty-risk"
                  class="form-label"
                >
                  Riesgo de garantía
                </label>

                <select
                  id="viability-warranty-risk"
                  v-model="viabilityForm.warranty_risk"
                  class="form-select mb-3"
                  :disabled="viabilitySaving || viabilityLoading"
                  required
                >
                  <option value="">Seleccionar...</option>
                  <option value="LOW">Bajo</option>
                  <option value="MEDIUM">Medio</option>
                  <option value="HIGH">Alto</option>
                </select>

                <label
                  for="viability-notes"
                  class="form-label"
                >
                  Observaciones (opcional)
                </label>

                <textarea
                  id="viability-notes"
                  v-model="viabilityForm.notes"
                  class="form-control mb-3"
                  rows="4"
                  :disabled="viabilitySaving"
                  placeholder="Ej.: Complejidad del desmontaje, antecedentes de la falla o riesgos observados."
                ></textarea>

                <button
                  type="submit"
                  class="btn btn-primary"
                  :disabled="viabilitySaving || viabilityLoading"
                >
                  <span
                    v-if="viabilitySaving"
                    class="spinner-border spinner-border-sm me-2"
                  ></span>
                  {{ viabilitySaveLabel }}
                </button>
              </form>

              <div v-else class="alert alert-secondary mb-0">
                Tu rol permite consultar el índice, pero no modificar la evaluación.
              </div>

              <hr class="my-4">

              <h6>Reglas de cálculo HU16-v1</h6>

              <div class="small text-muted">
                <ul class="mb-3 mt-2">
                  <li>
                    Dificultad técnica: baja 20, media 12 y alta 5 puntos.
                  </li>
                  <li>
                    Repuestos: hasta 20 puntos según registro,
                    disponibilidad de stock y estado del catálogo.
                  </li>
                  <li>
                    Margen: 25 puntos desde 30%, 20 desde 15%,
                    12 desde 0% y 0 si es negativo.
                  </li>
                  <li>
                    Tiempo técnico: 20 puntos hasta 2 h, 15 hasta 6 h,
                    8 hasta 12 h y 3 sobre 12 h.
                  </li>
                  <li>
                    Riesgo de garantía: bajo 15, medio 9 y alto 3 puntos.
                  </li>
                </ul>

                <div class="border rounded p-2">
                  <strong>Niveles:</strong>
                  Alta desde 75 puntos, Media desde 50 y Baja bajo 50.
                </div>
              </div>
            </div>
          </div>
        </template>
      </section>
    </template>
  </AdminLayout>
</template>
